import firestore from '@react-native-firebase/firestore';
import {FirebaseCollections} from '../utils/constants';
import auth from '@react-native-firebase/auth';
import storage from '@react-native-firebase/storage';

export class FireStoreHelper {
  constructor(collection) {
    if (collection) {
      this.collection = firestore().collection(collection);
    }
  }

  async create(data) {
    const newDocRef = await this.collection.add(data);
    try {
      return await this.getById(newDocRef.id);
    } catch (err) {
      console.log({err});
    }
  }

  async getById(id) {
    const docRef = this.collection.doc(id);

    const doc = await docRef.get();

    if (doc.exists) {
      return doc.data();
    } else {
      return null;
    }
  }

  async update(id, data) {
    const docRef = this.collection.doc(id);

    await docRef.update(data);
  }

  async delete(id) {
    const docRef = this.collection.doc(id);

    await docRef.delete();
  }

  async getAll(status) {
    let query = this.collection;

    if (!!status) {
      query = query.where('status', '==', status);
    }

    const userId = auth().currentUser.uid;

    try {
      const querySnapshot = await query
        // .where('userId', '==', userId)
        // .orderBy('createdAt', 'desc')
        .get();
      return querySnapshot.docs.map(doc => {
        return {
          id: doc.id,
          ...doc.data(),
        };
      });
    } catch (err) {
      console.log({err});
    }
  }

  async getByColumn(column, value) {
    const querySnapshot = await this.collection
      .where(column, '==', value)
      .get();
    return querySnapshot.docs.map(doc => {
      return {
        id: doc.id,
        ...doc.data(),
      };
    });
  }

  async uploadImage(path) {
    const formatePath = path.split('/')[path.split('/').length - 1];

    console.log({path, formatePath});

    const reference = storage().ref(`images/${formatePath}`);

    try {
      // Upload the image using the path
      await reference.putFile(path);

      // Get the download URL
      const downloadURL = await reference.getDownloadURL();
      return downloadURL;
    } catch (error) {
      console.error('Image upload error:', error);
      throw error;
    }
  }

  RealTimeData(callback) {
    this.collection.onSnapshot(callback);
  }

  //   usersHelper.onSnapshot((snapshot) => {
  //     const usersData = snapshot.docs.map((doc) => doc.data());

  //     // Do something with the user data
  //   });
}
