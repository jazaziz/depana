export default AppFonts = {
  hankenGroteskRegular: 'HankenGrotesk-Regular',
  hankenGroteskMedium: 'HankenGrotesk-Medium',
  hankenGroteskSemiBold: 'HankenGrotesk-SemiBold',
  hankenGroteskBold: 'HankenGrotesk-Bold',

  metropolisRegular: 'Metropolis-Regular',
  poppinsSemiBold: 'Poppins-SemiBold',
};
