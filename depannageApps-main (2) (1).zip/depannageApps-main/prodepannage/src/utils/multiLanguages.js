export const multiLanguages = {
  //English
  0: {
    home: 'Home',

    // Sign In Page Strings
    signIn: 'Sign in',
    signInMessg: 'Please sign in your account to continue',

    // OTP Verification Page Strings
    otpVerification: 'OTP Verification',
    otpVerificationMessg: 'We just sent you 6 digit OTP code\nat ',
    confirmNow: 'Confirm Now',
    resendCode: 'Resend Code',

    // Profile Setup Page Strings
    profileSetup: 'Profile Setup',
    companyLogo: 'Company Logo',

    // Home Page Strings
    welcome: 'Welcome',

    // Notification Page Strings
    notification: 'Notification',

    // Map Page Strings
    pickupSecond: 'Pick up',

    // Order Page Strings
    order: 'Order',
    pending: 'Pending',
    onGoing: 'On going',
    completed: 'Completed',
    cancelled: 'Cancelled',

    // Job Details Page Strings
    vehicle: 'Vehicle',
    notes: 'Notes',
    waitingForApproval: 'Waiting For Customer Approval',
    mySelf: 'Myself',
    availableDriver: 'Available driver',
    customerInfo: 'Customer info',
    driverAssign: 'Driver assign',
    assign: 'Assign',
    assignDriver: 'Assign Driver',
    driverAssignedMsg: 'Driver assigned successfully!',
    jobCompleteMsg: 'Job successfully! Completed.',
    thanks: 'Thanks',
    ADM: 'ADM',
    checkIn: 'Check-in',
    submitProposal: 'Submit Proposal',
    sendProposal: 'Send Proposal',
    enterAmount: 'Enter Amount',
    successProposalMsg: 'You have successfully submitted Proposal request',
    nowStayCalm: 'now stay calm and wait for proposal from customer approvel',
    submitOTP: 'Submit OTP',
    cancelReason: 'Cancel Reason',
    feelingNotwell: 'Feeling not well',
    personalEmergency: 'Personal Emergency',
    distanceFarOut: 'Distance is too far out',
    somethingElse: "It's something else",
    currentlynvoledAccident: 'Currently involved in an accident',
    other: 'Other',
    epxlainOther: 'Please explain your reason in details',
    cancelledNow: 'Cancelled now',
    notesTag: 'Note* ',
    noteDesc: 'Enter OTP received by customer to complete this job',
    vehicleDetail: 'Vehicle Detail',
    brand: 'Brand',
    yes: 'Yes',
    no: 'No',
    pickup: 'Pickup',
    dropOff: 'Drop-off',
    dateTime: 'Date & Time',
    thankMsg: 'Thank You',
    cancel: 'Cancel',
    paymentMethod: 'Payment Method',
    bookingDateTime: 'Booking Date & Time',
    amount: 'Amount',
    registrationNumber: 'Registration Number',
    year: 'Year',
    maker: 'Maker',

    // My Profile Page Strings
    myProfile: 'My Profile',
    notifications: 'Notifications',
    CMobileNumber: 'Change mobile number',
    manageAgents: 'Manage agents',
    wallet: 'Wallet',
    terms: 'Terms & conditions',
    termsSecond: 'Terms & Conditions',
    privacy: 'Privacy policy',
    privacySecond: 'Privacy Policy',
    support: 'Support',
    deleteAccount: 'Delete account',
    logout: 'Log out',
    logout: 'Log out',

    // Change Number Page Strings
    CMobileNumberSecond: 'Change Mobile Number',
    cNumber: 'Change Number',
    cNumberMsg:
      'Please enter your any new mobile number which you want to change',
    save: 'Save',

    // Edit Profile Page Strings
    editProfile: 'Edit Profile',
    updateNow: 'Update Now',
    fullName: 'Full Name',

    // Support Page Strings
    contactUs: 'Contact Us',
    emailUs: 'Email Us',

    // Rate Review Page Strings
    rateReview: 'Rate & Review',
    rateReviews: 'Rate & Reviews',
    all: 'All',

    // Manage agents Page Strings
    manageAgentsSecond: 'Manage Agents',
    edit: 'Edit',
    delete: 'Delete',
    addAgent: 'Add Agent',
    addNow: 'Add Now',
    name: 'Name',

    // Wallet Page Strings
    wallet: 'Wallet',
    availableEarn: 'Available Earning',
    totalEarn: 'Total Earning',
    withdrawMoney: 'Withdraw Money',
    paymentHistory: 'Payment History',

    // Add Bank Account Page Strings
    addBankAccount: 'Add Bank Account',
    accNumber: 'Account number',
    reEntAccNumber: 'Re-Enter Account number',
    IFSCCode: 'IFSC Code',
    addAccount: 'Add Account',
    secureMsg: 'Safe and Secure Payments.Easy 100% Authentic Assure',

    // App Validation messages strings
    noResult: 'No data found.',
    companyName: 'Company Name',
    mNumber: 'Mobile Number',
    location: 'Location',
    aboutCompany: 'About Company',
    continue: 'Continue',
    plsEnterOTP: 'Enter OTP',
    plsEnterOtpMsg: 'Please enter your OTP code.',
    OTPIncorrect: 'Entered OTP is incorrect.',
    logoutAccountMsg: 'Are you sure you want to logout?',
    deleteAccountMsg: 'Are you sure you want to delete this account?',
  },
  //French
  1: {
    home: 'Maison',

    // Sign In Page Strings
    signIn: "S'identifier",
    signInMessg: 'Veuillez vous connecter à votre compte pour continuer',

    // OTP Verification Page Strings
    otpVerification: 'Vérification OTP',
    otpVerificationMessg:
      'Nous venons de vous envoyer un code OTP à 4 chiffres\nat',
    confirmNow: 'Confirmer maintenant',
    resendCode: 'Renvoyer le code',

    // Attention Page Strings
    attention: 'Attention',
    attentionMessg:
      'Pour votre sécurité, veuillez prendre les mesures de sécurité suivantes',
    ok: "D'accord",
    turnOnLight: 'Allumer le feu de circulation',
    wearJacket: 'Porter une veste jaune',
    placement: 'Placement du triangle de sécurité',
    pleaseHold: 'Merci de vous tenir à la barrière',

    // Profile Setup Page Strings
    profileSetup: 'Configuration du profil',
    companyLogo: "Logo d'entreprise",

    // Home Page Strings
    welcome: 'Bienvenue',

    // Notification Page Strings
    notification: 'Notification',

    // Map Page Strings
    pickupSecond: 'Ramasser',

    // Order Page Strings
    order: 'Commande',
    pending: 'En attente',
    onGoing: 'En cours',
    completed: 'Complété',
    cancelled: 'Annulé',

    // Job Details Page Strings
    vehicle: 'Véhicule',
    notes: 'Remarques',
    waitingForApproval: "En attente de l'approbation du client",
    mySelf: 'Moi-même',
    availableDriver: 'Pilote disponible',
    customerInfo: 'Informations concernant le client',
    driverAssign: 'Affectation du conducteur',
    assign: 'Attribuer',
    assignDriver: 'Attribuer un chauffeur',
    driverAssignedMsg: 'Chauffeur attribué avec succès !',
    jobCompleteMsg: 'Travail réussi ! Complété.',
    thanks: 'Merci',
    ADM: 'SMA',
    checkIn: 'Enregistrement',
    submitProposal: 'Soumettre une proposition',
    sendProposal: 'Envoyer la proposition',
    enterAmount: 'Entrer le montant',
    successProposalMsg:
      'Vous avez soumis avec succès la demande de proposition',
    nowStayCalm:
      "maintenant restez calme et attendez la proposition de l'approbation du client",
    submitOTP: 'Soumettre OTP',
    cancelReason: "Raison d'annulation",
    feelingNotwell: 'Ne pas se sentir bien',
    personalEmergency: 'Urgence personnelle',
    distanceFarOut: 'La distance est trop grande',
    somethingElse: "C'est autre chose",
    currentlynvoledAccident: 'Actuellement impliqué dans un accident',
    other: 'Autre',
    epxlainOther: 'Veuillez expliquer votre raison en détail',
    cancelledNow: 'Annulé maintenant',
    notesTag: 'Note* ',
    noteDesc: "Entrez l'OTP reçu par le client pour terminer ce travail",
    vehicleDetail: 'Les détails du véhicule',
    brand: 'Marque',
    registrationNumber: "Numéro d'enregistrement",
    year: 'Année',
    maker: 'Fabricante',
    yes: 'Oui',
    no: 'Non',
    pickup: 'Ramasser',
    dropOff: 'Déposer',
    dateTime: 'Date et heure',
    thankMsg: 'Merci',
    cancel: 'Annuler',
    bookingDateTime: 'Date et heure de réservation',
    amount: 'Montante',
    paymentMethod: 'Mode de paiement',

    // My Profile Page Strings
    myProfile: 'Mon profil',
    notifications: 'Avis',
    manageAgents: 'Gérer les agents',
    wallet: 'Portefeuille',
    CMobileNumber: 'Changer de numéro de portable',
    terms: 'Termes et conditions',
    termsSecond: 'termes et conditions',
    privacy: 'Politique de confidentialité',
    privacySecond: 'politique de confidentialité',
    support: 'Soutien',
    deleteAccount: 'Supprimer le compte',
    logout: 'Se déconnecter',

    // Change Number Page Strings
    CMobileNumberSecond: 'Changer de numéro de portable',
    cNumber: 'Changer de numéro',
    cNumberMsg:
      'Veuillez entrer votre nouveau numéro de mobile que vous souhaitez modifier',
    save: 'Sauvegarder',

    // Edit Profile Page Strings
    editProfile: 'Editer le profil',
    updateNow: 'Mettez à jour maintenant',
    fullName: 'Nom et prénom',

    // Support Page Strings
    contactUs: 'Contactez-nous',
    emailUs: 'Envoyez-nous un email',

    // Rate Review Page Strings
    rateReview: 'Noter et commenter',
    rateReviews: 'Note et avis',
    all: 'Toute',

    // Manage agents Page Strings
    manageAgentsSecond: 'Gérer les agents',
    edit: 'Modifier',
    delete: 'Supprimer',
    addAgent: 'Ajouter un agent',
    addNow: 'Ajouter maintenant',
    name: 'Nom',

    // Wallet Page Strings
    wallet: 'Portefeuille',
    availableEarn: 'Gain disponible',
    totalEarn: 'Gain total',
    withdrawMoney: "Retirer de l'argent",
    paymentHistory: 'historique de paiement',

    // Add Bank Account Page Strings
    addBankAccount: 'Ajouter un compte bancaire',
    accNumber: 'Numéro de compte',
    reEntAccNumber: 'Réécrivez votre numéro de compte',
    IFSCCode: 'Code IFSC',
    addAccount: 'Ajouter un compte',
    secureMsg: 'Paiements sûrs et sécurisés.Assure 100% authentique facile',

    // App Validation messages strings
    noResult: 'Aucune donnée disponible.',
    companyName: "Nom de l'entreprise",
    mNumber: 'Numéro de portable',
    location: 'Emplacement',
    aboutCompany: 'À propos de la société',
    continue: 'Continuer',
    plsEnterOTP: 'Entrez OTP',
    plsEnterOtpMsg: 'Veuillez entrer votre code OTP.',
    OTPIncorrect: "L'OTP saisi est incorrect.",
    logoutAccountMsg: 'Êtes-vous sûr de vouloir vous déconnecter?',
    deleteAccountMsg: 'Voulez-vous vraiment supprimer ce compte ?',
  },
};
