import {ServiceTypes, googleMapApiKey} from './constants';
import Geocoder from 'react-native-geocoding';
import auth from '@react-native-firebase/auth';
import {Alert, Linking} from 'react-native';

export const formatePhoneNumber = (phone, countryCode) => {
  // Remove the leading zero from the phone number if it exists.
  const phoneNumber = phone.replace(/^0/, '');
  // Return the phone number with the country code prepended.
  return `${countryCode}${phoneNumber}`;
};

export const orderTypeMapping = status => {
  switch (status) {
    case ServiceTypes.TowingService:
      return 'Towing Service';

    case ServiceTypes.FuelOrGas:
      return 'Fuel or Gas';

    case ServiceTypes.TireChange:
      return 'Tire Change';

    case ServiceTypes.BatteryChange:
      return 'Battery Change';

    case ServiceTypes.Texi:
      return 'Taxi';

    case ServiceTypes.VisitTechnique:
      return 'Visit Technique';
  }
};

export const convertLatLngToAddress = async (lat, lng) => {
  // if (!lat && !lng) return '';

  console.log({lat, lng});

  Geocoder.init(googleMapApiKey);
  const response = await Geocoder.from(lat, lng);
  // console.log({response: response.results[0]});
  const address = response.results[0].formatted_address;

  console.log({fadd: address});
  return address;
};

export const fetchUserData = async () => {
  return auth().currentUser;
};

const deg2rad = deg => {
  return deg * (Math.PI / 180);
};
export const calculateDistance = (lat1, lon1, lat2, lon2) => {
  // Earth's radius at the average latitude of the two points
  const latAverage = (lat1 + lat2) / 2;
  const earthRadius =
    6371 / (1 + 0.00669438 * Math.pow(Math.sin(deg2rad(latAverage)), 2));

  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) *
      Math.cos(deg2rad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = earthRadius * c;

  return distance.toFixed(2);
};

export const openDialer = phoneNumber => {
  const tel = `tel:${phoneNumber}`;
  Linking.openURL(tel).catch(err => Alert.alert('Error', err));
};

export const openEmail = emailAddress => {
  Linking.openURL(`mailto:${emailAddress}`);
};

export const calculateAverageRating = ratings => {
  if (ratings.length === 0) {
    return 0; // Return 0 if the array is empty to avoid division by zero
  }

  const total = ratings.reduce((acc, rating) => acc + rating, 0);
  const average = total / ratings.length;

  return average.toFixed(2);
};

export const timeDifference = timestamp => {
  // Convert the timestamp to a Date object
  const timestampDate = new Date(timestamp);
  // Get the current time
  const currentTime = new Date();
  // Calculate the time difference in milliseconds
  const timeDiffMillis = currentTime - timestampDate;
  // Convert milliseconds to seconds
  const timeDiffSeconds = Math.floor(timeDiffMillis / 1000);
  // Convert seconds to minutes
  const timeDiffMinutes = Math.floor(timeDiffSeconds / 60);
  // Convert minutes to hours
  const timeDiffHours = Math.floor(timeDiffMinutes / 60);
  // Create a human-readable string
  if (timeDiffHours > 0) {
    return `${timeDiffHours}h ago`;
  } else if (timeDiffMinutes > 0) {
    return `${timeDiffMinutes} min ago`;
  } else {
    return 'Just now';
  }
};
