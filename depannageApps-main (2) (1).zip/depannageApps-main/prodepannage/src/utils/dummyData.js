export const dummuData = {
  TILE_OPTION_DATA: [
    {
      id: 1,
    },
    {
      id: 2,
    },
    {
      id: 3,
    },
    {
      id: 4,
    },
    {
      id: 5,
    },
    {
      id: 6,
    },
  ],
};

export default {dummuData};
