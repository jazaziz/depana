import React, {useEffect} from 'react';
import {
  LogBox,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  StatusBar,
} from 'react-native';

import {enableScreens} from 'react-native-screens';

import Router from './routes/AppRouter';
import ContextProvider from './contextAPI/contextProvider';

import {colors} from './utils/constants';
import {notificationListener} from './service/notifications';

const App = () => {
  useEffect(() => {
    LogBox.ignoreAllLogs();
    if (Platform.OS === 'ios') enableScreens(false);
    // Below code is use solving the font scale issue
    if (Text.defaultProps == null) Text.defaultProps = {};
    Text.defaultProps.allowFontScaling = false;
    if (TextInput.defaultProps == null) TextInput.defaultProps = {};
    TextInput.defaultProps.allowFontScaling = false;
  }, []);

  useEffect(() => {
    // create a clean up function of notificationListener
    const unsubscribe = async () => {
      const {openedAppSubscription, messageSubscription} =
        await notificationListener();
      return () => {
        openedAppSubscription();
        messageSubscription();
      };
    };
    unsubscribe();
  }, []);

  return (
    <ContextProvider>
      <StatusBar
        animated
        backgroundColor={colors.transparent}
        translucent={true}
        barStyle={'light-content'}
      />
      <Router />
    </ContextProvider>
  );
};

const styles = StyleSheet.create({});

export default App;
