import React from 'react';
import {
  FlatList,
  RefreshControl,
  Image,
  StyleSheet,
  Text,
  View,
  Pressable,
} from 'react-native';

import PropTypes from 'prop-types';
import {moderateScale, scale} from 'react-native-size-matters';

import EmptyMessageComponent from './EmptyMessageComponent';

import {colors, config} from '../utils/constants';
import {ImageView} from '../utils/imageView';
import appFonts from '../utils/appFonts';
import {timeDifference} from '../utils/helpers';

const NotificationListComponent = props => {
  const renderNotificationList = ({item}) => {
    const createdAtDate = new Date(item?.createdAt.toDate());
    return (
      <Pressable
        onPress={() => props.onPress(item)}
        style={styles.listItemContainer}>
        <View
          style={{
            flex: 0.2,
            alignItems: 'center',
          }}>
          <Image
            resizeMode="contain"
            style={styles.notificationIcon}
            source={ImageView.notificationSecond}
          />
        </View>
        <View
          style={{
            flex: 0.8,
            paddingHorizontal: scale(5),
            paddingVertical: scale(2),
            justifyContent: 'space-between',
          }}>
          <Text style={styles.titleTxt}>{item?.data?.title ?? '-'}</Text>
          <Text style={styles.descTxt}>{item?.data?.body ?? '-'}</Text>
        </View>
        <View style={{flex: 0.2}}>
          <Text style={styles.timeTxt}>{timeDifference(createdAtDate)}</Text>
        </View>
      </Pressable>
    );
  };
  return (
    <FlatList
      contentContainerStyle={styles.listContentContianer}
      style={{flex: 1}}
      data={props.listData}
      keyExtractor={item => item?.id}
      showsVerticalScrollIndicator={false}
      ListEmptyComponent={<EmptyMessageComponent />}
      ItemSeparatorComponent={() => <View style={{marginVertical: scale(8)}} />}
      renderItem={renderNotificationList}
      ListFooterComponent={props.LoadmoreSpinner}
      onEndReachedThreshold={0.05}
      onEndReached={props.onEndReached}
      refreshControl={
        <RefreshControl
          refreshing={false}
          onRefresh={props.refreshCall}
          tintColor={colors.primaryColor}
          progressBackgroundColor={colors.gray98}
          colors={[colors.primaryColor]}
        />
      }
    />
  );
};

const styles = StyleSheet.create({
  listContentContianer: {
    padding: scale(20),
  },
  listItemContainer: {
    backgroundColor: colors.white,
    borderRadius: 14,
    padding: scale(10),
    paddingVertical: scale(15),
    flexDirection: 'row',
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.17,
    shadowRadius: 2.54,
    elevation: 3,
  },
  notificationIcon: {
    width: scale(45),
    height: scale(45),
  },
  titleTxt: {
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(16),
    color: colors.blackBlue,
    marginBottom: scale(2),
  },
  descTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(13),
    color: colors.suvaGrey,
  },
  timeTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(12),
    color: colors.suvaGrey,
    top: scale(5),
    textAlign: 'right',
  },
});

NotificationListComponent.propTypes = {
  listData: PropTypes.any,
  onPress: PropTypes.func,
  LoadmoreSpinner: PropTypes.any,
  refreshCall: PropTypes.any,
  onEndReached: PropTypes.any,
};
NotificationListComponent.defaultProps = {};

export default NotificationListComponent;
