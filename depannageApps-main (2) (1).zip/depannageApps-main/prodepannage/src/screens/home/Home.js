import React, {useContext, useEffect, useState} from 'react';
import {StyleSheet, View} from 'react-native';

import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import {useBackHandler} from '@react-native-community/hooks';
import RNExitApp from 'react-native-exit-app';

import HeaderComponent from '../../components/HeaderComponent';
import OrderTypeListComponent from '../../components/OrderTypeListComponent';

import {
  FirebaseCollections,
  ServicesStatus,
  colors,
  config,
} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import appFonts from '../../utils/appFonts';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';
import {dummuData} from '../../utils/dummyData';
import {useFocusEffect} from '@react-navigation/native';
import {FireStoreHelper} from '../../service/firebase';
import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';

const Home = ({navigation}) => {
  const contextAPI = useContext(ContextAPI);
  const [orders, setOrders] = useState(null);

  useBackHandler(() => {
    RNExitApp.exitApp();
    return true;
  });

  const fetchOrders = async () => {
    contextAPI.setLoading(true);

    const user = auth().currentUser;

    const proposals = firestore().collection(FirebaseCollections.Proposals);
    const orders = firestore().collection(FirebaseCollections.Services);

    try {
      const proposalsQuerySnapshot = await proposals
        .where('company.userId', '==', user.uid)
        .get();

      const orderIDsWithProposals = proposalsQuerySnapshot.docs.map(
        doc => doc.data().orderId,
      );

      if (orderIDsWithProposals.length > 0) {
        const chunkSize = 10;
        const ordersQueryPromises = [];

        while (orderIDsWithProposals.length > 0) {
          const chunk = orderIDsWithProposals.splice(0, chunkSize);

          const ordersQuery = orders
            .where(firestore.FieldPath.documentId(), 'not-in', chunk)
            .where('status', '==', ServicesStatus.PENDING)
            .get();

          ordersQueryPromises.push(ordersQuery);
        }

        const results = await Promise.allSettled(ordersQueryPromises);

        const fulfilledResults = results
          .filter(result => result.status === 'fulfilled')
          .map(result => result.value);

        const pendingOrdersProposals = fulfilledResults.flatMap(snapshot =>
          snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data(),
          })),
        );

        setOrders(pendingOrdersProposals);
      } else {
        // No proposals, fetch all pending orders directly
        const ordersQuery = orders
          .where('status', '==', ServicesStatus.PENDING)
          .get();

        const ordersSnapshot = await ordersQuery;
        const pendingOrders = ordersSnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        }));

        setOrders(pendingOrders);
      }

      contextAPI.setLoading(false);
    } catch (error) {
      contextAPI.setLoading(false);
      console.error('Error fetching data:', error.message);
    }
  };

  const handleOrders = async () => {
    const collection = new FireStoreHelper(FirebaseCollections.Services);

    contextAPI.setLoading(true);
    const data = await collection.getAll(ServicesStatus.PENDING);

    setOrders(data);

    setTimeout(() => {
      contextAPI.setLoading(false);
    }, 500);
  };

  // useFocusEffect(
  //   React.useCallback(() => {
  //     handleOrders();
  //   }, []),
  // );

  useEffect(() => {
    fetchOrders();
    // handleOrders();
  }, []);

  return (
    <View style={styles.container}>
      <HeaderComponent
        centerTxt={multiLanguages[contextAPI?.appLang]?.welcome}
        headerTxt={styles.headerTxt}
        rightIcon={ImageView.notifications}
        rightIconStyl={styles.rightIconStyl}
        rightIconPress={() => {
          navigation.navigate('Notification');
        }}
        headerContainer={styles.headerContainer}
      />
      <View style={{flex: 1}}>
        <OrderTypeListComponent
          orderPress={item => {
            navigation.navigate('JobDetail', {
              type: config.PROPOSAL,
              order: item,
            });
          }}
          listData={orders}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  headerContainer: {
    height: verticalScale(70),
    borderBottomEndRadius: 35,
    borderBottomStartRadius: 35,
  },
  headerTxt: {
    textAlign: 'left',
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(24),
  },
  rightIconStyl: {
    width: scale(45),
    height: scale(45),
  },
});

export default Home;
