import React, {useContext, useState, useEffect} from 'react';
import {StyleSheet, View} from 'react-native';

import {useBackHandler} from '@react-native-community/hooks';

import NotificationListComponent from '../../components/NotificationListComponent';
import HeaderComponent from '../../components/HeaderComponent';

import {colors, FirebaseCollections} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import {dummuData} from '../../utils/dummyData';
import {multiLanguages} from '../../utils/multiLanguages';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {FireStoreHelper} from '../../service/firebase';
import auth from '@react-native-firebase/auth';

const Notification = ({navigation}) => {
  const [notificationData, setNotificationData] = useState([]);
  const contextAPI = useContext(ContextAPI);

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  const fetchNotificationData = async () => {
    try {
      const user = auth().currentUser;
      const notification = new FireStoreHelper(
        FirebaseCollections.notifications,
      );
      contextAPI.setLoading(true);
      const data = await notification.getByColumn('userId', user.uid);
      setNotificationData(data);
    } catch (err) {
      console.log({err});
    }
    contextAPI.setLoading(false);
  };

  useEffect(() => {
    (async () => {
      await fetchNotificationData();
    })();
  }, []);

  return (
    <View style={styles.container}>
      <HeaderComponent
        leftIconPress={() => {
          navigation.goBack();
        }}
        leftIcon={ImageView.backIconSecond}
        centerTxt={multiLanguages[contextAPI?.appLang]?.notification}
      />
      <NotificationListComponent
        onPress={item => {}}
        listData={notificationData}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
});

export default Notification;
