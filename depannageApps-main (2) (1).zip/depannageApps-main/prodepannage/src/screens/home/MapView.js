import React, {useContext, useEffect, useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  Dimensions,
  TouchableOpacity,
} from 'react-native';

import {moderateScale, scale} from 'react-native-size-matters';
import {useBackHandler} from '@react-native-community/hooks';

import HeaderComponent from '../../components/HeaderComponent';

import {colors} from '../../utils/constants';
import imageView, {ImageView} from '../../utils/imageView';
import appFonts from '../../utils/appFonts';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';
import RnMap, {Marker} from 'react-native-maps';
import Geolocation from '@react-native-community/geolocation';
import {calculateDistance, openDialer} from '../../utils/helpers';

const MapView = ({navigation, route}) => {
  const contextAPI = useContext(ContextAPI);
  const [order, setOrder] = useState(route.params?.order ?? null);
  const [currentLocation, setCurrentLocation] = useState({
    longitude: order?.pickUp?.lat,
    latitude: order?.pickUp?.lng,
  });

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  const getCurrentLocation = () => {
    Geolocation.getCurrentPosition(
      p => {
        const {latitude, longitude} = p.coords;
        setCurrentLocation({
          latitude,
          longitude,
        });
      },
      err => {
        console.log('err ->>', err);
      },
      {
        enableHighAccuracy: true,
        timeout: 20000,
        maximumAge: 1000,
      },
    );
  };

  useEffect(() => {
    getCurrentLocation();
  }, []);

  const LocationDetailsView = () => (
    <View style={styles.locationDetailsContainer}>
      {TrackPickupDetailsView()}
    </View>
  );

  const TrackPickupDetailsView = () => (
    <View
      style={[
        styles.locationWhiteBox,
        {
          paddingVertical: scale(15),
          paddingHorizontal: scale(15),
          width: '90%',
        },
      ]}>
      <View
        style={{
          flexDirection: 'row',
        }}>
        <View
          style={{
            flex: 0.2,
          }}>
          <Image
            resizeMode="contain"
            style={{width: scale(40), height: scale(40)}}
            source={ImageView.trackLocation}
          />
        </View>
        <View
          style={[
            styles.locationPlaceholderContainer,
            {
              flex: 0.8,
            },
          ]}>
          <Text style={styles.locationTxt}>
            {multiLanguages[contextAPI?.appLang]?.pickupSecond}
          </Text>
          <Text style={styles.locationPickupTxt}>
            {
              '4517 Washington Ave. Manchester, Kentucky Preston Rd. Inglewood, Maine39495'
            }
          </Text>
        </View>
      </View>
    </View>
  );

  const BottomTrackDetailsView = () => (
    <View
      style={{
        backgroundColor: colors.white,
        position: 'absolute',
        bottom: 0,
        right: 0,
        left: 0,
        padding: scale(15),
        borderTopEndRadius: 35,
        borderTopStartRadius: 35,
      }}>
      <View style={styles.dragLine} />
      <View style={styles.sizeBox} />
      <View
        style={{
          flexDirection: 'row',
          padding: scale(5),
        }}>
        <View style={{flex: 0.2, justifyContent: 'center'}}>
          <Image
            resizeMode="contain"
            style={styles.profileIcon}
            source={ImageView.dummyImg}
          />
        </View>
        <View
          style={{
            flex: 0.6,
            justifyContent: 'space-around',
          }}>
          <Text style={styles.userTxt}>{order?.contactInfo?.name}</Text>
          <Text style={styles.milesTxt}>{`${calculateDistance(
            currentLocation.latitude,
            currentLocation.longitude,
            order?.pickUp?.lng,
            order?.dropOff?.lat,
            order?.dropOff?.lng,
          )} KM Away`}</Text>
        </View>
        <TouchableOpacity
          onPress={() => openDialer(order?.contactInfo?.phone)}
          style={{
            flex: 0.2,
            justifyContent: 'center',
            alignItems: 'flex-end',
          }}>
          <Image
            resizeMode="contain"
            style={styles.callIcon}
            source={ImageView.call}
          />
        </TouchableOpacity>
      </View>
    </View>
  );

  const GoogleMap = () => {
    const {width, height} = Dimensions.get('window');

    const ASPECT_RATIO = width / height;
    const LATITUDE_DELTA = 0.012;
    const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

    const dummyLocation = {
      latitude: 31.728584,
      longitude: -7.011981,
    };

    const locationData = {
      latitude: order?.pickUp?.lat || dummyLocation?.latitude,
      longitude: order?.pickUp?.lng || dummyLocation?.longitude,
    };

    return (
      <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
        <RnMap
          style={{
            flex: 1,
            width: width * 1,
            height: height * 0.6,
          }}
          initialRegion={{
            latitude: locationData.latitude,
            longitude: locationData.longitude,
            latitudeDelta: LATITUDE_DELTA,
            longitudeDelta: LONGITUDE_DELTA,
          }}
          zoomEnabled={true}
          zoomControlEnabled={true}
          zoomTapEnabled={true}
          showsUserLocation={true}
          mapType="standard"
          showsMyLocationButton={true}
          customMapStyle={mapStyles}
          //
        >
          <Marker
            coordinate={locationData}
            draggable={true}
            onDragEnd={e => (selectedLocation = e.nativeEvent.coordinate)}>
            <Image
              source={imageView.ImageView.trackLocation}
              style={{
                width: 50,
                height: 50,
              }}
              resizeMode="contain"
            />
          </Marker>
        </RnMap>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <HeaderComponent
        leftIcon={ImageView.backIcon}
        leftIconStyl={styles.leftIconStyl}
        leftIconPress={() => {
          navigation.goBack();
        }}
        headerContainer={styles.headerContainer}
      />
      {GoogleMap()}
      {BottomTrackDetailsView()}
    </View>
  );
};

const mapStyles = [
  {
    featureType: 'road',
    elementType: 'geometry.stroke',
    stylers: [
      {color: '#0071BC'}, // Set the color of major roads to blue
    ],
  },
  {
    featureType: 'road',
    elementType: 'geometry.fill',
    stylers: [
      {color: '#FFFFFF'}, // Set the color of the road background to white
    ],
  },
  {
    featureType: 'road',
    elementType: 'labels.icon',
    stylers: [
      {color: '#0071BC'}, // Set the color of local road arrow icons to blue
      {visibility: 'on'}, // Show local road arrow icons
    ],
  },
  {
    featureType: 'transit.line',
    elementType: 'geometry.fill',
    stylers: [
      {color: '#0071BC'}, // Set the color of transit lines to blue
    ],
  },
];

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.transparent,
  },
  headerContainer: {
    position: 'absolute',
    backgroundColor: colors.transparent,
    paddingTop: scale(20),
    width: '95%',
    paddingHorizontal: scale(10),
    zIndex: 10,
  },
  leftIconStyl: {
    width: scale(70),
    height: scale(70),
    top: scale(5),
    right: scale(5),
    borderRadius: scale(70 / 2),
  },
  locationDetailsContainer: {
    right: 0,
    left: 0,
    top: scale(70),
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
  },
  locationWhiteBox: {
    borderRadius: 20,
    backgroundColor: colors.white,
    width: '75%',
    paddingHorizontal: scale(20),
    paddingVertical: scale(10),
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
  },
  locationTxt: {
    color: colors.black,
    opacity: 0.4,
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(14),
  },
  locationPickupTxt: {
    marginTop: scale(5),
    color: colors.black,
    opacity: 0.9,
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(15),
  },
  locationPlaceholderContainer: {
    flex: 0.9,
    justifyContent: 'center',
  },
  dragLine: {
    height: scale(6),
    width: scale(75),
    borderRadius: 13,
    backgroundColor: colors.silver,
    alignSelf: 'center',
  },
  sizeBox: {
    marginVertical: scale(5),
  },
  profileIcon: {
    width: scale(50),
    height: scale(50),
  },
  callIcon: {
    width: scale(48),
    height: scale(41),
  },
  userTxt: {
    color: colors.approxBlack,
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(18),
  },
  milesTxt: {
    color: colors.primaryColor,
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(14),
  },
});

export default MapView;
