import React, {useContext, useEffect, useState} from 'react';
import {StyleSheet, View} from 'react-native';

import {useBackHandler} from '@react-native-community/hooks';
import {scale} from 'react-native-size-matters';

import HeaderComponent from '../../components/HeaderComponent';
import TopTabBarComponent from '../../components/TopTabBarComponent';
import OrderTypeListComponent from '../../components/OrderTypeListComponent';

import {
  FirebaseCollections,
  ServicesStatus,
  colors,
  config,
} from '../../utils/constants';
import {dummuData} from '../../utils/dummyData';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';
import {useFocusEffect} from '@react-navigation/native';
import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';

const Order = ({navigation}) => {
  const contextAPI = useContext(ContextAPI);
  const [selectedTab, setSelectedTab] = useState(
    multiLanguages[contextAPI?.appLang]?.pending,
  );
  const [orders, setOrders] = useState([]);

  const handleOrders = async () => {
    let orderStatus = ServicesStatus.PENDING;

    switch (selectedTab) {
      case multiLanguages[contextAPI?.appLang].onGoing:
        orderStatus = ServicesStatus.ON_GOING;
        break;

      case multiLanguages[contextAPI?.appLang].completed:
        orderStatus = ServicesStatus.COMPLETED;
        break;

      case multiLanguages[contextAPI?.appLang].cancelled:
        orderStatus = ServicesStatus.CANCELLED;
        break;
    }

    contextAPI.setLoading(true);

    const user = auth().currentUser;

    const proposals = firestore().collection(FirebaseCollections.Proposals);
    const orders = firestore().collection(FirebaseCollections.Services);

    try {
      const proposalsQuerySnapshot = await proposals
        .where('company.userId', '==', user.uid)
        .get();

      const orderIDsWithProposals = proposalsQuerySnapshot.docs.map(
        doc => doc.data().orderId,
      );

      const chuckSize = 10;
      const orderPromises = [];

      while (orderIDsWithProposals.length > 0) {
        const chunk = orderIDsWithProposals.splice(0, chuckSize);

        const orderProm = orders
          .where('status', '==', orderStatus)
          .where(firestore.FieldPath.documentId(), 'in', chunk)
          .get();

        orderPromises.push(orderProm);
      }

      const results = await Promise.allSettled(orderPromises);

      const fulfilledResults = results
        .filter(result => result.status === 'fulfilled')
        .map(result => result.value);

      const pendingOrdersProposals = fulfilledResults.flatMap(snapshot =>
        snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        })),
      );

      setOrders(pendingOrdersProposals);

      contextAPI.setLoading(false);
    } catch (error) {
      contextAPI.setLoading(false);
      console.error('Error fetching data:', error);
    }
  };

  useFocusEffect(
    React.useCallback(() => {
      handleOrders();
    }, [selectedTab]),
  );

  // useEffect(() => {
  //   handleOrders();
  // }, [selectedTab]);

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  return (
    <View style={styles.container}>
      <HeaderComponent centerTxt={multiLanguages[contextAPI?.appLang]?.order} />
      <View style={{paddingBottom: scale(10), padding: scale(20)}}>
        <TopTabBarComponent
          selectedTab={selectedTab}
          titleOne={multiLanguages[contextAPI?.appLang]?.pending}
          titleSecond={multiLanguages[contextAPI?.appLang]?.onGoing}
          titleThird={multiLanguages[contextAPI?.appLang]?.completed}
          titleFour={multiLanguages[contextAPI?.appLang]?.cancelled}
          onTabPress={flag => {
            if (flag == selectedTab) return;
            setSelectedTab(flag);
          }}
        />
      </View>
      <OrderTypeListComponent
        orderPress={item => {
          selectedTab == multiLanguages[contextAPI?.appLang]?.pending
            ? navigation.navigate('JobDetail', {
                type: config.APPROVAL_WAIT,
                order: item,
              })
            : navigation.navigate('JobDetail', {
                type: config.ASSIGN,
                order: item,
              });
        }}
        listData={orders}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
});

export default Order;
