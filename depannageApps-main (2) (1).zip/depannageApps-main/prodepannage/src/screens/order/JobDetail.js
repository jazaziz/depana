import React, {useContext, useEffect, useRef, useState} from 'react';
import {
  StyleSheet,
  View,
  ScrollView,
  Image,
  Pressable,
  Keyboard,
  FlatList,
  Text,
  Alert,
} from 'react-native';

import {useBackHandler} from '@react-native-community/hooks';
import RBSheet from 'react-native-raw-bottom-sheet';
import Modal from 'react-native-modal';
import {Avatar, Divider} from 'react-native-paper';
import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import OTPTextInput from 'react-native-otp-textinput';

import HeaderComponent from '../../components/HeaderComponent';
import ButtonComponent from '../../components/ButtonComponent';
import TextInputComponent from '../../components/TextInputComponent';

import {
  FirebaseCollections,
  ServicesStatus,
  colors,
  config,
} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import appFonts from '../../utils/appFonts';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';
import Validation from '../../utils/validation';
import {orderTypeMapping} from '../../utils/helpers';
import {FireStoreHelper} from '../../service/firebase';
import auth from '@react-native-firebase/auth';
import {sendNotification} from '../../service/notifications';

const JobDetail = ({navigation, route}) => {
  const [inputFocus, setInputFocus] = useState('');
  const [enterAmount, setEnterAmount] = useState('');
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [selectedReason, setSelectedReason] = useState('');
  const [cancelReasonValue, setCancelReasonValue] = useState(null);
  const [otherReason, setOtherReason] = useState('');

  // REVIEW - Please check status list in config of constant file.
  const [submitType, setSubmitType] = useState('');
  const [jobDetailStatus, setJobDetailStatus] = useState(
    route.params?.type ?? '',
  );
  const [order, setOrder] = useState(route.params?.order ?? null);
  const [rideStatus, setRideStatus] = useState('');
  const [divers, setDivers] = useState();
  const [userCompany, setUserCompany] = useState(null);
  const [selectedDriver, setSelectedDriver] = useState(
    route.params?.order?.driver ?? null,
  );
  const [orderProposal, setOrderProposal] = useState(null);

  const cancelReasonBSheetRef = useRef('');
  const otpVerificationBSheetRef = useRef('');
  const asignDriverBSheetRef = useRef('');
  const proposalBSheetRef = useRef('');
  const otpRef = useRef('');

  const rideStatusType = {
    CheckIn: config.CHECK_IN,
    Complete: config.COMPLETE,
    Cancel: config.CANCEL,
  };

  const contextAPI = useContext(ContextAPI);

  const submitProposal = async () => {
    Keyboard.dismiss();
    proposalBSheetRef.current.close();

    try {
      contextAPI.setLoading(true);
      const proposals = new FireStoreHelper(FirebaseCollections.Proposals);
      const companies = new FireStoreHelper(FirebaseCollections.Companies);
      const userSettings = new FireStoreHelper(
        FirebaseCollections.userSettings,
      );
      const notification = new FireStoreHelper(
        FirebaseCollections.notifications,
      );

      const user = auth().currentUser;

      const userCompany = await companies.getByColumn('userId', user.uid);

      const payload = {
        amount: enterAmount,
        orderId: order.id,
        company: userCompany[0],
      };

      await proposals.create(payload);

      // send notification to user
      const isCustomerSettingExits = await userSettings.getByColumn(
        'userId',
        order?.userId,
      );

      if (isCustomerSettingExits.length > 0) {
        const message = {
          title: `${userCompany[0].companyName} has submitted a proposal`,
          body: `${
            userCompany[0].companyName
          } has submitted a proposal on Order #${order?.id?.substring(0, 10)}`,
        };

        await sendNotification(isCustomerSettingExits[0]?.fcmToken, message);

        // save notification
        await notification.create({
          senderId: user.uid,
          userId: order?.userId,
          data: message,
          createdAt: new Date(),
        });
      }

      contextAPI.setLoading(false);

      setSubmitType(config.PROPOSAL);
      setShowSubmitModal(true);
    } catch (err) {
      contextAPI.setLoading(false);
      console.log({err});
      Alert.alert('Error', err.message);
    }
  };

  // fetch
  const fetchCompanyDivers = async () => {
    contextAPI.setLoading(true);
    try {
      const firebase = new FireStoreHelper(FirebaseCollections.Agents);

      const result = await firebase.getByColumn(
        'userId',
        auth().currentUser.uid,
      );

      setDivers(result);
    } catch (err) {
      contextAPI.setLoading(false);
      Alert.alert(err);
    }

    setTimeout(() => {
      contextAPI.setLoading(false);
    }, 500);
  };

  const fetchUserCompany = async () => {
    const user = auth().currentUser;

    const firebase = new FireStoreHelper(FirebaseCollections.Companies);

    const userCompany = await firebase.getByColumn('userId', user.uid);

    setUserCompany(userCompany[0]);
  };

  const fetchProposalDetails = async () => {
    const proposals = new FireStoreHelper(FirebaseCollections.Proposals);

    contextAPI.setLoading(true);

    try {
      const result = await proposals.getByColumn('orderId', order.id);
      setOrderProposal(result[0]);
    } catch (err) {
      console.log({err});
    }

    setTimeout(() => {
      contextAPI.setLoading(false);
    }, 500);
  };

  const checkTheDriverStatus = () => {
    if (order?.driver) {
      setJobDetailStatus(config.ASSIGN_DRIVER);

      if (order?.driver?.checkIn) {
        setRideStatus(config.COMPLETE);
      } else {
        setRideStatus(config.CHECK_IN);
      }
    }
    if (order?.status === ServicesStatus.COMPLETED) {
      setRideStatus(config.RIDE_END);
    }

    if (order?.status === ServicesStatus.CANCELLED) {
      setRideStatus(config.CANCEL);
    }
  };

  const assignDriver = async () => {
    asignDriverBSheetRef.current.close();

    const service = new FireStoreHelper(FirebaseCollections.Services);
    const userSettings = new FireStoreHelper(FirebaseCollections.userSettings);
    const notification = new FireStoreHelper(FirebaseCollections.notifications);
    contextAPI.setLoading(true);

    try {
      await service.update(order.id, {
        driver: {
          userId: selectedDriver?.id || selectedDriver?.userId,
          name: selectedDriver?.name || selectedDriver?.companyName,
          phoneNumber: selectedDriver?.phoneNumber,
          profileImg:
            selectedDriver?.profileImg !== undefined
              ? selectedDriver?.profileImg
              : selectedDriver?.logo || null,
        },
      });

      // send notification to customer
      const user = auth().currentUser;

      const isCustomerSettingExits = await userSettings.getByColumn(
        'userId',
        order?.userId,
      );

      if (isCustomerSettingExits.length > 0) {
        const message = {
          title: `${
            selectedDriver?.name || selectedDriver?.companyName
          } has been assigned`,
          body: `${
            selectedDriver?.name || selectedDriver?.companyName
          } has been assigned to your Order #${order?.id?.substring(0, 10)}`,
        };

        await sendNotification(isCustomerSettingExits[0]?.fcmToken, message);

        // save notification
        await notification.create({
          senderId: user.uid,
          userId: order?.userId,
          data: message,
          createdAt: new Date(),
        });
      }

      setSubmitType(config.ASSIGN);
      setShowSubmitModal(true);
    } catch (err) {
      console.log({err});
    }

    setTimeout(() => {
      contextAPI.setLoading(false);
    }, 500);
  };

  const handleRideStatus = async type => {
    const firebase = new FireStoreHelper(FirebaseCollections.Services);
    const userSettings = new FireStoreHelper(FirebaseCollections.userSettings);
    const notification = new FireStoreHelper(FirebaseCollections.notifications);
    const user = auth().currentUser;

    const isCustomerSettingExits = await userSettings.getByColumn(
      'userId',
      order?.userId,
    );

    let message = {
      title: '',
      body: '',
    };

    if (type === rideStatusType.CheckIn) {
      contextAPI.setLoading(true);

      try {
        await firebase.update(order.id, {
          driver: {
            ...selectedDriver,
            checkIn: true,
          },
        });

        message = {
          title: 'Driver is arrived',
          body: `Driver is arrived for Order #${order?.id?.substring(0, 10)}`,
        };

        setRideStatus(config.COMPLETE);
      } catch (err) {
        Alert.alert('Error', err);
        return;
      }

      setTimeout(() => {
        contextAPI.setLoading(false);
      }, 500);
    }

    if (type === rideStatusType.Complete) {
      Keyboard.dismiss();
      otpVerificationBSheetRef.current.close();

      contextAPI.setLoading(true);

      try {
        await firebase.update(order.id, {
          status: ServicesStatus.COMPLETED,
        });

        setSubmitType(config.COMPLETE);

        message = {
          title: 'Order has been completed',
          body: `Your Order #${order?.id?.substring(
            0,
            10,
          )} has been completed. Thank you`,
        };

        setTimeout(() => {
          setShowSubmitModal(true);
        }, 500);
      } catch (err) {
        Alert.alert('Error', err.message);
        return;
      }

      setTimeout(() => {
        contextAPI.setLoading(false);
      }, 500);
    }

    if (type === rideStatusType.Cancel) {
      Keyboard.dismiss();

      contextAPI.setLoading(true);

      try {
        await firebase.update(order?.id, {
          status: ServicesStatus.CANCELLED,
          cancelReason: cancelReasonValue,
          cancelDescription: otherReason ?? null,
        });

        message = {
          title: 'Order has been cancelled',
          body: `Your Order #${order?.id?.substring(
            0,
            10,
          )} has been cancelled by ${
            selectedDriver?.name || selectedDriver?.companyName
          }. click for more details`,
        };
      } catch (err) {
        Alert.alert('Error', err.message);
        return;
      }

      setRideStatus(config.CANCEL);
      cancelReasonBSheetRef.current.close();

      setTimeout(() => {
        contextAPI.setLoading(false);
      }, 500);
    }

    await sendNotification(isCustomerSettingExits[0]?.fcmToken, message);

    // save notification
    await notification.create({
      senderId: user.uid,
      userId: order?.userId,
      data: message,
      createdAt: new Date(),
    });
  };

  useEffect(() => {
    (async () => {
      await fetchCompanyDivers();
      await fetchUserCompany();
      await fetchProposalDetails();
      checkTheDriverStatus();
    })();
  }, []);

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  const JobDetailsView = () => {
    const createdAtDate = new Date(order?.createdAt.toDate());
    const formattedDate = createdAtDate.toLocaleDateString('en-US', {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric',
    });
    const formattedTime = createdAtDate.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });

    return (
      <View
        style={{
          margin: scale(20),
          marginBottom: scale(15),
        }}>
        <View style={styles.detailsWhiteBox}>
          <View style={{paddingVertical: scale(15)}}>
            <View style={styles.headerItemContainer}>
              <View style={styles.leftHeaderSection}>
                <Text numberOfLines={1} style={styles.titleTxt}>
                  {multiLanguages[contextAPI?.appLang]?.vehicleDetail}
                </Text>
              </View>
              <View style={styles.rightHeaderSection}>
                <Text numberOfLines={1} style={styles.statusTxt}>
                  {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                </Text>
              </View>
            </View>
            <View style={styles.sizeBox} />
            <View
              style={{
                paddingHorizontal: scale(15),
              }}>
              <Text numberOfLines={1} style={styles.subTitleTagTxt}>
                {multiLanguages[contextAPI?.appLang]?.vehicle}
              </Text>
              <Text numberOfLines={1} style={styles.subTitleTxt}>
                {order?.vehicle}
              </Text>
              <View style={styles.sizeBox} />
              <Text numberOfLines={1} style={styles.subTitleTagTxt}>
                {multiLanguages[contextAPI?.appLang]?.brand}
              </Text>
              <Text numberOfLines={1} style={styles.subTitleTxt}>
                {order?.vehicleBrand}
              </Text>
              <View style={styles.sizeBox} />
              <Text numberOfLines={1} style={styles.subTitleTagTxt}>
                {multiLanguages[contextAPI?.appLang]?.registrationNumber}
              </Text>
              <Text numberOfLines={1} style={styles.subTitleTxt}>
                {order?.registrationNo}
              </Text>
              <View style={styles.sizeBox} />
              <Text numberOfLines={1} style={styles.subTitleTagTxt}>
                {multiLanguages[contextAPI?.appLang]?.year}
              </Text>
              <Text numberOfLines={1} style={styles.subTitleTxt}>
                {order?.year}
              </Text>
              <View style={styles.sizeBox} />
              <Text numberOfLines={1} style={styles.subTitleTagTxt}>
                {multiLanguages[contextAPI?.appLang]?.maker}
              </Text>
              <Text numberOfLines={1} style={styles.subTitleTxt}>
                {order?.maker}
              </Text>
            </View>
            <View style={styles.sizeBox} />
            <Divider style={styles.dividerLine} />
            <View style={styles.sizeBox} />
            <View style={styles.headerItemContainer}>
              <View style={styles.leftHeaderSection}>
                <Text numberOfLines={1} style={styles.titleTxt}>
                  {multiLanguages[contextAPI?.appLang]?.location}
                </Text>
              </View>
              <View style={styles.rightHeaderSection}>
                <Image
                  resizeMode="contain"
                  style={styles.mapIcon}
                  source={ImageView.map}
                />
              </View>
            </View>
            <View
              style={{
                paddingHorizontal: scale(15),
              }}>
              <View style={styles.sizeBox} />
              <Text numberOfLines={1} style={styles.subTitleTagTxt}>
                {multiLanguages[contextAPI?.appLang]?.pickup}
              </Text>
              <Text numberOfLines={3} style={styles.subTitleTxt}>
                {/* {'4558 street Name, City Texas 75245'} */}
                {order?.pickUp?.address || '--'}
              </Text>
              <View style={styles.sizeBox} />
              <Text numberOfLines={1} style={styles.subTitleTagTxt}>
                {multiLanguages[contextAPI?.appLang]?.dropOff}
              </Text>
              <Text numberOfLines={3} style={styles.subTitleTxt}>
                {/* {'2464 Royal Ln. Mesa, New Jersey 45463'} */}
                {order?.dropOff?.address || '--'}
              </Text>
            </View>
            <View style={styles.sizeBox} />
            <Divider style={styles.dividerLine} />
            <View style={styles.sizeBox} />
            <View
              style={{
                paddingHorizontal: scale(15),
              }}>
              <Text numberOfLines={1} style={styles.titleTxt}>
                {multiLanguages[contextAPI?.appLang]?.bookingDateTime}
              </Text>
              <View style={styles.sizeBox} />
              <Text numberOfLines={1} style={styles.subTitleTxt}>
                {`${formattedDate} - ${formattedTime}`}
              </Text>
            </View>
            <View style={styles.sizeBox} />
            <Divider style={styles.dividerLine} />
            <View style={styles.sizeBox} />
            <View
              style={{
                paddingHorizontal: scale(15),
              }}>
              <Text numberOfLines={1} style={styles.titleTxt}>
                {multiLanguages[contextAPI?.appLang]?.paymentMethod}
              </Text>
              <View style={styles.sizeBox} />
              <Text numberOfLines={1} style={styles.subTitleTxt}>
                {'Cash'}
              </Text>
            </View>
            <View style={styles.sizeBox} />
            <Divider style={styles.dividerLine} />
            <View style={styles.sizeBox} />
            <View
              style={{
                paddingHorizontal: scale(15),
              }}>
              <Text numberOfLines={1} style={styles.titleTxt}>
                {multiLanguages[contextAPI?.appLang]?.notes}
              </Text>
              <View style={styles.sizeBox} />
              <Text numberOfLines={4} style={styles.subTitleTxt}>
                {order?.contactInfo?.note || '--'}
              </Text>
            </View>
            {jobDetailStatus != config.PROPOSAL && (
              <>
                <View style={styles.sizeBox} />
                <Divider style={styles.dividerLine} />
                <View style={styles.sizeBox} />
                <View
                  style={[
                    styles.priceContainer,
                    {
                      paddingHorizontal: scale(15),
                    },
                  ]}>
                  <Text style={styles.titleTxt}>
                    {multiLanguages[contextAPI?.appLang]?.amount}
                  </Text>
                  <Text numberOfLines={1} style={styles.amountPriceTxt}>
                    {`${orderProposal?.amount ?? '0.00'} MAD`}
                  </Text>
                </View>
                <View style={styles.sizeBox} />
              </>
            )}
          </View>
        </View>
      </View>
    );
  };

  const AssignDetailView = () => (
    <View style={{paddingHorizontal: scale(20)}}>
      <View>
        <Text style={styles.assignTitleTxt}>
          {multiLanguages[contextAPI?.appLang]?.customerInfo}
        </Text>
        <View style={styles.agentItemContainer}>
          <View style={{flex: 0.2}}>
            <Avatar.Image
              style={{backgroundColor: colors.silver}}
              source={ImageView.dummyProfileImg}
              size={scale(44)}
            />
          </View>
          <View style={{flex: 0.55}}>
            <Text numberOfLines={2} style={styles.userText}>
              {order?.contactInfo?.name ?? '--'}
            </Text>
            <View style={{marginVertical: scale(2)}} />
            <Text numberOfLines={1} style={styles.userNumberText}>
              {order?.contactInfo?.phone ?? '--'}
            </Text>
          </View>
          <View style={{flex: 0.25, alignItems: 'flex-end'}}>
            <Pressable
              style={{zIndex: 1}}
              onPress={() => {
                navigation.navigate('MapView', {
                  order: order,
                });
              }}>
              <Image
                resizeMode="contain"
                style={styles.trackIcon}
                source={ImageView.trackIcon}
              />
            </Pressable>
          </View>
        </View>
      </View>
      {jobDetailStatus == config.ASSIGN_DRIVER && (
        <>
          <View style={{marginVertical: scale(10)}} />
          <View>
            <Text style={styles.assignTitleTxt}>
              {multiLanguages[contextAPI?.appLang]?.driverAssign}
            </Text>
            <View style={styles.agentItemContainer}>
              <View style={{flex: 0.2}}>
                <Avatar.Image
                  style={{backgroundColor: colors.silver}}
                  source={
                    selectedDriver?.profileImg
                      ? {uri: selectedDriver?.profileImg}
                      : selectedDriver?.logo
                      ? {uri: selectedDriver?.logo}
                      : ImageView.dummyProfileImg
                  }
                  size={scale(44)}
                />
              </View>
              <View style={{flex: 0.8}}>
                <Text numberOfLines={2} style={styles.userText}>
                  {selectedDriver?.name || selectedDriver?.companyName}
                </Text>
              </View>
            </View>
          </View>
        </>
      )}
      {rideStatus != config.RIDE_END && rideStatus != config.CANCEL && (
        <>
          <View style={styles.sizeBox} />
          <View style={styles.sizeBox} />
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <ButtonComponent
              onBtnPress={() => {
                if (rideStatus == config.COMPLETE) {
                  // setOtpCode('');
                  // otpVerificationBSheetRef.current.open();
                  handleRideStatus(config.COMPLETE);
                } else if (
                  jobDetailStatus == config.ASSIGN &&
                  rideStatus == ''
                ) {
                  asignDriverBSheetRef.current.open();
                } else {
                  handleRideStatus(config.CHECK_IN);
                }
              }}
              container={{
                flex: 0.48,
                backgroundColor:
                  rideStatus == config.CHECK_IN
                    ? colors.green
                    : colors.darkBlue,
                borderRadius:
                  jobDetailStatus !== config.ASSIGN_DRIVER ? scale(50) : 9,
              }}
              btnLabel={
                jobDetailStatus !== config.ASSIGN_DRIVER
                  ? multiLanguages[contextAPI?.appLang]?.assign
                  : rideStatus == config.CHECK_IN
                  ? multiLanguages[contextAPI?.appLang]?.checkIn
                  : multiLanguages[contextAPI?.appLang]?.completed
              }
            />
            <ButtonComponent
              container={[
                styles.cancelBtnContainer,
                {
                  flex: 0.48,
                  borderRadius:
                    jobDetailStatus !== config.ASSIGN_DRIVER ? scale(50) : 9,
                },
              ]}
              btnLabelTxt={{color: colors.warning}}
              onBtnPress={() => {
                cancelReasonBSheetRef.current.open();
              }}
              btnLabel={multiLanguages[contextAPI?.appLang]?.cancel}
            />
          </View>
        </>
      )}
    </View>
  );

  const AssignDriverView = () => (
    <View>
      <View style={styles.assignHeaderContainer}>
        <Text style={styles.sendProposalTxt}>
          {multiLanguages[contextAPI?.appLang]?.assignDriver}
        </Text>
      </View>
      <View>
        <Text
          style={[
            styles.assignTitleTxt,
            {
              marginLeft: scale(20),
              fontFamily: appFonts.hankenGroteskSemiBold,
            },
          ]}>
          {multiLanguages[contextAPI?.appLang]?.mySelf}
        </Text>
        <Pressable
          style={[
            styles.agentItemContainer,
            {borderRadius: 14, marginHorizontal: scale(20)},
          ]}
          onPress={() => {
            setSelectedDriver(userCompany);
          }}>
          <View style={{flex: 0.2}}>
            <Avatar.Image
              style={{backgroundColor: colors.silver}}
              source={
                userCompany?.logo
                  ? {uri: userCompany?.logo}
                  : ImageView.dummyImg
              }
              size={scale(42)}
            />
          </View>
          <View style={{flex: 0.6}}>
            <Text numberOfLines={2} style={styles.userText}>
              {userCompany?.companyName ?? '--'}
            </Text>
          </View>
          <View style={{flex: 0.2, alignItems: 'flex-end'}}>
            <Image
              style={styles.checkIcon}
              source={
                selectedDriver && selectedDriver == userCompany
                  ? ImageView.checkedRoundSecond
                  : ImageView.uncheckedRoundSecond
              }
            />
          </View>
        </Pressable>
      </View>
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View>
        <Text
          style={[
            styles.assignTitleTxt,
            {
              marginLeft: scale(20),
              fontFamily: appFonts.hankenGroteskSemiBold,
            },
          ]}>
          {multiLanguages[contextAPI?.appLang]?.availableDriver}
        </Text>
        <FlatList
          scrollEnabled={true}
          contentContainerStyle={{
            paddingVertical: scale(15),
          }}
          data={divers}
          keyExtractor={item => item?.id}
          showsVerticalScrollIndicator={false}
          ItemSeparatorComponent={() => (
            <View style={{marginVertical: scale(5)}} />
          )}
          renderItem={renderDriverListItem}
        />
      </View>
      <View style={styles.sizeBox} />
      <View style={{paddingBottom: scale(20)}}>
        <ButtonComponent
          onBtnPress={assignDriver}
          btnLabel={multiLanguages[contextAPI?.appLang]?.assign}
        />
      </View>
    </View>
  );

  const renderDriverListItem = ({item}) => (
    <Pressable
      style={[
        styles.agentItemContainer,
        {borderRadius: 14, marginTop: 0, marginHorizontal: scale(20)},
      ]}
      onPress={() => {
        setSelectedDriver(item);
      }}>
      <View style={{flex: 0.2}}>
        <Avatar.Image
          style={{backgroundColor: colors.silver}}
          source={
            item?.profileImg
              ? {uri: item?.profileImg}
              : ImageView.dummyProfileImg
          }
          size={scale(42)}
        />
      </View>
      <View style={{flex: 0.6}}>
        <Text numberOfLines={2} style={styles.userText}>
          {item?.name}
        </Text>
      </View>
      <View style={{flex: 0.2, alignItems: 'flex-end'}}>
        <Image
          style={styles.checkIcon}
          source={
            selectedDriver && selectedDriver?.id == item?.id
              ? ImageView.checkedRoundSecond
              : ImageView.uncheckedRoundSecond
          }
        />
      </View>
    </Pressable>
  );

  const AddProposalView = () => (
    <View>
      <View style={styles.assignHeaderContainer}>
        <Text style={styles.sendProposalTxt}>
          {multiLanguages[contextAPI?.appLang]?.sendProposal}
        </Text>
      </View>
      <View style={styles.sizeBox} />
      <TextInputComponent
        placeholder={multiLanguages[contextAPI?.appLang]?.enterAmount}
        value={enterAmount}
        inputTxtStyl={{
          fontFamily: Validation.isEmpty(enterAmount)
            ? appFonts.hankenGroteskRegular
            : appFonts.hankenGroteskMedium,
        }}
        keyboardType={'number-pad'}
        container={
          inputFocus == multiLanguages[contextAPI?.appLang]?.enterAmount &&
          styles.activeTextInput
        }
        onFocus={() => {
          setInputFocus(multiLanguages[contextAPI?.appLang]?.enterAmount);
        }}
        onBlur={() => {
          setInputFocus('');
        }}
        onChangeText={text => setEnterAmount(text)}
        onSubmitEditing={() => {
          Keyboard.dismiss();
        }}
        returnKeyType={'done'}
      />
      <View style={{padding: scale(20)}}>
        <Text style={styles.commitionMsgTxt}>
          {'You will get 285 after completing job and 15 will be for admin'}
        </Text>
      </View>
      <View style={{paddingBottom: scale(20)}}>
        <ButtonComponent
          onBtnPress={submitProposal}
          btnLabel={multiLanguages[contextAPI?.appLang]?.submitProposal}
        />
      </View>
    </View>
  );

  const ModalContentView = () => (
    <View style={styles.modalContainer}>
      <View style={styles.centerIconContainer}>
        <Image
          resizeMode="contain"
          style={styles.successIcon}
          source={ImageView.success}
        />
      </View>
      <View
        display={submitType == config.PROPOSAL ? 'flex' : 'none'}
        style={{marginTop: scale(20)}}>
        <Text style={styles.succesMsgTxt}>
          {multiLanguages[contextAPI?.appLang]?.successProposalMsg}
        </Text>
        <Text style={styles.takeCalmMsgTxt}>
          {multiLanguages[contextAPI?.appLang]?.nowStayCalm}
        </Text>
        <Text
          suppressHighlighting
          onPress={() => {
            setShowSubmitModal(false);
            setTimeout(() => {
              navigation.goBack();
            }, 500);
          }}
          style={styles.thankMsgTxt}>
          {multiLanguages[contextAPI?.appLang]?.thankMsg}
        </Text>
      </View>
      <View
        display={
          submitType == config.ASSIGN || submitType == config.COMPLETE
            ? 'flex'
            : 'none'
        }
        style={{marginTop: scale(20)}}>
        <Text style={styles.assignMsgTxt}>
          {submitType == config.COMPLETE
            ? multiLanguages[contextAPI?.appLang]?.jobCompleteMsg
            : multiLanguages[contextAPI?.appLang]?.driverAssignedMsg}
        </Text>
        <View style={styles.sizeBox} />
        <View style={styles.sizeBox} />
        <Text
          suppressHighlighting
          onPress={() => {
            if (submitType == config.ASSIGN) {
              setJobDetailStatus(config.ASSIGN_DRIVER);
              setRideStatus(config.CHECK_IN);
            } else {
              setRideStatus(config.RIDE_END);
            }
            setShowSubmitModal(false);
          }}
          style={[
            styles.thankMsgTxt,
            {
              fontFamily: appFonts.hankenGroteskBold,
              textDecorationLine: 'underline',
            },
          ]}>
          {multiLanguages[contextAPI?.appLang]?.thanks}
        </Text>
      </View>
    </View>
  );

  const OTPVerificationView = () => (
    <View>
      <View
        style={{
          paddingVertical: scale(10),
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Text style={styles.enterOtpTxt}>
          {multiLanguages[contextAPI?.appLang]?.plsEnterOTP}
        </Text>
      </View>
      <View style={{paddingVertical: scale(10)}}>
        <OTPTextInput
          tintColor={colors.primaryColor}
          offTintColor={colors.softPeach}
          handleTextChange={text => setOtpCode(text)}
          defaultValue={otpCode}
          inputCount={6}
          selectionColor={colors.primaryColor}
          cursorColor={colors.primaryColor}
          containerStyle={{
            marginHorizontal: scale(15),
          }}
          textInputStyle={styles.textInputStyle}
          ref={otpRef}
        />
      </View>
      <View style={{paddingHorizontal: scale(20)}}>
        <Text style={styles.noteMesgTxt}>
          {multiLanguages[contextAPI?.appLang]?.notesTag}
          <Text
            style={[
              styles.noteMesgTxt,
              {
                fontFamily: appFonts.hankenGroteskRegular,
                color: '#000000B2',
              },
            ]}>
            {multiLanguages[contextAPI?.appLang]?.noteDesc}
          </Text>
        </Text>
      </View>
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <ButtonComponent
        onBtnPress={() => {
          handleRideStatus(config.COMPLETE);
        }}
        btnLabel={multiLanguages[contextAPI?.appLang]?.submitOTP}
      />
    </View>
  );

  const CancelReasonView = () => (
    <View style={{flex: 1}}>
      <View
        style={{
          paddingVertical: scale(10),
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Text style={styles.enterOtpTxt}>
          {multiLanguages[contextAPI?.appLang]?.cancelReason}
        </Text>
      </View>
      <View style={{paddingHorizontal: scale(20), paddingVertical: scale(10)}}>
        <View>
          <Pressable
            onPress={() => {
              if (selectedReason == '1') setSelectedReason('');
              else {
                setSelectedReason('1');
                setCancelReasonValue(
                  multiLanguages[contextAPI?.appLang]?.feelingNotwell,
                );
              }
            }}
            style={styles.cancelReasonItemContianer}>
            <View style={{flex: 0.8}}>
              <Text numberOfLines={2} style={styles.reasonText}>
                {multiLanguages[contextAPI?.appLang]?.feelingNotwell}
              </Text>
            </View>
            <View style={{flex: 0.2, alignItems: 'flex-end'}}>
              <Image
                style={styles.checkIcon}
                source={
                  selectedReason == '1'
                    ? ImageView.checkedRoundSecond
                    : ImageView.uncheckedRoundSecond
                }
              />
            </View>
          </Pressable>
          <Divider style={styles.dividerLine} />
        </View>
        <View>
          <Pressable
            onPress={() => {
              if (selectedReason == '2') setSelectedReason('');
              else {
                setSelectedReason('2');
                setCancelReasonValue(
                  multiLanguages[contextAPI?.appLang]?.personalEmergency,
                );
              }
            }}
            style={styles.cancelReasonItemContianer}>
            <View style={{flex: 0.8}}>
              <Text numberOfLines={2} style={styles.reasonText}>
                {multiLanguages[contextAPI?.appLang]?.personalEmergency}
              </Text>
            </View>
            <View style={{flex: 0.2, alignItems: 'flex-end'}}>
              <Image
                style={styles.checkIcon}
                source={
                  selectedReason == '2'
                    ? ImageView.checkedRoundSecond
                    : ImageView.uncheckedRoundSecond
                }
              />
            </View>
          </Pressable>
          <Divider style={styles.dividerLine} />
        </View>
        <View>
          <Pressable
            onPress={() => {
              if (selectedReason == '3') setSelectedReason('');
              else {
                setSelectedReason('3');
                setCancelReasonValue(
                  multiLanguages[contextAPI?.appLang]?.distanceFarOut,
                );
              }
            }}
            style={styles.cancelReasonItemContianer}>
            <View style={{flex: 0.8}}>
              <Text numberOfLines={2} style={styles.reasonText}>
                {multiLanguages[contextAPI?.appLang]?.distanceFarOut}
              </Text>
            </View>
            <View style={{flex: 0.2, alignItems: 'flex-end'}}>
              <Image
                style={styles.checkIcon}
                source={
                  selectedReason == '3'
                    ? ImageView.checkedRoundSecond
                    : ImageView.uncheckedRoundSecond
                }
              />
            </View>
          </Pressable>
          <Divider style={styles.dividerLine} />
        </View>
        <View>
          <Pressable
            onPress={() => {
              if (selectedReason == '4') setSelectedReason('');
              else {
                setSelectedReason('4');
                setCancelReasonValue(
                  multiLanguages[contextAPI?.appLang]?.somethingElse,
                );
              }
            }}
            style={styles.cancelReasonItemContianer}>
            <View style={{flex: 0.8}}>
              <Text numberOfLines={2} style={styles.reasonText}>
                {multiLanguages[contextAPI?.appLang]?.somethingElse}
              </Text>
            </View>
            <View style={{flex: 0.2, alignItems: 'flex-end'}}>
              <Image
                style={styles.checkIcon}
                source={
                  selectedReason == '4'
                    ? ImageView.checkedRoundSecond
                    : ImageView.uncheckedRoundSecond
                }
              />
            </View>
          </Pressable>
          <Divider style={styles.dividerLine} />
        </View>
        <View>
          <Pressable
            onPress={() => {
              if (selectedReason == '5') setSelectedReason('');
              else {
                setSelectedReason('5');
                setCancelReasonValue(
                  multiLanguages[contextAPI?.appLang]?.currentlynvoledAccident,
                );
              }
            }}
            style={styles.cancelReasonItemContianer}>
            <View style={{flex: 0.8}}>
              <Text numberOfLines={2} style={styles.reasonText}>
                {multiLanguages[contextAPI?.appLang]?.currentlynvoledAccident}
              </Text>
            </View>
            <View style={{flex: 0.2, alignItems: 'flex-end'}}>
              <Image
                style={styles.checkIcon}
                source={
                  selectedReason == '5'
                    ? ImageView.checkedRoundSecond
                    : ImageView.uncheckedRoundSecond
                }
              />
            </View>
          </Pressable>
          <Divider style={styles.dividerLine} />
        </View>
        <View>
          <Pressable
            onPress={() => {
              if (selectedReason == '6') setSelectedReason('');
              else {
                setSelectedReason('6');
                setCancelReasonValue(
                  multiLanguages[contextAPI?.appLang]?.other,
                );
              }
            }}
            style={styles.cancelReasonItemContianer}>
            <View style={{flex: 0.8}}>
              <Text numberOfLines={2} style={styles.reasonText}>
                {multiLanguages[contextAPI?.appLang]?.other}
              </Text>
            </View>
            <View style={{flex: 0.2, alignItems: 'flex-end'}}>
              <Image
                style={styles.checkIcon}
                source={
                  selectedReason == '6'
                    ? ImageView.checkedRoundSecond
                    : ImageView.uncheckedRoundSecond
                }
              />
            </View>
          </Pressable>
          <Divider style={styles.dividerLine} />
        </View>
        <View style={styles.sizeBox} />
        <View style={styles.sizeBox} />
        <TextInputComponent
          textAlignVertical="top"
          multiline={true}
          placeholder={multiLanguages[contextAPI?.appLang]?.epxlainOther}
          value={otherReason}
          inputTxtStyl={{
            paddingVertical: scale(12),
            height: scale(140),
          }}
          container={[
            {
              marginHorizontal: 0,
              paddingHorizontal: scale(12),
              borderRadius: 15,
              shadowColor: '#000000',
              shadowOffset: {
                width: 0,
                height: 3,
              },
              shadowOpacity: 0.17,
              shadowRadius: 3.05,
              elevation: 4,
            },
          ]}
          onChangeText={text => setOtherReason(text)}
        />
      </View>
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <ButtonComponent
        onBtnPress={() => {
          handleRideStatus(config.CANCEL);
        }}
        btnLabel={multiLanguages[contextAPI?.appLang]?.cancelledNow}
      />
    </View>
  );

  return (
    <View style={styles.container}>
      <HeaderComponent
        leftIconPress={() => {
          navigation.goBack();
        }}
        leftIcon={ImageView.backIconSecond}
        centerTxt={orderTypeMapping(order.type)}
        centerSubTxt={`# ${order.id.substring(0, 10)}`}
      />
      <Modal
        animationIn={'fadeIn'}
        animationOut={'fadeOut'}
        isVisible={showSubmitModal}
        backdropOpacity={0.5}
        style={{
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        {ModalContentView()}
      </Modal>
      <RBSheet
        ref={cancelReasonBSheetRef}
        height={verticalScale(450)}
        dragFromTopOnly
        closeOnDragDown
        openDuration={250}
        customStyles={{
          container: {
            borderTopEndRadius: 35,
            borderTopStartRadius: 35,
          },
          draggableIcon: {
            top: scale(5),
            backgroundColor: colors.silver,
            height: scale(6),
            borderRadius: 13,
            width: scale(70),
          },
        }}>
        <KeyboardAwareScrollView
          bounces={false}
          keyboardShouldPersistTaps="always"
          contentContainerStyle={{flexGrow: 1, paddingBottom: scale(20)}}
          showsVerticalScrollIndicator={false}>
          {CancelReasonView()}
        </KeyboardAwareScrollView>
      </RBSheet>
      <RBSheet
        ref={otpVerificationBSheetRef}
        height={verticalScale(300)}
        dragFromTopOnly
        closeOnDragDown
        openDuration={250}
        customStyles={{
          container: {
            borderTopEndRadius: 35,
            borderTopStartRadius: 35,
          },
          draggableIcon: {
            top: scale(5),
            backgroundColor: colors.silver,
            height: scale(6),
            borderRadius: 13,
            width: scale(70),
          },
        }}>
        <KeyboardAwareScrollView
          bounces={false}
          keyboardShouldPersistTaps="always"
          showsVerticalScrollIndicator={false}>
          {OTPVerificationView()}
        </KeyboardAwareScrollView>
      </RBSheet>
      <RBSheet
        ref={asignDriverBSheetRef}
        height={verticalScale(500)}
        dragFromTopOnly
        closeOnDragDown
        openDuration={250}
        customStyles={{
          container: {
            borderTopEndRadius: 35,
            borderTopStartRadius: 35,
          },
          draggableIcon: {
            top: scale(5),
            backgroundColor: colors.silver,
            height: scale(6),
            borderRadius: 13,
            width: scale(70),
          },
        }}>
        <ScrollView
          bounces={false}
          keyboardShouldPersistTaps="always"
          contentContainerStyle={{flexGrow: 1}}
          showsVerticalScrollIndicator={false}>
          {AssignDriverView()}
        </ScrollView>
      </RBSheet>
      <RBSheet
        ref={proposalBSheetRef}
        height={verticalScale(300)}
        dragFromTopOnly
        closeOnDragDown
        openDuration={250}
        customStyles={{
          container: {
            borderTopEndRadius: 35,
            borderTopStartRadius: 35,
          },
          draggableIcon: {
            top: scale(5),
            backgroundColor: colors.silver,
            height: scale(6),
            borderRadius: 13,
            width: scale(70),
          },
        }}>
        <KeyboardAwareScrollView
          bounces={false}
          keyboardShouldPersistTaps="always"
          showsVerticalScrollIndicator={false}>
          {AddProposalView()}
        </KeyboardAwareScrollView>
      </RBSheet>
      <ScrollView
        bounces={false}
        contentContainerStyle={{flexGrow: 1, paddingBottom: scale(20)}}
        keyboardShouldPersistTaps="always"
        showsVerticalScrollIndicator={false}>
        {JobDetailsView()}
        {(jobDetailStatus == config.ASSIGN ||
          jobDetailStatus == config.ASSIGN_DRIVER) &&
          AssignDetailView()}
        {jobDetailStatus == config.PROPOSAL && (
          <ButtonComponent
            onBtnPress={() => {
              setEnterAmount('');
              proposalBSheetRef.current.open();
            }}
            btnLabel={multiLanguages[contextAPI?.appLang]?.submitProposal}
          />
        )}
        {rideStatus != config.CANCEL &&
          jobDetailStatus == config.APPROVAL_WAIT && (
            <>
              <ButtonComponent
                container={[
                  styles.cancelBtnContainer,
                  {
                    marginTop: scale(10),
                  },
                ]}
                btnLabelTxt={{color: colors.warning}}
                onBtnPress={() => {
                  cancelReasonBSheetRef.current.open();
                }}
                btnLabel={multiLanguages[contextAPI?.appLang]?.cancel}
              />
              <View
                style={{
                  marginVertical: scale(20),
                }}>
                <Text style={styles.waitMsgTxt}>
                  {multiLanguages[contextAPI?.appLang]?.waitingForApproval}
                </Text>
              </View>
            </>
          )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  detailsWhiteBox: {
    borderRadius: 7,
    backgroundColor: colors.white,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
  },
  headerItemContainer: {
    paddingHorizontal: scale(15),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  leftHeaderSection: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    paddingRight: scale(5),
  },
  rightHeaderSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  statusTxt: {
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(16),
    textAlign: 'right',
    color: '#978800',
  },
  dividerLine: {
    width: '100%',
    height: 1,
    backgroundColor: colors.black,
    opacity: 0.1,
  },
  sizeBox: {
    marginVertical: scale(5),
  },
  titleTxt: {
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(16),
    color: colors.primaryColor,
  },
  amountPriceTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.black,
  },
  subTitleTagTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(14),
    color: colors.black,
    opacity: 0.5,
  },
  subTitleTxt: {
    marginTop: scale(5),
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(14),
    color: colors.black,
    opacity: 0.9,
  },
  waitMsgTxt: {
    marginHorizontal: scale(20),
    textAlign: 'center',
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(26),
    color: colors.black,
    opacity: 0.2,
    lineHeight: scale(40),
  },
  mapIcon: {
    width: scale(22),
    height: scale(22),
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  activeTextInput: {
    borderColor: colors.secondaryColor,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.17,
    shadowRadius: 2.54,
    elevation: 3,
  },
  cancelBtnContainer: {
    backgroundColor: colors.white,
    borderColor: colors.warning,
    borderWidth: 1,
    borderRadius: scale(50),
    height: scale(50),
    width: scale(200),
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
  },
  assignHeaderContainer: {
    paddingVertical: scale(10),
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendProposalTxt: {
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(18),
    color: colors.black,
    textAlign: 'center',
  },
  commitionMsgTxt: {
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(18),
    color: colors.black,
    opacity: 0.8,
    lineHeight: scale(29),
    textAlign: 'center',
  },
  modalContainer: {
    borderRadius: 20,
    padding: scale(20),
    backgroundColor: colors.white,
    width: '90%',
  },
  centerIconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  successIcon: {
    width: scale(100),
    height: scale(100),
  },
  succesMsgTxt: {
    textAlign: 'center',
    fontSize: moderateScale(18),
    fontFamily: appFonts.hankenGroteskBold,
    color: colors.black,
  },
  assignMsgTxt: {
    textAlign: 'center',
    fontSize: moderateScale(18),
    fontFamily: appFonts.hankenGroteskSemiBold,
    color: colors.blackRussian,
  },
  takeCalmMsgTxt: {
    textAlign: 'center',
    fontSize: moderateScale(15),
    fontFamily: appFonts.hankenGroteskMedium,
    color: colors.black,
    opacity: 0.8,
    marginVertical: scale(10),
  },
  thankMsgTxt: {
    textAlign: 'center',
    fontSize: moderateScale(16),
    fontFamily: appFonts.hankenGroteskSemiBold,
    color: colors.primaryColor,
  },
  assignTitleTxt: {
    marginLeft: scale(15),
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(16),
    color: colors.primaryColor,
  },
  agentItemContainer: {
    backgroundColor: colors.white,
    padding: scale(15),
    marginTop: scale(15),
    borderRadius: 10,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
    flexDirection: 'row',
    alignItems: 'center',
  },
  userText: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.lightBlue,
  },
  userNumberText: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(12),
    opacity: 0.8,
    color: colors.black,
  },
  trackIcon: {
    width: scale(65),
    height: scale(20),
  },
  checkIcon: {
    width: scale(20),
    height: scale(20),
  },
  enterOtpTxt: {
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(18),
    color: colors.black,
    textAlign: 'center',
  },
  textInputStyle: {
    backgroundColor: colors.transparent,
    borderRadius: 12,
    height: scale(50),
    marginLeft: 0,
    width: scale(50),
    color: colors.primaryColor,
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(24),
    borderWidth: 1,
    borderBottomWidth: 1,
    borderColor: colors.softPeach,
  },
  noteMesgTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.red,
    lineHeight: scale(24),
  },
  cancelReasonItemContianer: {
    backgroundColor: colors.white,
    paddingBottom: scale(15),
    marginTop: scale(15),
    flexDirection: 'row',
    alignItems: 'center',
  },
  reasonText: {
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(16),
    color: colors.black,
  },
});

export default JobDetail;
