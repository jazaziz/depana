import React, {useContext, useRef, useState} from 'react';
import {
  StyleSheet,
  Image,
  View,
  Text,
  Keyboard,
  Pressable,
  SafeAreaView,
  Alert,
} from 'react-native';

import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {CountryPicker} from 'react-native-country-codes-picker';
import {useBackHandler} from '@react-native-community/hooks';
import RBSheet from 'react-native-raw-bottom-sheet';
import OTPTextInput from 'react-native-otp-textinput';

import TextInputComponent from '../../components/TextInputComponent';
import HeaderComponent from '../../components/HeaderComponent';
import ButtonComponent from '../../components/ButtonComponent';

import {colors} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import appFonts from '../../utils/appFonts';
import Validation from '../../utils/validation';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';
import {formatePhoneNumber} from '../../utils/helpers';
import auth from '@react-native-firebase/auth';

const ChangeMobileNumber = ({navigation}) => {
  const [inputFocus, setInputFocus] = useState('');
  const [pNumber, setPNumber] = useState('');
  const [countryCode, setCountryCode] = useState('+1');
  const [showCountryPicker, setShowCountryPicker] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [disbaleResend, setDisbaleResend] = useState(false);
  const [verification, setVerification] = useState(null);

  const contextAPI = useContext(ContextAPI);

  const refRBSheet = useRef();
  const otpRef = useRef('');

  useBackHandler(() => {
    Keyboard.dismiss();
    navigation.goBack();
    return true;
  });

  const onSelect = item => {
    setCountryCode(item.dial_code);
    setShowCountryPicker(false);
  };

  const handleSave = async () => {
    Keyboard.dismiss();

    contextAPI.setLoading(true);

    const formatePhone = formatePhoneNumber(pNumber, countryCode);

    try {
      const confirmation = await auth().signInWithPhoneNumber(formatePhone);
      setVerification(confirmation.verificationId);
      setDisbaleResend(false);
      refRBSheet.current.open();
    } catch (err) {
      contextAPI.setLoading(false);
      Alert.alert('Error', err.message);
    }

    contextAPI.setLoading(false);
  };

  const handleConfirm = async () => {
    Keyboard.dismiss();
    contextAPI.setLoading(true);

    if (!!otpCode) {
      Alert.alert('Error', 'Please Enter OTP');
      return;
    }

    try {
      const credential = auth.PhoneAuthProvider.credential(
        verification,
        otpCode,
      );
      await auth().currentUser.updatePhoneNumber(credential);

      refRBSheet.current.close();
      setTimeout(() => {
        navigation.goBack();
      }, 500);
    } catch (error) {
      contextAPI.setLoading(false);
      Alert.alert('Error', error.message);
    }
    contextAPI.setLoading(false);
  };

  const disableResendBtnHandler = () => {
    otpRef.current.clear();
    setDisbaleResend(true);
    setTimeout(() => {
      setDisbaleResend(false);
    }, 60000);
  };

  const UserInputView = () => (
    <View
      style={{
        paddingVertical: scale(20),
      }}>
      <View style={{marginTop: scale(20)}}>{InputTextView()}</View>
    </View>
  );

  const InputTextView = () => (
    <View style={{}}>
      <Text style={styles.authTypeTxt}>
        {multiLanguages[contextAPI?.appLang]?.cNumber}
      </Text>
      <View style={styles.sizeBox} />
      <Text style={styles.authTypeMsgTxt}>
        {multiLanguages[contextAPI?.appLang]?.cNumberMsg}
      </Text>
      <View style={styles.sizeBox} />
      <View style={{paddingVertical: scale(20)}}>
        <TextInputComponent
          placeholder={multiLanguages[contextAPI?.appLang]?.mNumber}
          value={pNumber}
          container={
            inputFocus == multiLanguages[contextAPI?.appLang]?.mNumber &&
            styles.activeTextInput
          }
          inputTxtStyl={[
            styles.inputTxtStyl,
            {
              fontFamily: Validation.isEmpty(pNumber)
                ? appFonts.hankenGroteskRegular
                : appFonts.hankenGroteskMedium,
            },
          ]}
          onFocus={() => {
            setInputFocus(multiLanguages[contextAPI?.appLang]?.mNumber);
          }}
          onBlur={() => {
            setInputFocus('');
          }}
          keyboardType="number-pad"
          onChangeText={text => setPNumber(text)}
          onSubmitEditing={() => {
            Keyboard.dismiss();
          }}
          returnKeyType={'done'}
          leftCustomIcon={LeftCustomIcon()}
        />
      </View>
      <View style={styles.sizeBox} />
      <ButtonComponent
        onBtnPress={handleSave}
        btnLabel={multiLanguages[contextAPI?.appLang]?.save}
      />
    </View>
  );

  const LeftCustomIcon = () => (
    <Pressable
      onPress={() => {
        Keyboard.dismiss();
        setShowCountryPicker(true);
      }}
      style={styles.customIconContainer}>
      <Text
        style={[
          styles.countryCodeTxt,
          {
            color:
              inputFocus !== multiLanguages[contextAPI?.appLang]?.mNumber
                ? colors.grayDark
                : colors.black,
          },
        ]}>
        {countryCode}
      </Text>
      <Image
        resizeMode="contain"
        style={[
          styles.downArrowIcon,
          {
            tintColor:
              inputFocus !== multiLanguages[contextAPI?.appLang]?.mNumber
                ? colors.grayDark
                : null,
          },
        ]}
        source={ImageView.downArrow}
      />
    </Pressable>
  );

  const OTPVerificationView = () => (
    <View>
      <View
        style={{
          paddingVertical: scale(10),
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Text style={styles.enterOtpTxt}>
          {multiLanguages[contextAPI?.appLang]?.plsEnterOTP}
        </Text>
        <Text style={styles.authTypeMsgTxt}>
          {multiLanguages[contextAPI?.appLang]?.otpVerificationMessg}
          <Text style={styles.mNumberTxt}> {countryCode + ' ' + pNumber}</Text>
        </Text>
      </View>
      <View style={{paddingVertical: scale(10)}}>
        <OTPTextInput
          tintColor={colors.primaryColor}
          offTintColor={colors.softPeach}
          handleTextChange={text => setOtpCode(text)}
          defaultValue={otpCode}
          inputCount={6}
          selectionColor={colors.primaryColor}
          cursorColor={colors.primaryColor}
          containerStyle={{
            marginHorizontal: scale(10),
          }}
          textInputStyle={styles.textInputStyle}
          ref={otpRef}
        />
      </View>
      <Text
        suppressHighlighting
        onPress={() => {
          !disbaleResend && disableResendBtnHandler();
        }}
        style={[
          styles.resendCodeTxt,
          {
            color: disbaleResend ? colors.grayDark : colors.primaryColor,
          },
        ]}>
        {multiLanguages[contextAPI?.appLang]?.resendCode}
      </Text>
      <View style={styles.sizeBox} />
      <ButtonComponent
        onBtnPress={handleConfirm}
        btnLabel={multiLanguages[contextAPI?.appLang]?.confirmNow}
      />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
    </View>
  );

  return (
    <View style={styles.container}>
      <HeaderComponent
        leftIconPress={() => {
          navigation.goBack();
        }}
        leftIcon={ImageView.backIconSecond}
        centerTxt={multiLanguages[contextAPI?.appLang]?.CMobileNumberSecond}
      />
      <RBSheet
        ref={refRBSheet}
        height={verticalScale(300)}
        dragFromTopOnly
        closeOnDragDown
        openDuration={250}
        customStyles={{
          container: {
            borderTopEndRadius: 35,
            borderTopStartRadius: 35,
          },
          draggableIcon: {
            top: scale(5),
            backgroundColor: colors.silver,
            height: scale(6),
            borderRadius: 13,
            width: scale(70),
          },
        }}>
        <KeyboardAwareScrollView
          bounces={false}
          keyboardShouldPersistTaps="always"
          showsVerticalScrollIndicator={false}>
          {OTPVerificationView()}
        </KeyboardAwareScrollView>
      </RBSheet>
      <CountryPicker
        enableModalAvoiding
        show={showCountryPicker}
        onBackdropPress={() => {
          setShowCountryPicker(false);
        }}
        onRequestClose={() => {
          setShowCountryPicker(false);
        }}
        pickerButtonOnPress={item => onSelect(item)}
        style={styles.countryPickerStyl}
      />
      <KeyboardAwareScrollView
        bounces={false}
        keyboardShouldPersistTaps="always"
        showsVerticalScrollIndicator={false}>
        {UserInputView()}
      </KeyboardAwareScrollView>
      <SafeAreaView style={{flex: 0, backgroundColor: colors.white}} />
    </View>
  );
};

const styles = StyleSheet.create({
  countryPickerStyl: {
    // Styles for whole modal [View]
    modal: {
      height: verticalScale(300),
    },
    // Styles for input [TextInput]
    textInput: {
      height: scale(50),
      borderRadius: 10,
      paddingHorizontal: scale(25),
    },
    // Styles for country button [TouchableOpacity]
    countryButtonStyles: {
      height: scale(50),
      borderRadius: 10,
    },
    dialCode: {
      fontSize: moderateScale(13),
      fontFamily: appFonts.interRegular,
    },
    // Country name styles [Text]
    countryName: {
      fontSize: moderateScale(13),
      fontFamily: appFonts.interRegular,
    },
  },
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  authTypeTxt: {
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(26),
    color: colors.primaryColor,
    textAlign: 'center',
  },
  authTypeMsgTxt: {
    paddingHorizontal: scale(5),
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(16),
    color: colors.suvaGrey,
    textAlign: 'center',
    lineHeight: scale(27),
    paddingHorizontal: scale(20),
  },
  customIconContainer: {
    marginEnd: scale(10),
    height: scale(25),
    alignItems: 'center',
    flexDirection: 'row',
  },
  downArrowIcon: {
    marginLeft: scale(10),
    width: scale(20),
    height: scale(20),
  },
  countryCodeTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(16),
  },
  activeTextInput: {
    borderColor: colors.secondaryColor,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.17,
    shadowRadius: 2.54,
    elevation: 3,
  },
  sizeBox: {
    marginVertical: scale(5),
  },
  inputTxtStyl: {
    color: colors.primaryColor,
    fontSize: moderateScale(16),
  },
  enterOtpTxt: {
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(18),
    color: colors.black,
    textAlign: 'center',
  },
  mNumberTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.secondaryColor,
    textAlign: 'center',
  },
  textInputStyle: {
    backgroundColor: colors.transparent,
    borderRadius: 12,
    height: scale(50),
    marginLeft: 0,
    width: scale(50),
    color: colors.primaryColor,
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(24),
    borderWidth: 1,
    borderBottomWidth: 1,
    borderColor: colors.softPeach,
  },
  resendCodeTxt: {
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(16),
    color: colors.primaryColor,
    textAlign: 'center',
  },
});

export default ChangeMobileNumber;
