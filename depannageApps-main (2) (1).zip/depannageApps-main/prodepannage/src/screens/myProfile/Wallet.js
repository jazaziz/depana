import React, {useContext, useState} from 'react';
import {
  Image,
  ImageBackground,
  StyleSheet,
  Text,
  View,
  FlatList,
  Pressable,
} from 'react-native';

import {moderateScale, scale} from 'react-native-size-matters';
import {Avatar} from 'react-native-paper';
import {useBackHandler} from '@react-native-community/hooks';

import HeaderComponent from '../../components/HeaderComponent';
import EmptyMessageComponent from '../../components/EmptyMessageComponent';

import {colors} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import {multiLanguages} from '../../utils/multiLanguages';
import {ContextAPI} from '../../contextAPI/contextProvider';
import appFonts from '../../utils/appFonts';

const Wallet = ({navigation}) => {
  const [paymentHistoryListData, setPaymentHistoryListData] = useState(
    Array(20).fill(),
  );

  const contextAPI = useContext(ContextAPI);

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  const EarningView = () => (
    <View style={styles.earningMainContainer}>
      <ImageBackground
        resizeMode="contain"
        style={{flex: 0.48}}
        imageStyle={{
          height: scale(90),
        }}
        source={ImageView.walletImg}>
        <View style={styles.earningDetailContainer}>
          <Text style={styles.tagEarnTxt}>
            {multiLanguages[contextAPI?.appLang]?.availableEarn}
          </Text>
          <Text numberOfLines={1} style={styles.earnAmountTxt}>
            {' 4,570,80 MAD'}
          </Text>
        </View>
      </ImageBackground>
      <ImageBackground
        resizeMode="contain"
        style={{flex: 0.48}}
        imageStyle={{
          height: scale(90),
        }}
        source={ImageView.walletImg}>
        <View style={styles.earningDetailContainer}>
          <Text style={styles.tagEarnTxt}>
            {multiLanguages[contextAPI?.appLang]?.totalEarn}
          </Text>
          <Text numberOfLines={1} style={styles.earnAmountTxt}>
            {'4,570,80 MAD'}
          </Text>
        </View>
      </ImageBackground>
    </View>
  );

  const WithrawMoneyView = () => (
    <Pressable
      onPress={() => {
        navigation.navigate('AddBankAccount');
      }}
      style={styles.withrawMoneyContainer}>
      <View style={{flex: 0.2}}>
        <Avatar.Image
          style={{backgroundColor: colors.silver}}
          source={ImageView.dollar}
          size={scale(35)}
        />
      </View>
      <View style={{flex: 0.6}}>
        <Text numberOfLines={2} style={styles.withrawMoneyTxt}>
          {multiLanguages[contextAPI?.appLang]?.withdrawMoney}
        </Text>
      </View>
      <View style={{alignItems: 'flex-end', flex: 0.2}}>
        <View
          style={{
            padding: scale(5),
          }}>
          <Image
            resizeMode="contain"
            style={styles.rightArrowIcon}
            source={ImageView.rightArrow}
          />
        </View>
      </View>
    </Pressable>
  );

  const PaymentHistoryView = () => (
    <View style={{flex: 1, paddingBottom: 0, padding: scale(20)}}>
      <Text style={styles.paymentHistoryTxt}>
        {multiLanguages[contextAPI?.appLang]?.paymentHistory}
      </Text>
      <FlatList
        bounces={false}
        contentContainerStyle={{paddingBottom: scale(10)}}
        data={paymentHistoryListData}
        keyExtractor={item => item?.id}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={<EmptyMessageComponent />}
        ItemSeparatorComponent={() => (
          <View
            style={{
              height: 0.5,
              backgroundColor: colors.black,
              opacity: 0.09,
            }}
          />
        )}
        renderItem={renderPaymentHistoryList}
      />
    </View>
  );

  const renderPaymentHistoryList = () => (
    <View
      style={{
        paddingVertical: scale(10),
        alignItems: 'center',
        justifyContent: 'space-between',
        flexDirection: 'row',
      }}>
      <View style={{flex: 0.7}}>
        <Text numberOfLines={1} style={styles.withdrawReqTxt}>
          {'Withdraw Requested'}
        </Text>
        {/* <Text numberOfLines={1} style={styles.withdrawReqTxt}>{'Taxi #325621656'}</Text> */}
        <View style={styles.sizeBox} />
        <Text numberOfLines={1} style={styles.dateTxt}>
          {'Completed - 25 Jan 2021 4:30 PM'}
        </Text>
      </View>
      <View style={styles.sizeBox} />
      <View style={{flex: 0.3, alignItems: 'flex-end'}}>
        <Text
          numberOfLines={1}
          style={[styles.withdrawReqTxt, {color: '#BD7202'}]}>
          {'Pending'}
        </Text>
        <View style={styles.sizeBox} />
        <Text numberOfLines={1} style={styles.payAmmountTxt}>
          {'-15.45 MAD'}
        </Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <HeaderComponent
        leftIconPress={() => {
          navigation.goBack();
        }}
        leftIcon={ImageView.backIconSecond}
        centerTxt={multiLanguages[contextAPI?.appLang]?.wallet}
      />
      {EarningView()}
      {WithrawMoneyView()}
      {PaymentHistoryView()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  earningMainContainer: {
    padding: scale(20),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  earningDetailContainer: {
    height: scale(90),
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: scale(10),
    paddingVertical: scale(15),
  },
  tagEarnTxt: {
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(13),
    color: colors.white,
    textAlign: 'center',
  },
  earnAmountTxt: {
    fontFamily: appFonts.poppinsSemiBold,
    fontSize: moderateScale(23),
    color: colors.white,
    textAlign: 'center',
  },
  withrawMoneyContainer: {
    marginHorizontal: scale(20),
    backgroundColor: colors.white,
    padding: scale(15),
    borderRadius: 14,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
    flexDirection: 'row',
    alignItems: 'center',
  },
  withrawMoneyTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.black,
  },
  rightArrowIcon: {
    width: scale(25),
    height: scale(25),
  },
  paymentHistoryTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(14),
    color: colors.dimGray,
    paddingBottom: scale(10),
  },
  sizeBox: {
    marginVertical: scale(6),
  },
  withdrawReqTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(14),
    color: colors.black,
  },
  dateTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(12),
    color: colors.gray,
  },
  payAmmountTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(14),
    color: colors.red,
  },
});

export default Wallet;
