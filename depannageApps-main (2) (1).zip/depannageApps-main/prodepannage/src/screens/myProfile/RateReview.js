import React, {useContext, useState} from 'react';
import {FlatList, StyleSheet, Text, View, Pressable} from 'react-native';

import Stars from 'react-native-stars';
import {moderateScale, scale} from 'react-native-size-matters';
import {useBackHandler} from '@react-native-community/hooks';

import HeaderComponent from '../../components/HeaderComponent';
import EmptyMessageComponent from '../../components/EmptyMessageComponent';

import {colors} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import {multiLanguages} from '../../utils/multiLanguages';
import {ContextAPI} from '../../contextAPI/contextProvider';
import appFonts from '../../utils/appFonts';

const RateReview = ({navigation}) => {
  const contextAPI = useContext(ContextAPI);
  const [reviewTagListData, setReviewTagListData] = useState([
    {
      id: 1,
      tag: multiLanguages[contextAPI?.appLang]?.all,
      isSelected: true,
    },
    {
      id: 2,
      tag: '5',
      isSelected: false,
    },
    {
      id: 3,
      tag: '4',
      isSelected: false,
    },
    {
      id: 4,
      tag: '3',
      isSelected: false,
    },
    {
      id: 5,
      tag: '2',
      isSelected: false,
    },
    {
      id: 6,
      tag: '1',
      isSelected: false,
    },
  ]);

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  const tagSelectHandler = item => {
    const tempData = [...reviewTagListData];
    tempData.map(obj => {
      obj.id == item?.id ? (obj.isSelected = true) : (obj.isSelected = false);
    });
    setReviewTagListData(tempData);
  };

  const RateReviewTagView = () => (
    <View style={{paddingTop: scale(20)}}>
      <View style={{paddingHorizontal: scale(20)}}>
        <Text style={styles.rateReviewsTxt}>
          {multiLanguages[contextAPI?.appLang]?.rateReviews}
        </Text>
      </View>
      <View>
        <FlatList
          horizontal
          contentContainerStyle={{
            paddingHorizontal: scale(20),
            paddingTop: scale(15),
          }}
          ItemSeparatorComponent={<View style={{marginRight: scale(8)}} />}
          renderItem={renderReviewTagList}
          data={reviewTagListData}
          showsHorizontalScrollIndicator={false}
          bounces={false}
          keyExtractor={item => item?.id}
        />
      </View>
    </View>
  );

  const renderReviewList = () => (
    <View style={styles.reviewItemContainer}>
      <Text numberOfLines={2} style={styles.userText}>
        {'Jack Celibers'}
      </Text>
      <View style={styles.reviewStar}>
        <Stars
          disabled={true}
          default={5}
          spacing={scale(6)}
          starSize={scale(14)}
          count={5}
          fullStar={ImageView.activeStar}
          emptyStar={ImageView.star}
        />
      </View>
      <View style={styles.sizeBox} />
      <Text numberOfLines={5} style={styles.reviewDetailTxt}>
        {
          'Fantastic job, it was quick, efficient and very good property i am very satisfied. i had to re-come to take this property again whenever i will come there.'
        }
      </Text>
      <View style={styles.sizeBox} />
      <Text numberOfLines={1} style={styles.timeTxt}>
        {'6hr ago'}
      </Text>
    </View>
  );

  const renderReviewTagList = ({item}) => (
    <Pressable
      onPress={() => {
        tagSelectHandler(item);
      }}
      style={[
        styles.tagItemContianer,
        {
          borderColor: item?.isSelected ? colors.transparent : colors.gray87,
          borderWidth: 1,
          backgroundColor: item?.isSelected
            ? colors.primaryColor
            : colors.gray95,
        },
      ]}>
      <Stars
        disabled={true}
        default={item?.isSelected ? 1 : 0}
        starSize={scale(16)}
        count={1}
        fullStar={ImageView.whiteStar}
        emptyStar={ImageView.lightStar}
      />
      <Text
        style={[
          styles.tagTxt,
          {color: item?.isSelected ? colors.white : colors.gray33},
        ]}>
        {item?.tag}
      </Text>
    </Pressable>
  );

  return (
    <View style={styles.container}>
      <HeaderComponent
        leftIconPress={() => {
          navigation.goBack();
        }}
        leftIcon={ImageView.backIconSecond}
        centerTxt={multiLanguages[contextAPI?.appLang]?.rateReview}
      />
      {RateReviewTagView()}
      <View style={{flex: 1, marginTop: scale(10)}}>
        <FlatList
          bounces={false}
          contentContainerStyle={{
            paddingTop: scale(10),
            padding: scale(20),
          }}
          data={Array(10).fill()}
          keyExtractor={item => item?.id}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={<EmptyMessageComponent />}
          ItemSeparatorComponent={() => (
            <View style={{marginVertical: scale(5)}} />
          )}
          renderItem={renderReviewList}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  rateReviewsTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.darkShadeBlue,
  },
  tagItemContianer: {
    paddingVertical: scale(5),
    paddingHorizontal: scale(10),
    borderRadius: scale(40),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  tagTxt: {
    marginLeft: scale(5),
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(14),
  },
  reviewItemContainer: {
    backgroundColor: colors.lightRed,
    padding: scale(15),
    borderRadius: 15,
  },
  userText: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(14),
    color: colors.darkShadeBlue,
  },
  reviewStar: {
    marginTop: scale(5),
    alignItems: 'flex-start',
  },
  reviewDetailTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(13),
    color: colors.suvaGrey,
  },
  timeTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(12),
    color: colors.approxGray,
  },
  sizeBox: {
    marginVertical: scale(6),
  },
});

export default RateReview;
