import React, {useContext, useRef, useState} from 'react';
import {StyleSheet, View, Text, Keyboard, Image} from 'react-native';

import {useBackHandler} from '@react-native-community/hooks';
import {moderateScale, scale} from 'react-native-size-matters';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';

import HeaderComponent from '../../components/HeaderComponent';
import ButtonComponent from '../../components/ButtonComponent';
import TextInputComponent from '../../components/TextInputComponent';

import {colors} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import {multiLanguages} from '../../utils/multiLanguages';
import {ContextAPI} from '../../contextAPI/contextProvider';
import Validation from '../../utils/validation';
import appFonts from '../../utils/appFonts';

const AddBankAccount = ({navigation}) => {
  const [inputFocus, setInputFocus] = useState('');
  const [name, setName] = useState('');
  const [accNumber, setAccNumber] = useState('');
  const [reEntAccNumber, setReEntAccNumber] = useState('');
  const [IFSCCode, setIFSCCode] = useState('');

  const accNumberRef = useRef('');
  const reEntAccNumberRef = useRef('');
  const IFSCCodeRef = useRef('');

  const contextAPI = useContext(ContextAPI);

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  const AddAccountInputView = () => (
    <View style={{flex: 1, paddingVertical: scale(20)}}>
      <TextInputComponent
        placeholder={multiLanguages[contextAPI?.appLang]?.name}
        value={name}
        inputTxtStyl={{
          fontFamily: Validation.isEmpty(name)
            ? appFonts.hankenGroteskRegular
            : appFonts.hankenGroteskMedium,
        }}
        container={
          inputFocus == multiLanguages[contextAPI?.appLang]?.name &&
          styles.activeTextInput
        }
        onFocus={() => {
          setInputFocus(multiLanguages[contextAPI?.appLang]?.name);
        }}
        onBlur={() => {
          setInputFocus('');
        }}
        onChangeText={text => setName(text)}
        onSubmitEditing={() => {
          Keyboard.dismiss();
          setTimeout(() => {
            accNumberRef.current.focus();
          }, 500);
        }}
        returnKeyType={'next'}
      />
      <View style={styles.sizeBox} />
      <TextInputComponent
        placeholder={multiLanguages[contextAPI?.appLang]?.accNumber}
        value={accNumber}
        keyboardType={'number-pad'}
        inputTxtStyl={{
          fontFamily: Validation.isEmpty(accNumber)
            ? appFonts.hankenGroteskRegular
            : appFonts.hankenGroteskMedium,
        }}
        container={
          inputFocus == multiLanguages[contextAPI?.appLang]?.accNumber &&
          styles.activeTextInput
        }
        onFocus={() => {
          setInputFocus(multiLanguages[contextAPI?.appLang]?.accNumber);
        }}
        onBlur={() => {
          setInputFocus('');
        }}
        onChangeText={text => setAccNumber(text)}
        inputRef={accNumberRef}
        onSubmitEditing={() => {
          Keyboard.dismiss();
          setTimeout(() => {
            reEntAccNumberRef.current.focus();
          }, 500);
        }}
        returnKeyType={'done'}
      />
      <View style={styles.sizeBox} />
      <TextInputComponent
        placeholder={multiLanguages[contextAPI?.appLang]?.reEntAccNumber}
        value={reEntAccNumber}
        keyboardType={'number-pad'}
        inputTxtStyl={{
          fontFamily: Validation.isEmpty(reEntAccNumber)
            ? appFonts.hankenGroteskRegular
            : appFonts.hankenGroteskMedium,
        }}
        container={
          inputFocus == multiLanguages[contextAPI?.appLang]?.reEntAccNumber &&
          styles.activeTextInput
        }
        onFocus={() => {
          setInputFocus(multiLanguages[contextAPI?.appLang]?.reEntAccNumber);
        }}
        onBlur={() => {
          setInputFocus('');
        }}
        onChangeText={text => setReEntAccNumber(text)}
        inputRef={reEntAccNumberRef}
        onSubmitEditing={() => {
          Keyboard.dismiss();
          setTimeout(() => {
            IFSCCodeRef.current.focus();
          }, 500);
        }}
        returnKeyType={'done'}
      />
      <View style={styles.sizeBox} />
      <TextInputComponent
        placeholder={multiLanguages[contextAPI?.appLang]?.IFSCCode}
        value={IFSCCode}
        kyeboardType={'number-pad'}
        inputTxtStyl={{
          fontFamily: Validation.isEmpty(IFSCCode)
            ? appFonts.hankenGroteskRegular
            : appFonts.hankenGroteskMedium,
        }}
        container={
          inputFocus == multiLanguages[contextAPI?.appLang]?.IFSCCode &&
          styles.activeTextInput
        }
        onFocus={() => {
          setInputFocus(multiLanguages[contextAPI?.appLang]?.IFSCCode);
        }}
        onBlur={() => {
          setInputFocus('');
        }}
        onChangeText={text => setIFSCCode(text)}
        inputRef={IFSCCodeRef}
        onSubmitEditing={() => {
          Keyboard.dismiss();
        }}
        returnKeyType={'done'}
      />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <ButtonComponent
        onBtnPress={() => {
          Keyboard.dismiss();
          navigation.goBack();
        }}
        btnLabel={multiLanguages[contextAPI?.appLang]?.addAccount}
      />
    </View>
  );

  const FotterMsgView = () => (
    <View style={styles.footerContianer}>
      <Image
        style={styles.secureIcon}
        resizeMode="contain"
        source={ImageView.secure}
      />
      <Text style={styles.secureTxt}>
        {multiLanguages[contextAPI?.appLang]?.secureMsg}
      </Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <HeaderComponent
        leftIconPress={() => {
          navigation.goBack();
        }}
        leftIcon={ImageView.backIconSecond}
        centerTxt={multiLanguages[contextAPI?.appLang]?.addBankAccount}
      />
      <KeyboardAwareScrollView
        bounces={false}
        contentContainerStyle={{flexGrow: 1}}
        keyboardShouldPersistTaps="always"
        showsVerticalScrollIndicator={false}>
        {AddAccountInputView()}
        {FotterMsgView()}
      </KeyboardAwareScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  sizeBox: {
    marginVertical: scale(6),
  },
  activeTextInput: {
    borderColor: colors.secondaryColor,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.17,
    shadowRadius: 2.54,
    elevation: 3,
  },
  footerContianer: {
    paddingHorizontal: scale(60),
    flexDirection: 'row',
    justifyContent: 'center',
    paddingVertical: scale(20),
  },
  secureIcon: {
    width: scale(20),
    height: scale(20),
    marginEnd: scale(7),
  },
  secureTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(13),
    color: colors.gray40,
    textAlign: 'center',
  },
});

export default AddBankAccount;
