import React, {useContext, useState, useRef, useEffect} from 'react';
import {
  FlatList,
  StyleSheet,
  Text,
  View,
  Image,
  Pressable,
  Keyboard,
  Alert,
} from 'react-native';

import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import Tooltip from 'react-native-walkthrough-tooltip';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import RBSheet from 'react-native-raw-bottom-sheet';
import {Avatar} from 'react-native-paper';
import {CountryPicker} from 'react-native-country-codes-picker';
import {useBackHandler} from '@react-native-community/hooks';
import * as ImagePicker from 'react-native-image-crop-picker';

import HeaderComponent from '../../components/HeaderComponent';
import EmptyMessageComponent from '../../components/EmptyMessageComponent';
import TextInputComponent from '../../components/TextInputComponent';
import ButtonComponent from '../../components/ButtonComponent';

import {FirebaseCollections, colors} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import {multiLanguages} from '../../utils/multiLanguages';
import {ContextAPI} from '../../contextAPI/contextProvider';
import appFonts from '../../utils/appFonts';
import Validation from '../../utils/validation';
import {FireStoreHelper} from '../../service/firebase';
import {formatePhoneNumber} from '../../utils/helpers';
import auth from '@react-native-firebase/auth';

const ManageAgents = ({navigation}) => {
  const [inputFocus, setInputFocus] = useState('');
  const [name, setName] = useState('');
  const [pNumber, setPNumber] = useState('');
  const [countryCode, setCountryCode] = useState('+1');
  const [showCountryPicker, setShowCountryPicker] = useState(false);
  const [agentProfileImg, setAgentProfileImg] = useState(null);
  const [agents, setAgents] = useState(null);

  const imageOptions = {
    Camera: 'camera',
    Gallery: 'gallery',
  };

  const refRBSheet = useRef('');
  const refOptionRBSheet = useRef('');

  const contextAPI = useContext(ContextAPI);

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  const onSelect = item => {
    setCountryCode(item.dial_code);
    setShowCountryPicker(false);
  };

  const popupOpenHandler = item => {
    const tempData = [...agents];
    tempData.map(obj => {
      obj.id == item.id ? (obj.visible = true) : (obj.visible = false);
    });
    setAgents(tempData);
  };

  const popupCloseHandler = item => {
    const tempData = [...agents];
    tempData.map(obj => {
      obj.visible = false;
    });
    setAgents(tempData);
  };

  const fetchAgents = async () => {
    try {
      contextAPI.setLoading(true);
      const firebase = new FireStoreHelper(FirebaseCollections.Agents);

      const result = await firebase.getByColumn(
        'userId',
        auth().currentUser.uid,
      );

      setAgents(result);
    } catch (err) {
      contextAPI.setLoading(false);
      Alert.alert(err);
    }

    contextAPI.setLoading(false);
  };

  const handleImage = async imageType => {
    Keyboard.dismiss();

    let imagePath = null;

    if (imageType === imageOptions.Camera) {
      const result = await ImagePicker.openCamera({
        cropping: true,
      });

      imagePath = result.path;
    }

    if (imageType === imageOptions.Gallery) {
      const result = await ImagePicker.openPicker({
        cropping: true,
        mediaType: 'photo',
      });
      imagePath = result.path;
    }

    const firebase = new FireStoreHelper();

    contextAPI.setLoading(true);
    const url = await firebase.uploadImage(imagePath);
    console.log({url});
    setAgentProfileImg(url);

    contextAPI.setLoading(false);
  };

  const addAgent = async () => {
    Keyboard.dismiss();

    try {
      const firebase = new FireStoreHelper(FirebaseCollections.Agents);

      const user = auth().currentUser;

      contextAPI.setLoading(true);

      await firebase.create({
        name: name,
        phoneNumber: formatePhoneNumber(pNumber, countryCode),
        profileImg: agentProfileImg,
        userId: user.uid,
      });
      refRBSheet.current?.close();
      await fetchAgents();
    } catch (err) {
      contextAPI.setLoading(false);
      Alert.alert(err);
    }

    contextAPI.setLoading(false);
  };

  const deleteAgent = async id => {
    Keyboard.dismiss();
    contextAPI.setLoading(true);

    try {
      const firebase = new FireStoreHelper(FirebaseCollections.Agents);

      await firebase.delete(id);

      await fetchAgents();
    } catch (err) {
      contextAPI.setLoading(false);
      Alert.alert(err);
    }

    contextAPI.setLoading(false);
  };

  useEffect(() => {
    (async () => {
      fetchAgents();
    })();
  }, []);

  const renderAgentList = ({item}) => (
    <View style={styles.agentItemContainer}>
      <View style={{flex: 0.18}}>
        <Avatar.Image
          style={{backgroundColor: colors.silver}}
          source={
            item?.profileImg
              ? {
                  uri: item?.profileImg,
                }
              : ImageView.dummyProfileImg
          }
          size={scale(40)}
        />
      </View>
      <View style={{flex: 0.67}}>
        <Text numberOfLines={2} style={styles.userText}>
          {item?.name}
        </Text>
      </View>
      <View style={{alignItems: 'flex-end', flex: 0.15}}>
        <Tooltip
          tooltipStyle={{}}
          contentStyle={{
            right: scale(10),
            borderRadius: 10,
            padding: 0,
          }}
          animated={true}
          arrowSize={{width: 0, height: 0}}
          backgroundColor="rgba(0,0,0,0.5)"
          isVisible={item?.visible}
          content={ToolTipView(item.id)}
          placement="bottom"
          onClose={() => popupCloseHandler(item)}>
          <Pressable
            style={{
              padding: scale(5),
            }}
            onPress={() => {
              popupOpenHandler(item);
            }}>
            <Image
              resizeMode="contain"
              style={styles.moreIcon}
              source={ImageView.more}
            />
          </Pressable>
        </Tooltip>
      </View>
    </View>
  );

  const ToolTipView = id => (
    <View style={styles.tooltipContainer}>
      <Text style={styles.optionTxt}>
        {multiLanguages[contextAPI?.appLang]?.edit}
      </Text>
      <Text style={styles.optionTxt} onPress={() => deleteAgent(id)}>
        {multiLanguages[contextAPI?.appLang]?.delete}
      </Text>
    </View>
  );

  const AddAgentView = () => (
    <View>
      <RBSheet
        ref={refOptionRBSheet}
        height={verticalScale(150)}
        dragFromTopOnly
        closeOnDragDown
        openDuration={250}
        customStyles={{
          container: {
            borderTopEndRadius: 35,
            borderTopStartRadius: 35,
          },
          draggableIcon: {
            top: scale(5),
            backgroundColor: colors.silver,
            height: scale(6),
            borderRadius: 13,
            width: scale(70),
          },
        }}>
        {ModalContentView()}
      </RBSheet>
      <View
        style={{
          paddingVertical: scale(10),
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Text style={styles.addAgentTxt}>
          {multiLanguages[contextAPI?.appLang]?.addAgent}
        </Text>
      </View>
      <View style={styles.sizeBox} />
      <View style={{paddingVertical: scale(5)}}>
        <View
          style={{
            alignSelf: 'center',
            borderWidth: 1,
            borderColor: colors.gray72,
            borderRadius: scale(80 / 2),
          }}>
          <Pressable
            onPress={() => {
              Keyboard.dismiss();
              refOptionRBSheet.current?.open();
            }}
            style={styles.positionCameraContainer}>
            <Image
              resizeMode="contain"
              style={styles.cameraSecondIcon}
              source={ImageView.cameraSecond}
            />
          </Pressable>
          <Avatar.Image
            style={{backgroundColor: colors.silver}}
            source={
              agentProfileImg
                ? {uri: agentProfileImg}
                : ImageView.dummyProfileImg
            }
            size={scale(80)}
          />
        </View>
      </View>
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <TextInputComponent
        placeholder={multiLanguages[contextAPI?.appLang]?.name}
        value={name}
        inputTxtStyl={{
          fontFamily: Validation.isEmpty(name)
            ? appFonts.hankenGroteskRegular
            : appFonts.hankenGroteskMedium,
        }}
        container={
          inputFocus == multiLanguages[contextAPI?.appLang]?.name &&
          styles.activeTextInput
        }
        onFocus={() => {
          setInputFocus(multiLanguages[contextAPI?.appLang]?.name);
        }}
        onBlur={() => {
          setInputFocus('');
        }}
        onChangeText={text => setName(text)}
        onSubmitEditing={() => {
          Keyboard.dismiss();
        }}
        returnKeyType={'done'}
      />
      <View style={styles.sizeBox} />
      <TextInputComponent
        placeholder={multiLanguages[contextAPI?.appLang]?.mNumber}
        value={pNumber}
        inputTxtStyl={{
          fontFamily: Validation.isEmpty(pNumber)
            ? appFonts.hankenGroteskRegular
            : appFonts.hankenGroteskMedium,
        }}
        container={
          inputFocus == multiLanguages[contextAPI?.appLang]?.mNumber &&
          styles.activeTextInput
        }
        onFocus={() => {
          setInputFocus(multiLanguages[contextAPI?.appLang]?.mNumber);
        }}
        onBlur={() => {
          setInputFocus('');
        }}
        keyboardType="number-pad"
        onChangeText={text => setPNumber(text)}
        leftCustomIcon={LeftCustomIcon()}
        onSubmitEditing={() => {
          Keyboard.dismiss();
        }}
        returnKeyType={'done'}
      />
      <View style={styles.sizeBox} />
      <View style={{paddingVertical: scale(20)}}>
        <ButtonComponent
          onBtnPress={addAgent}
          btnLabel={multiLanguages[contextAPI?.appLang]?.addNow}
        />
      </View>
    </View>
  );

  const LeftCustomIcon = () => (
    <Pressable
      onPress={() => {
        Keyboard.dismiss();
        setShowCountryPicker(true);
      }}
      style={styles.customIconContainer}>
      <Text
        style={[
          styles.countryCodeTxt,
          {
            color:
              inputFocus !== multiLanguages[contextAPI?.appLang]?.mNumber
                ? colors.grayDark
                : colors.black,
          },
        ]}>
        {countryCode}
      </Text>
      <Image
        resizeMode="contain"
        style={[
          styles.downArrowIcon,
          {
            tintColor:
              inputFocus !== multiLanguages[contextAPI?.appLang]?.mNumber
                ? colors.grayDark
                : null,
          },
        ]}
        source={ImageView.downArrow}
      />
    </Pressable>
  );

  const ModalContentView = () => (
    <View
      style={{
        flexDirection: 'row',
        alignSelf: 'center',
        flex: 1,
      }}>
      <View
        style={{
          width: scale(100),
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Pressable
          onPress={() => {
            refOptionRBSheet.current.close();
            setTimeout(async () => {
              await handleImage(imageOptions.Camera);
            }, 500);
          }}
          style={styles.modalcIcon}>
          <Image
            resizeMode="contain"
            source={ImageView.chooseCamera}
            style={styles.cameraGalleryIcon}
          />
        </Pressable>
      </View>
      <View
        style={{
          width: scale(100),
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Pressable
          onPress={() => {
            refOptionRBSheet.current.close();
            setTimeout(async () => {
              await handleImage(imageOptions.Gallery);
            }, 500);
          }}
          style={styles.modalcIcon}>
          <Image
            resizeMode="contain"
            source={ImageView.chooseGallery}
            style={styles.cameraGalleryIcon}
          />
        </Pressable>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <HeaderComponent
        leftIconPress={() => {
          navigation.goBack();
        }}
        leftIcon={ImageView.backIconSecond}
        centerTxt={multiLanguages[contextAPI?.appLang]?.manageAgentsSecond}
      />
      <CountryPicker
        enableModalAvoiding
        show={showCountryPicker}
        onBackdropPress={() => {
          setShowCountryPicker(false);
        }}
        onRequestClose={() => {
          setShowCountryPicker(false);
        }}
        pickerButtonOnPress={item => onSelect(item)}
        style={styles.countryPickerStyl}
      />
      <RBSheet
        ref={refRBSheet}
        height={verticalScale(400)}
        dragFromTopOnly
        closeOnDragDown
        openDuration={250}
        customStyles={{
          container: {
            borderTopEndRadius: 35,
            borderTopStartRadius: 35,
          },
          draggableIcon: {
            top: scale(5),
            backgroundColor: colors.silver,
            height: scale(6),
            borderRadius: 13,
            width: scale(70),
          },
        }}>
        <KeyboardAwareScrollView
          bounces={false}
          keyboardShouldPersistTaps="always"
          showsVerticalScrollIndicator={false}>
          {AddAgentView()}
        </KeyboardAwareScrollView>
      </RBSheet>

      <View style={{flex: 1, marginTop: scale(10)}}>
        <FlatList
          contentContainerStyle={{
            paddingTop: scale(10),
            padding: scale(20),
          }}
          data={agents}
          keyExtractor={item => item?.id}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={<EmptyMessageComponent />}
          ItemSeparatorComponent={() => (
            <View style={{marginVertical: scale(6)}} />
          )}
          renderItem={renderAgentList}
        />
      </View>
      <View style={{paddingVertical: scale(20)}}>
        <ButtonComponent
          onBtnPress={() => {
            refRBSheet.current?.open();
          }}
          btnLabel={multiLanguages[contextAPI?.appLang]?.addAgent}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  countryPickerStyl: {
    // Styles for whole modal [View]
    modal: {
      height: verticalScale(300),
    },
    // Styles for input [TextInput]
    textInput: {
      height: scale(50),
      borderRadius: 10,
      paddingHorizontal: scale(25),
    },
    // Styles for country button [TouchableOpacity]
    countryButtonStyles: {
      height: scale(50),
      borderRadius: 10,
    },
    // Country name styles [Text]
    countryName: {
      fontSize: moderateScale(13),
      fontFamily: appFonts.interRegular,
    },
  },
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  agentItemContainer: {
    backgroundColor: colors.white,
    padding: scale(15),
    borderRadius: 14,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
    flexDirection: 'row',
    alignItems: 'center',
  },
  userText: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.lightBlue,
  },
  tooltipContainer: {
    backgroundColor: colors.white,
    padding: scale(10),
    width: scale(90),
    height: scale(70),
    justifyContent: 'space-between',
  },
  optionTxt: {
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(14),
    color: colors.lightBlue,
  },
  sizeBox: {
    marginVertical: scale(6),
  },
  moreIcon: {
    width: scale(16),
    height: scale(4),
  },
  addAgentTxt: {
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(18),
    color: colors.black,
    textAlign: 'center',
  },
  positionCameraContainer: {
    position: 'absolute',
    zIndex: 1,
    right: scale(-5),
  },
  cameraSecondIcon: {
    width: scale(30),
    height: scale(30),
  },
  activeTextInput: {
    borderColor: colors.secondaryColor,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.17,
    shadowRadius: 2.54,
    elevation: 3,
  },
  customIconContainer: {
    marginEnd: scale(10),
    height: scale(25),
    alignItems: 'center',
    flexDirection: 'row',
  },
  downArrowIcon: {
    marginLeft: scale(10),
    width: scale(20),
    height: scale(20),
  },
  countryCodeTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(16),
  },
  cameraGalleryIcon: {
    width: scale(55),
    height: scale(55),
  },
});

export default ManageAgents;
