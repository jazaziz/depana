import React, {useState, useRef, useContext, useEffect} from 'react';
import {
  StyleSheet,
  View,
  Image,
  Keyboard,
  Pressable,
  Alert,
} from 'react-native';

import {useBackHandler} from '@react-native-community/hooks';
import {scale, verticalScale} from 'react-native-size-matters';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import RBSheet from 'react-native-raw-bottom-sheet';
import * as ImagePicker from 'react-native-image-crop-picker';

import HeaderComponent from '../../components/HeaderComponent';
import TextInputComponent from '../../components/TextInputComponent';
import ButtonComponent from '../../components/ButtonComponent';

import {FirebaseCollections, colors} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import Validation from '../../utils/validation';
import appFonts from '../../utils/appFonts';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';
import {FireStoreHelper} from '../../service/firebase';

const EditProfile = ({navigation, route}) => {
  const [inputFocus, setInputFocus] = useState('');
  const [username, setUsername] = useState('');
  const [location, setLocation] = useState('');
  const [aboutC, setAboutC] = useState('');
  const [userC, setUserC] = useState(route?.params?.user ?? null);
  const [companyLogo, setCompanyLogo] = useState(route?.params?.user?.logo);

  const refOptionRBSheet = useRef('');

  const contextAPI = useContext(ContextAPI);

  const imageOptions = {
    Camera: 'camera',
    Gallery: 'gallery',
  };

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  useEffect(() => {
    setUsername(userC?.companyName ?? '');
    setLocation(userC?.location ?? '');
    setAboutC(userC?.about ?? '');
  }, []);

  const handleUpdate = async () => {
    Keyboard.dismiss();

    contextAPI.setLoading(true);

    const firebase = new FireStoreHelper(FirebaseCollections.Companies);

    console.log(
      {userC},
      // {
      //   companyName: username,
      //   location: location,
      //   about: aboutC,
      //   logo: companyLogo,
      // },
    );

    try {
      await firebase.update(userC?.id, {
        companyName: username,
        location: location,
        about: aboutC,
        logo: companyLogo,
      });

      navigation.goBack();

      contextAPI.setLoading(false);
    } catch (error) {
      contextAPI.setLoading(false);
      Alert.alert(error);
    }
  };

  const handleImage = async imageType => {
    let imagePath = null;

    if (imageType === imageOptions.Camera) {
      const result = await ImagePicker.openCamera({
        cropping: true,
      });

      imagePath = result.path;
    }

    if (imageType === imageOptions.Gallery) {
      const result = await ImagePicker.openPicker({
        cropping: true,
        mediaType: 'photo',
      });
      imagePath = result.path;
    }

    const firebase = new FireStoreHelper();

    contextAPI.setLoading(true);
    const url = await firebase.uploadImage(imagePath);
    console.log({url});
    setCompanyLogo(url);

    contextAPI.setLoading(false);
  };

  const ProfileDetailView = () => (
    <View style={{paddingTop: scale(20), paddingBottom: scale(10)}}>
      <View
        style={[
          styles.profileIcon,
          {
            marginHorizontal: scale(20),
          },
        ]}>
        <Pressable
          onPress={() => {
            Keyboard.dismiss();
            refOptionRBSheet.current.open();
          }}
          style={styles.cameraContainer}>
          <Image
            resizeMode="contain"
            style={styles.cameraIcon}
            source={ImageView.camera}
          />
        </Pressable>
        <Image
          resizeMode="contain"
          style={styles.profileIcon}
          source={
            companyLogo
              ? {
                  uri: companyLogo,
                }
              : ImageView.dummyImg
          }
        />
      </View>
      <View style={styles.sizeBox} />
      <View style={{paddingVertical: scale(10)}}>
        <TextInputComponent
          placeholder={multiLanguages[contextAPI?.appLang]?.fullName}
          value={username}
          inputTxtStyl={{
            fontFamily: Validation.isEmpty(username)
              ? appFonts.hankenGroteskRegular
              : appFonts.hankenGroteskMedium,
          }}
          container={[
            inputFocus == multiLanguages[contextAPI?.appLang]?.fullName &&
              styles.activeTextInput,
          ]}
          onFocus={() => {
            setInputFocus(multiLanguages[contextAPI?.appLang]?.fullName);
          }}
          onBlur={() => {
            setInputFocus('');
          }}
          onChangeText={text => {
            setUsername(text);
          }}
          onSubmitEditing={() => {
            Keyboard.dismiss();
          }}
        />
        <View style={styles.sizeBox} />
        <TextInputComponent
          placeholder={multiLanguages[contextAPI?.appLang]?.location}
          value={location}
          inputTxtStyl={{
            fontFamily: Validation.isEmpty(username)
              ? appFonts.hankenGroteskRegular
              : appFonts.hankenGroteskMedium,
          }}
          container={
            inputFocus == multiLanguages[contextAPI?.appLang]?.location &&
            styles.activeTextInput
          }
          onFocus={() => {
            setInputFocus(multiLanguages[contextAPI?.appLang]?.location);
          }}
          onBlur={() => {
            setInputFocus('');
          }}
          onChangeText={text => setLocation(text)}
          onSubmitEditing={() => {
            Keyboard.dismiss();
          }}
          returnKeyType={'done'}
        />
        <View style={styles.sizeBox} />
        <TextInputComponent
          textAlignVertical="top"
          multiline={true}
          placeholder={multiLanguages[contextAPI?.appLang]?.aboutCompany}
          value={aboutC}
          inputTxtStyl={{
            height: scale(135),
            paddingVertical: scale(15),
            fontFamily: Validation.isEmpty(aboutC)
              ? appFonts.hankenGroteskRegular
              : appFonts.hankenGroteskMedium,
          }}
          container={[
            {
              borderRadius: 15,
            },
            inputFocus == multiLanguages[contextAPI?.appLang]?.aboutCompany &&
              styles.activeTextInput,
          ]}
          onFocus={() => {
            setInputFocus(multiLanguages[contextAPI?.appLang]?.aboutCompany);
          }}
          onBlur={() => {
            setInputFocus('');
          }}
          onChangeText={text => setAboutC(text)}
        />
        <View style={styles.sizeBox} />
      </View>
    </View>
  );

  const ModalContentView = () => (
    <View
      style={{
        flexDirection: 'row',
        alignSelf: 'center',
        flex: 1,
      }}>
      <View
        style={{
          width: scale(100),
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Pressable
          onPress={() => {
            refOptionRBSheet.current.close();
            setTimeout(async () => {
              await handleImage(imageOptions.Camera);
            }, 500);
          }}
          style={styles.modalcIcon}>
          <Image
            resizeMode="contain"
            source={ImageView.chooseCamera}
            style={styles.cameraGalleryIcon}
          />
        </Pressable>
      </View>
      <View
        style={{
          width: scale(100),
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Pressable
          onPress={() => {
            refOptionRBSheet.current.close();
            setTimeout(async () => {
              await handleImage(imageOptions.Gallery);
            }, 500);
          }}
          style={styles.modalcIcon}>
          <Image
            resizeMode="contain"
            source={ImageView.chooseGallery}
            style={styles.cameraGalleryIcon}
          />
        </Pressable>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <HeaderComponent
        leftIconPress={() => {
          navigation.goBack();
        }}
        leftIcon={ImageView.backIconSecond}
        centerTxt={multiLanguages[contextAPI?.appLang]?.editProfile}
      />
      <RBSheet
        ref={refOptionRBSheet}
        height={verticalScale(150)}
        dragFromTopOnly
        closeOnDragDown
        openDuration={250}
        customStyles={{
          container: {
            borderTopEndRadius: 35,
            borderTopStartRadius: 35,
          },
          draggableIcon: {
            top: scale(5),
            backgroundColor: colors.silver,
            height: scale(6),
            borderRadius: 13,
            width: scale(70),
          },
        }}>
        {ModalContentView()}
      </RBSheet>
      <KeyboardAwareScrollView
        bounces={false}
        contentContainerStyle={{flexGrow: 1, paddingBottom: scale(20)}}
        keyboardShouldPersistTaps="always"
        showsVerticalScrollIndicator={false}>
        {ProfileDetailView()}
        <View style={styles.sizeBox} />
        <ButtonComponent
          onBtnPress={handleUpdate}
          btnLabel={multiLanguages[contextAPI?.appLang]?.updateNow}
        />
      </KeyboardAwareScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  profileIcon: {
    backgroundColor: colors.silver,
    borderRadius: 13,
    width: scale(90),
    height: scale(90),
  },
  cameraContainer: {
    zIndex: 1,
    position: 'absolute',
    bottom: scale(-20),
    right: scale(-15),
  },
  cameraIcon: {
    width: scale(50),
    height: scale(50),
  },
  cameraGalleryIcon: {
    width: scale(55),
    height: scale(55),
  },
  sizeBox: {
    marginVertical: scale(6),
  },
  activeTextInput: {
    borderColor: colors.secondaryColor,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.17,
    shadowRadius: 2.54,
    elevation: 3,
  },
  modalcIcon: {
    width: scale(50),
    height: scale(50),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: scale(15),
  },
});

export default EditProfile;
