import React, {useContext, useEffect} from 'react';
import {StyleSheet, ImageBackground, Alert} from 'react-native';

import {moderateScale, scale} from 'react-native-size-matters';

import {FirebaseCollections, colors, config} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import appFonts from '../../utils/appFonts';
import {ContextAPI} from '../../contextAPI/contextProvider';
import auth from '@react-native-firebase/auth';
import {FireStoreHelper} from '../../service/firebase';

const Splash = ({navigation}) => {
  const contextAPI = useContext(ContextAPI);

  useEffect(() => {
    (async () => {
      contextAPI?.setAppLang(0);
      const user = auth().currentUser;

      if (user) {
        contextAPI.setLoginUserData(user);

        const firebase = new FireStoreHelper(FirebaseCollections.Companies);

        const userCompany = await firebase.getByColumn('userId', user.uid);

        if (!(userCompany.length > 0)) {
          navigation.replace('ProfileSetup');
          return;
        }
      }

      setTimeout(() => {
        if (user) {
          navigation.replace('Home');
        } else navigation.replace('SignIn');
      }, 1000);
    })();
  }, []);

  return (
    <ImageBackground
      style={styles.container}
      imageStyle={{width: '100%', height: '100%'}}
      source={ImageView.splashImg}
    />
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  centerContainer: {
    flex: 0.25,
    width: '100%',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  centerAppIcon: {
    width: '80%',
    height: '40%',
  },
  splashMsgTxt: {
    textAlign: 'center',
    marginHorizontal: scale(15),
    color: colors.white,
    fontSize: moderateScale(24),
    fontFamily: appFonts.openSansBold,
    lineHeight: scale(32),
  },
});

export default Splash;
