import React, {useContext, useRef, useState} from 'react';
import {
  StyleSheet,
  Image,
  Dimensions,
  ImageBackground,
  View,
  Text,
  Keyboard,
  Pressable,
  SafeAreaView,
  Platform,
  Alert,
} from 'react-native';

import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import OTPTextInput from 'react-native-otp-textinput';
import {useBackHandler} from '@react-native-community/hooks';
import {useSafeAreaInsets} from 'react-native-safe-area-context';

import ButtonComponent from '../../components/ButtonComponent';

import {FirebaseCollections, colors} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import appFonts from '../../utils/appFonts';
import {multiLanguages} from '../../utils/multiLanguages';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {FireStoreHelper} from '../../service/firebase';
import auth from '@react-native-firebase/auth';
import {getFcmToken} from '../../service/notifications';
import AsyncStorage from '@react-native-async-storage/async-storage';

const deviceHeight = Dimensions.get('window').height;
const OTPVerification = ({navigation, route}) => {
  const [otpCode, setOtpCode] = useState('');
  const [disbaleResend, setDisbaleResend] = useState(false);

  const insets = useSafeAreaInsets();

  const otpRef = useRef('');

  const contextAPI = useContext(ContextAPI);

  useBackHandler(() => {
    Keyboard.dismiss();
    navigation.goBack();
    return true;
  });

  const handleOtpConfirmation = async () => {
    Keyboard.dismiss();

    contextAPI.setLoading(true);
    try {
      const confirmCode = route.params?.confirmationCode;
      await confirmCode.confirm(otpCode);

      // check is user setup the company then redirect to home
      const company = new FireStoreHelper(FirebaseCollections.Companies);

      const user = auth().currentUser;

      const userCompany = await company.getByColumn('userId', user.uid);

      // create user setting
      const userSettings = new FireStoreHelper(
        FirebaseCollections.userSettings,
      );

      const isUserSettingExits = await userSettings.getByColumn(
        'userId',
        user.uid,
      );

      if (isUserSettingExits.length > 0) {
        // delete the old user setting
        await userSettings.delete(isUserSettingExits[0].id);
      }

      const token = await getFcmToken();

      await userSettings.create({
        userId: user.uid,
        fcmToken: token,
        isNotificationsOn: true,
        createdAt: new Date(),
      });

      if (userCompany.length > 0) {
        navigation.replace('Home');
        return;
      }

      navigation.replace('ProfileSetup');
    } catch (error) {
      contextAPI.setLoading(false);
      Alert.alert('Error', 'Invalid Code. please try again');
      navigation.replace('SignIn');
    }

    contextAPI.setLoading(false);
  };

  const disableResendBtnHandler = () => {
    otpRef.current.clear();
    setDisbaleResend(true);
    setTimeout(() => {
      setDisbaleResend(false);
    }, 60000);
  };

  const AuthHeaderView = () => (
    <ImageBackground
      style={[
        styles.imgBgContainer,
        {
          height:
            Platform.OS == 'ios'
              ? verticalScale(250) - insets.top
              : verticalScale(250),
        },
      ]}
      imageStyle={styles.curveImgStyl}
      source={ImageView.headerCurveImg}>
      <Pressable
        onPress={() => {
          Keyboard.dismiss();
          navigation.goBack();
        }}
        style={styles.backIconAbsoluteIcon}>
        <Image
          style={styles.backIcon}
          resizeMode="contain"
          source={ImageView.backIcon}
        />
      </Pressable>
    </ImageBackground>
  );

  const UserInputView = () => (
    <View
      style={{
        height: deviceHeight - verticalScale(250),
      }}>
      <View style={styles.headerAbsoluteIcon}>
        <Image
          style={styles.headerIcon}
          resizeMode="contain"
          source={ImageView.otpIcon}
        />
      </View>
      <View style={{height: '60%'}}>{InputTextView()}</View>
      <View style={styles.fotterAbsoluteIcon}>
        <Image
          style={styles.fotterIcon}
          resizeMode="contain"
          source={ImageView.towingImg}
        />
        <Text
          suppressHighlighting
          onPress={() => {
            !disbaleResend && disableResendBtnHandler();
          }}
          style={[
            styles.resendCodeTxt,
            {
              color: disbaleResend ? colors.grayDark : colors.primaryColor,
            },
          ]}>
          {multiLanguages[contextAPI?.appLang]?.resendCode}
        </Text>
      </View>
    </View>
  );

  const InputTextView = () => (
    <View style={{}}>
      <Text style={styles.authTypeTxt}>
        {multiLanguages[contextAPI?.appLang]?.otpVerification}
      </Text>
      <Text style={styles.authTypeMsgTxt}>
        {multiLanguages[contextAPI?.appLang]?.otpVerificationMessg}
        <Text style={styles.mNumberTxt}> {route.params?.mobileN}</Text>
      </Text>
      <View style={{paddingVertical: scale(20)}}>
        <OTPTextInput
          tintColor={colors.primaryColor}
          offTintColor={colors.softPeach}
          handleTextChange={text => setOtpCode(text)}
          defaultValue={otpCode}
          inputCount={6}
          selectionColor={colors.primaryColor}
          cursorColor={colors.primaryColor}
          containerStyle={{
            marginHorizontal: scale(15),
          }}
          textInputStyle={styles.textInputStyle}
          ref={otpRef}
        />
      </View>
      <View style={styles.sizeBox} />
      <ButtonComponent
        onBtnPress={handleOtpConfirmation}
        btnLabel={multiLanguages[contextAPI?.appLang]?.confirmNow}
      />
    </View>
  );

  return (
    <View style={styles.container}>
      <KeyboardAwareScrollView
        bounces={false}
        keyboardShouldPersistTaps="always"
        showsVerticalScrollIndicator={false}>
        {AuthHeaderView()}
        {UserInputView()}
      </KeyboardAwareScrollView>
      <SafeAreaView style={{flex: 0, backgroundColor: colors.white}} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  imgBgContainer: {
    width: '100%',
  },
  curveImgStyl: {
    width: '100%',
    height: '100%',
    borderBottomLeftRadius: 85,
    borderBottomRightRadius: 85,
  },
  backIconAbsoluteIcon: {
    position: 'absolute',
    left: scale(5),
    top: scale(30),
    alignItems: 'center',
    justifyContent: 'center',
  },
  backIcon: {
    width: scale(70),
    height: scale(70),
  },
  headerAbsoluteIcon: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: scale(-45),
  },
  headerIcon: {
    width: scale(100),
    height: scale(100),
  },
  fotterAbsoluteIcon: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: scale(100),
    height: '40%',
    zIndex: -1,
  },
  fotterIcon: {
    width: '100%',
    height: scale(131),
  },
  authTypeTxt: {
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(26),
    color: colors.primaryColor,
    textAlign: 'center',
  },
  resendCodeTxt: {
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(16),
    color: colors.primaryColor,
    textAlign: 'center',
  },
  authTypeMsgTxt: {
    paddingHorizontal: scale(5),
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(16),
    color: colors.suvaGrey,
    textAlign: 'center',
    lineHeight: scale(25),
  },
  mNumberTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.secondaryColor,
    textAlign: 'center',
  },
  sizeBox: {
    marginVertical: scale(5),
  },
  textInputStyle: {
    backgroundColor: colors.transparent,
    borderRadius: 12,
    height: scale(50),
    marginLeft: 0,
    width: scale(50),
    color: colors.primaryColor,
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(24),
    borderWidth: 1,
    borderBottomWidth: 1,
    borderColor: colors.softPeach,
  },
});

export default OTPVerification;
