import React, {useContext, useState} from 'react';
import {
  StyleSheet,
  Image,
  Dimensions,
  ImageBackground,
  View,
  Text,
  Keyboard,
  Pressable,
  SafeAreaView,
  Platform,
  Alert,
} from 'react-native';

import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {CountryPicker} from 'react-native-country-codes-picker';
import {useBackHandler} from '@react-native-community/hooks';
import RNExitApp from 'react-native-exit-app';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import auth from '@react-native-firebase/auth';

import TextInputComponent from '../../components/TextInputComponent';
import ButtonComponent from '../../components/ButtonComponent';

import {colors} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import appFonts from '../../utils/appFonts';
import Validation from '../../utils/validation';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';
import {formatePhoneNumber} from '../../utils/helpers';

const deviceHeight = Dimensions.get('window').height;

const SignIn = ({navigation}) => {
  const [inputFocus, setInputFocus] = useState('');
  const [pNumber, setPNumber] = useState('');
  const [countryCode, setCountryCode] = useState('+1');
  const [showCountryPicker, setShowCountryPicker] = useState(false);

  const insets = useSafeAreaInsets();

  const contextAPI = useContext(ContextAPI);

  useBackHandler(() => {
    Keyboard.dismiss();
    RNExitApp.exitApp();
    return true;
  });

  const onSelect = item => {
    setCountryCode(item.dial_code);
    setShowCountryPicker(false);
  };

  const handleSubmit = async () => {
    Keyboard.dismiss();

    console.log('working Now');

    const formatePhone = formatePhoneNumber(pNumber, countryCode);

    contextAPI.setLoading(true);

    try {
      const confirm = await auth().signInWithPhoneNumber(formatePhone);
      console.log({confirm});
      navigation.navigate('OTPVerification', {
        mobileN: formatePhone,
        confirmationCode: confirm,
      });
    } catch (err) {
      console.log({err});
      contextAPI.setLoading(false);
      Alert.alert('Error', err.message);
    }
    contextAPI.setLoading(false);
  };

  const AuthHeaderView = () => (
    <ImageBackground
      style={[
        styles.imgBgContainer,
        {
          height:
            Platform.OS == 'ios'
              ? verticalScale(250) - insets.top
              : verticalScale(250),
        },
      ]}
      imageStyle={styles.curveImgStyl}
      source={ImageView.headerCurveImg}
    />
  );

  const UserInputView = () => (
    <View
      style={{
        height: deviceHeight - verticalScale(250),
      }}>
      <View style={styles.headerAbsoluteIcon}>
        <Image
          style={styles.headerIcon}
          resizeMode="contain"
          source={ImageView.signInIcon}
        />
      </View>
      <View style={{height: '60%'}}>{InputTextView()}</View>
      <View style={styles.fotterAbsoluteIcon}>
        <Image
          style={styles.fotterIcon}
          resizeMode="contain"
          source={ImageView.towingImg}
        />
      </View>
    </View>
  );

  const InputTextView = () => (
    <View style={{}}>
      <Text style={styles.authTypeTxt}>
        {multiLanguages[contextAPI?.appLang]?.signIn}
      </Text>
      <Text style={styles.authTypeMsgTxt}>
        {multiLanguages[contextAPI?.appLang]?.signInMessg}
      </Text>
      <View style={{paddingVertical: scale(20)}}>
        <TextInputComponent
          placeholder={multiLanguages[contextAPI?.appLang]?.mNumber}
          value={pNumber}
          container={
            inputFocus == multiLanguages[contextAPI?.appLang]?.mNumber &&
            styles.activeTextInput
          }
          inputTxtStyl={[
            styles.inputTxtStyl,
            {
              fontFamily: Validation.isEmpty(pNumber)
                ? appFonts.hankenGroteskRegular
                : appFonts.hankenGroteskMedium,
            },
          ]}
          onFocus={() => {
            setInputFocus(multiLanguages[contextAPI?.appLang]?.mNumber);
          }}
          onBlur={() => {
            setInputFocus('');
          }}
          keyboardType="number-pad"
          onChangeText={text => setPNumber(text)}
          onSubmitEditing={() => {
            Keyboard.dismiss();
          }}
          returnKeyType={'done'}
          leftCustomIcon={LeftCustomIcon()}
        />
      </View>
      <View style={styles.sizeBox} />
      <ButtonComponent
        onBtnPress={handleSubmit}
        btnLabel={multiLanguages[contextAPI?.appLang]?.signIn}
      />
    </View>
  );

  const LeftCustomIcon = () => (
    <Pressable
      onPress={() => {
        Keyboard.dismiss();
        setShowCountryPicker(true);
      }}
      style={styles.customIconContainer}>
      <Text
        style={[
          styles.countryCodeTxt,
          {
            color:
              inputFocus !== multiLanguages[contextAPI?.appLang]?.mNumber
                ? colors.grayDark
                : colors.black,
          },
        ]}>
        {countryCode}
      </Text>
      <Image
        resizeMode="contain"
        style={[
          styles.downArrowIcon,
          {
            tintColor:
              inputFocus !== multiLanguages[contextAPI?.appLang]?.mNumber
                ? colors.grayDark
                : null,
          },
        ]}
        source={ImageView.downArrow}
      />
    </Pressable>
  );

  return (
    <View style={styles.container}>
      <CountryPicker
        enableModalAvoiding
        show={showCountryPicker}
        onBackdropPress={() => {
          setShowCountryPicker(false);
        }}
        onRequestClose={() => {
          setShowCountryPicker(false);
        }}
        pickerButtonOnPress={item => onSelect(item)}
        style={styles.countryPickerStyl}
      />
      <KeyboardAwareScrollView
        bounces={false}
        keyboardShouldPersistTaps="always"
        showsVerticalScrollIndicator={false}>
        {AuthHeaderView()}
        {UserInputView()}
      </KeyboardAwareScrollView>
      <SafeAreaView style={{flex: 0, backgroundColor: colors.white}} />
    </View>
  );
};

const styles = StyleSheet.create({
  countryPickerStyl: {
    // Styles for whole modal [View]
    modal: {
      height: verticalScale(300),
    },
    // Styles for input [TextInput]
    textInput: {
      height: scale(50),
      borderRadius: 10,
      paddingHorizontal: scale(25),
    },
    // Styles for country button [TouchableOpacity]
    countryButtonStyles: {
      height: scale(50),
      borderRadius: 10,
    },
    dialCode: {
      fontSize: moderateScale(13),
      fontFamily: appFonts.interRegular,
    },
    // Country name styles [Text]
    countryName: {
      fontSize: moderateScale(13),
      fontFamily: appFonts.interRegular,
    },
  },
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  imgBgContainer: {
    width: '100%',
  },
  curveImgStyl: {
    width: '100%',
    height: '100%',
    borderBottomLeftRadius: 85,
    borderBottomRightRadius: 85,
  },
  headerAbsoluteIcon: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: scale(-45),
  },
  headerIcon: {
    width: scale(100),
    height: scale(100),
  },
  fotterAbsoluteIcon: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: scale(100),
    height: '40%',
    zIndex: -1,
  },
  fotterIcon: {
    width: '100%',
    height: scale(131),
  },
  authTypeTxt: {
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(26),
    color: colors.primaryColor,
    textAlign: 'center',
  },
  authTypeMsgTxt: {
    paddingHorizontal: scale(5),
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(16),
    color: colors.suvaGrey,
    textAlign: 'center',
  },
  customIconContainer: {
    marginEnd: scale(10),
    height: scale(25),
    alignItems: 'center',
    flexDirection: 'row',
  },
  downArrowIcon: {
    marginLeft: scale(10),
    width: scale(20),
    height: scale(20),
  },
  countryCodeTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(16),
  },
  activeTextInput: {
    borderColor: colors.secondaryColor,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.17,
    shadowRadius: 2.54,
    elevation: 3,
  },
  sizeBox: {
    marginVertical: scale(5),
  },
  inputTxtStyl: {
    color: colors.primaryColor,
    fontSize: moderateScale(16),
  },
});

export default SignIn;
