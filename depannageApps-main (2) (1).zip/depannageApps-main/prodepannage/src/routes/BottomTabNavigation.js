import React from 'react';
import {SafeAreaView, StatusBar} from 'react-native';

import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {getFocusedRouteNameFromRoute} from '@react-navigation/native';

import {colors} from '../utils/constants';

import CustomTabBar from './CustomTabBar';
import Home from '../screens/home/Home';
import Order from '../screens/order/Order';
import MyProfile from '../screens/myProfile/MyProfile';
import Notification from '../screens/home/Notification';
import MapView from '../screens/home/MapView';
import JobDetail from '../screens/order/JobDetail';
import ChangeMobileNumber from '../screens/myProfile/ChangeMobileNumber';
import EditProfile from '../screens/myProfile/EditProfile';
import WebviewPage from '../screens/myProfile/WebviewPage';
import Support from '../screens/myProfile/Support';
import OTPVerification from '../screens/auth/OTPVerification';
import RateReview from '../screens/myProfile/RateReview';
import ManageAgents from './../screens/myProfile/ManageAgents';
import Wallet from '../screens/myProfile/Wallet';
import AddBankAccount from '../screens/myProfile/AddBankAccount';

const Stack = createNativeStackNavigator();

const HomeStackScreen = ({navigation, route}) => {
  return (
    <Stack.Navigator
      initialRouteName={'Home'}
      screenOptions={{
        headerShown: false,
        gestureEnabled: false,
      }}>
      <Stack.Screen name="Home" component={Home} />
      <Stack.Screen name="Notification" component={Notification} />
      <Stack.Screen name="JobDetail" component={JobDetail} />
      <Stack.Screen name="MapView" component={MapView} />
    </Stack.Navigator>
  );
};

const OrderStackScreen = ({navigation, route}) => {
  return (
    <Stack.Navigator
      initialRouteName={'Order'}
      screenOptions={{
        headerShown: false,
        gestureEnabled: false,
      }}>
      <Stack.Screen name="Order" component={Order} />
      <Stack.Screen name="JobDetail" component={JobDetail} />
      <Stack.Screen name="MapView" component={MapView} />
    </Stack.Navigator>
  );
};

const MyProfileStackScreen = ({navigation, route}) => {
  return (
    <Stack.Navigator
      initialRouteName={'MyProfile'}
      screenOptions={{
        headerShown: false,
        gestureEnabled: false,
      }}>
      <Stack.Screen name="MyProfile" component={MyProfile} />
      <Stack.Screen name="EditProfile" component={EditProfile} />
      <Stack.Screen name="ChangeMobileNumber" component={ChangeMobileNumber} />
      <Stack.Screen name="WebviewPage" component={WebviewPage} />
      <Stack.Screen name="Support" component={Support} />
      <Stack.Screen name="OTPVerification" component={OTPVerification} />
      <Stack.Screen name="RateReview" component={RateReview} />
      <Stack.Screen name="ManageAgents" component={ManageAgents} />
      <Stack.Screen name="Wallet" component={Wallet} />
      <Stack.Screen name="AddBankAccount" component={AddBankAccount} />
    </Stack.Navigator>
  );
};

const Tab = createBottomTabNavigator();

export default function BottomTabNavigation({navigation}) {
  return (
    <>
      <SafeAreaView style={{flex: 0, backgroundColor: colors.primaryColor}} />
      <SafeAreaView style={{flex: 1, backgroundColor: colors.white}}>
        <StatusBar
          animated
          translucent={false}
          backgroundColor={colors.primaryColor}
        />
        <Tab.Navigator
          initialRouteName="Home"
          tabBar={props => <CustomTabBar {...props} />}
          screenOptions={({route}) => ({
            headerShown: false,
            tabBarShowLabel: false,
            tabBarActiveBackgroundColor: colors.white,
            tabBarInactiveBackgroundColor: colors.white,
            tabBarHideOnKeyboard: true,
          })}>
          <Tab.Screen
            name="Home"
            component={HomeStackScreen}
            options={({route}) => ({
              tabBarStyle: (route => {
                const routeName = getFocusedRouteNameFromRoute(route) ?? 'Home';
                if (routeName !== 'Home') {
                  return {display: 'none'};
                }
                return {display: 'flex', borderTopWidth: 0};
              })(route),
            })}
          />
          <Tab.Screen
            name="Order"
            component={OrderStackScreen}
            options={({route}) => ({
              tabBarStyle: (route => {
                const routeName =
                  getFocusedRouteNameFromRoute(route) ?? 'Order';
                if (routeName !== 'Order') {
                  return {display: 'none'};
                }
                return {display: 'flex', borderTopWidth: 0};
              })(route),
            })}
          />
          <Tab.Screen
            name="MyProfile"
            component={MyProfileStackScreen}
            options={({route}) => ({
              tabBarStyle: (route => {
                const routeName =
                  getFocusedRouteNameFromRoute(route) ?? 'MyProfile';
                if (routeName !== 'MyProfile') {
                  return {display: 'none'};
                }
                return {display: 'flex', borderTopWidth: 0};
              })(route),
            })}
          />
        </Tab.Navigator>
      </SafeAreaView>
    </>
  );
}
