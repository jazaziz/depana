import React, {useContext} from 'react';

import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import FlashMessage from 'react-native-flash-message';

import Splash from '../screens/auth/Splash';
import SignIn from '../screens/auth/SignIn';
import OTPVerification from '../screens/auth/OTPVerification';
import ProfileSetup from '../screens/auth/ProfileSetup';
import BottomTabNavigation from './BottomTabNavigation';
import LoadingComponent from '../components/LoadingComponent';
import {ContextAPI} from '../contextAPI/contextProvider';

const Stack = createNativeStackNavigator();

export default function Router() {
  const contextAPI = useContext(ContextAPI);

  return (
    <>
      <LoadingComponent isVisible={contextAPI?.isLoading} />
      <NavigationContainer>
        <Stack.Navigator
          screenOptions={{
            headerShown: false,
            gestureEnabled: false,
          }}
          initialRouteName="Splash">
          <Stack.Screen name="Splash" component={Splash} />
          <Stack.Screen name="SignIn" component={SignIn} />
          <Stack.Screen name="OTPVerification" component={OTPVerification} />
          <Stack.Screen name="ProfileSetup" component={ProfileSetup} />
          <Stack.Screen name="Home" component={BottomTabNavigation} />
        </Stack.Navigator>
        <FlashMessage position="bottom" />
      </NavigationContainer>
    </>
  );
}
