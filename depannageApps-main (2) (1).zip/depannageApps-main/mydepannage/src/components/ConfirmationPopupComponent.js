import React, {useContext} from 'react';
import {StyleSheet, Text, View} from 'react-native';

import PropTypes from 'prop-types';
import {moderateScale, scale} from 'react-native-size-matters';

import ButtonComponent from './ButtonComponent';

import {colors} from '../utils/constants';
import appFonts from '../utils/appFonts';
import {multiLanguages} from '../utils/multiLanguages';
import {ContextAPI} from '../contextAPI/contextProvider';

const ConfirmationPopupComponent = props => {
  const contextAPI = useContext(ContextAPI);

  return (
    <View style={styles.container}>
      <View>
        <Text style={styles.titleTxt}>{props.titleMessage}</Text>
      </View>
      <View
        style={{
          width: '100%',
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
        {props.nagetiveBtnPress == null ? null : (
          <ButtonComponent
            onBtnPress={props.nagetiveBtnPress}
            container={[
              styles.positiveBtnContianer,
              {
                borderColor: colors.whisper,
                borderWidth: 1,
                backgroundColor: colors.lightRed,
              },
            ]}
            btnLabel={
              props.negativeTxt ?? multiLanguages[contextAPI?.appLang]?.no
            }
            btnLabelTxt={[
              styles.positiveTxt,
              {
                color: colors.grayishViolet,
              },
            ]}
          />
        )}
        <ButtonComponent
          onBtnPress={props.postiveBtnPress}
          container={styles.positiveBtnContianer}
          btnLabel={
            props.postiveTxt ?? multiLanguages[contextAPI?.appLang]?.yes
          }
          btnLabelTxt={styles.positiveTxt}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'space-around',
    flex: 1,
    padding: scale(20),
  },
  positiveBtnContianer: {
    flex: 0.47,
    borderRadius: scale(50),
    shadowOpacity: 0,
    shadowRadius: 0,
    elevation: 0,
  },
  titleTxt: {
    fontSize: moderateScale(22),
    fontFamily: appFonts.hankenGroteskBold,
    color: colors.msgColor,
    lineHeight: scale(31),
    textAlign: 'center',
  },
  positiveTxt: {
    fontSize: moderateScale(16),
    fontFamily: appFonts.hankenGroteskBold,
    color: colors.white,
    textAlign: 'center',
  },
});

ConfirmationPopupComponent.propTypes = {
  positiveTxt: PropTypes.string,
  titleMessage: PropTypes.string,
  postiveBtnPress: PropTypes.func,
  nagetiveBtnPress: PropTypes.func,
};
ConfirmationPopupComponent.defaultProps = {};

export default ConfirmationPopupComponent;
