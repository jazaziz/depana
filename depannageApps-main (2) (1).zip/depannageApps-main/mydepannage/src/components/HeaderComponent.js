import React from 'react';
import {
  Image,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import PropTypes from 'prop-types';
import {moderateScale, scale, verticalScale} from 'react-native-size-matters';

import {colors} from '../utils/constants';
import appFonts from '../utils/appFonts';

const HeaderComponent = props => {
  return (
    <View style={[styles.headerContainer, props.headerContainer]}>
      {props.leftIcon == null ? null : (
        <View style={props.leftIconContainer}>
          <Pressable style={{}} onPress={props.leftIconPress}>
            <Image
              resizeMode="contain"
              style={[styles.iconStyl, props.leftIconStyl]}
              source={props.leftIcon}
            />
          </Pressable>
        </View>
      )}
      {props.centerCustomComponent !== null ? (
        props.centerCustomComponent
      ) : (
        <View style={[styles.centerContainer, props.centerContainer]}>
          <Text style={[styles.headerTxt, props.headerTxt]}>
            {props.centerTxt}
          </Text>
        </View>
      )}
      {props.rightCustomIcon !== null ? (
        props.rightCustomIcon
      ) : props.leftIcon == null && props.rightIcon == null ? null : (
        <View
          style={{
            flex: 0.15,
            alignItems: 'flex-end',
          }}>
          {props.rightIcon == null ? null : (
            <Pressable
              // style={{alignItems: 'center', justifyContent: 'center'}}
              onPress={props.rightIconPress}>
              <Image
                resizeMode="contain"
                style={[styles.iconStyl, props.rightIconStyl]}
                source={props.rightIcon}
              />
            </Pressable>
          )}
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  headerContainer: {
    backgroundColor: colors.primaryColor,
    alignItems: 'center',
    flexDirection: 'row',
    height: verticalScale(45),
    paddingHorizontal: scale(20),
  },
  iconStyl: {
    width: scale(30),
    height: scale(30),
  },
  headerTxt: {
    textAlign: 'center',
    fontFamily: appFonts.hankenGroteskBold,
    color: colors.white,
    fontSize: moderateScale(18),
  },
  leftIconContainer: {
    flex: 0.15,
  },
  centerContainer: {
    flex: 1,
  },
});

HeaderComponent.propTypes = {
  headerContainer: PropTypes.object,
  leftIconStyl: PropTypes.object,
  rightIconStyl: PropTypes.object,
  headerTxt: PropTypes.object,
  leftIconContainer: PropTypes.object,
  centerContainer: PropTypes.object,
  centerCustomComponent: PropTypes.any,
  rightCustomIcon: PropTypes.any,
  leftIcon: PropTypes.any,
  rightIcon: PropTypes.any,
  centerTxt: PropTypes.string,
  leftIconPress: PropTypes.func,
  rightIconPress: PropTypes.func,
};
HeaderComponent.defaultProps = {
  leftIconContainer: styles.leftIconContainer,
  centerContainer: styles.centerContainer,
  centerCustomComponent: null,
  rightCustomIcon: null,
};

export default HeaderComponent;
