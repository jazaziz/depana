import React from 'react';
import {StyleSheet, FlatList, Pressable, Image, Text} from 'react-native';

import {moderateScale, scale} from 'react-native-size-matters';
import PropTypes from 'prop-types';

import {colors} from '../utils/constants';
import appFonts from '../utils/appFonts';

const TileOptionList = props => {
  const renderPhotoAlbumListItem = ({item, index}) => {
    return (
      <Pressable
        onPress={() => props.onTilePress(item)}
        style={[styles.tileItemContainer, props.tileItemContainer]}>
        <Image
          resizeMode="contain"
          source={item?.icon}
          style={[
            props.tileItemIcon,
            {
              width: item?.width,
              height: item?.height,
            },
          ]}
        />
        <Text
          style={[
            styles.tagTxt,
            {
              fontFamily: item?.selected
                ? appFonts.hankenGroteskBold
                : appFonts.hankenGroteskMedium,
              opacity: item?.selected ? 1 : 0.6,
            },
          ]}>
          {item?.tag}
        </Text>
      </Pressable>
    );
  };

  return (
    <FlatList
      data={props.listTileData}
      numColumns={2}
      contentContainerStyle={{
        flexGrow: 1,
        paddingBottom: scale(80),
        padding: scale(10),
        paddingHorizontal: scale(20),
        paddingVertical: props.verticalSpace,
      }}
      columnWrapperStyle={{
        marginBottom: scale(15),
        justifyContent: 'space-between',
      }}
      keyExtractor={item => item?.id}
      showsVerticalScrollIndicator={false}
      bounces={false}
      renderItem={renderPhotoAlbumListItem}
    />
  );
};

const styles = StyleSheet.create({
  tileItemContainer: {
    width: scale(150),
    height: scale(130),
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.white,
    paddingTop: scale(30),
    paddingBottom: scale(20),
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
  },
  tagTxt: {
    textAlign: 'center',
    fontSize: moderateScale(17),
    color: colors.darkBlueGrayis,
  },
});

TileOptionList.propTypes = {
  tileItemContainer: PropTypes.object,
  tileItemIcon: PropTypes.object,
  listTileData: PropTypes.array,
  verticalSpace: PropTypes.any,
  onTilePress: PropTypes.func,
};
TileOptionList.defaultProps = {
  tileItemContainer: styles.tileItemContainer,
  verticalSpace: scale(10),
};

export default TileOptionList;
