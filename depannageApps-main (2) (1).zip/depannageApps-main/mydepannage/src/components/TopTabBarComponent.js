import React from 'react';
import {StyleSheet, Text, View, Pressable} from 'react-native';

import {moderateScale, scale} from 'react-native-size-matters';
import PropTypes from 'prop-types';

import {colors} from '../utils/constants';
import appFonts from '../utils/appFonts';

const TopTabBarComponent = props => {
  return (
    <View style={props.container}>
      <View style={styles.roundContainer}>
        {props.titleOne == null ? null : (
          <Pressable
            onPress={() => props.onTabPress(props.titleOne)}
            style={[
              styles.tabContainer,
              {
                backgroundColor:
                  props.selectedTab == props.titleOne
                    ? colors.primaryColor
                    : null,
              },
            ]}>
            <Text
              style={
                props.selectedTab != props.titleOne
                  ? styles.deSelectedTxt
                  : styles.selectedTxt
              }>
              {props.titleOne}
            </Text>
          </Pressable>
        )}
        <Pressable
          onPress={() => props.onTabPress(props.titleSecond)}
          style={[
            styles.tabContainer,
            {
              backgroundColor:
                props.selectedTab == props.titleSecond
                  ? colors.primaryColor
                  : null,
            },
          ]}>
          <Text
            style={
              props.selectedTab != props.titleSecond
                ? styles.deSelectedTxt
                : styles.selectedTxt
            }>
            {props.titleSecond}
          </Text>
        </Pressable>
        <Pressable
          onPress={() => props.onTabPress(props.titleThird)}
          style={[
            styles.tabContainer,
            {
              backgroundColor:
                props.selectedTab == props.titleThird
                  ? colors.primaryColor
                  : null,
            },
          ]}>
          <Text
            style={
              props.selectedTab != props.titleThird
                ? styles.deSelectedTxt
                : styles.selectedTxt
            }>
            {props.titleThird}
          </Text>
        </Pressable>
        <Pressable
          onPress={() => props.onTabPress(props.titleFour)}
          style={[
            styles.tabContainer,
            {
              backgroundColor:
                props.selectedTab == props.titleFour
                  ? colors.primaryColor
                  : null,
            },
          ]}>
          <Text
            style={
              props.selectedTab != props.titleFour
                ? styles.deSelectedTxt
                : styles.selectedTxt
            }>
            {props.titleFour}
          </Text>
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  roundContainer: {
    backgroundColor: colors.gray98,
    borderColor: colors.gray89,
    borderWidth: 1,
    borderRadius: 18,
    paddingHorizontal: scale(6),
    paddingVertical: scale(4),
    alignItems: 'center',
    justifyContent: 'space-between',
    flexDirection: 'row',
  },
  tabContainer: {
    marginVertical: scale(2),
    flex: 0.33,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    height: scale(38),
  },
  selectedTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(13),
    textAlign: 'center',
    color: colors.white,
  },
  deSelectedTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(13),
    textAlign: 'center',
    color: colors.black,
    opacity: 0.5,
  },
});

TopTabBarComponent.propTypes = {
  container: PropTypes.object,
  onTabPress: PropTypes.func,
  titleOne: PropTypes.string,
  titleSecond: PropTypes.string,
  titleThird: PropTypes.string,
  titleFour: PropTypes.string,
  selectedTab: PropTypes.bool,
};
TopTabBarComponent.defaultProps = {};

export default TopTabBarComponent;
