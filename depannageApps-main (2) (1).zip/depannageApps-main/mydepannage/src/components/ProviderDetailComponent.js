import {useContext, useState} from 'react';
import {StyleSheet, View, Image, Pressable, FlatList} from 'react-native';

import {Text} from 'react-native-paper';
import {moderateScale, scale} from 'react-native-size-matters';
import PropTypes from 'prop-types';
import Stars from 'react-native-stars';

import appFonts from '../utils/appFonts';
import {ServicesStatus, colors} from '../utils/constants';
import {ImageView} from '../utils/imageView';
import {multiLanguages} from '../utils/multiLanguages';
import {ContextAPI} from '../contextAPI/contextProvider';

const ProviderDetailComponent = props => {
  const contextAPI = useContext(ContextAPI);
  const [order, setOrder] = useState(props?.order ?? null);

  const ProviderDetailItem = () => (
    <View style={styles.itemContainer}>
      <View style={{flex: 0.2}}>
        <Image
          resizeMode="contain"
          style={styles.proposalIcon}
          source={
            order?.proposal?.company?.logo
              ? {
                  uri: order?.proposal?.company?.logo,
                }
              : ImageView.dummyImg
          }
        />
      </View>
      <View style={styles.detailsContainer}>
        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
          <Text numberOfLines={1} style={styles.proposalTitleTxt}>
            {order?.proposal?.company?.companyName ?? '--'}
          </Text>
          <Pressable style={{zIndex: 1}} onPress={props.trackIconPress}>
            <Image
              resizeMode="contain"
              style={styles.trackIcon}
              source={ImageView.trackIcon}
            />
          </Pressable>
        </View>
        <Text numberOfLines={2} style={styles.proposalDescTxt}>
          {order?.proposal?.company?.location ?? '--'}
        </Text>
      </View>
    </View>
  );

  const renderReviewList = ({item}) => (
    <View style={styles.reviewItemContainer}>
      <Text numberOfLines={2} style={styles.userText}>
        {item?.user?.name ?? '--'}
      </Text>
      <View style={styles.reviewStar}>
        <Stars
          disabled={true}
          default={item?.rating ?? 0}
          spacing={scale(6)}
          starSize={scale(14)}
          count={5}
          fullStar={ImageView.activeStar}
          emptyStar={ImageView.star}
        />
      </View>
      <View style={styles.sizeBox} />
      <Text numberOfLines={5} style={styles.reviewDetailTxt}>
        {item?.review ?? '-'}
      </Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <Text style={styles.providerTxt}>
          {multiLanguages[contextAPI?.appLang]?.provider}
        </Text>
      </View>
      <View
        style={{
          paddingVertical: scale(15),
          paddingHorizontal: scale(20),
        }}>
        {ProviderDetailItem()}
      </View>
      {order?.status === ServicesStatus.COMPLETED && (
        <View style={{marginHorizontal: scale(20)}}>
          <Text style={styles.rateTxt}>
            {multiLanguages[contextAPI?.appLang]?.rateReview}
          </Text>
          <FlatList
            scrollEnabled={false}
            style={{flex: 1}}
            data={props?.orderReviews}
            keyExtractor={item => item?.id}
            showsVerticalScrollIndicator={false}
            ItemSeparatorComponent={() => (
              <View style={{marginVertical: scale(5)}} />
            )}
            renderItem={renderReviewList}
          />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginTop: 0,
    marginVertical: scale(20),
  },
  headerContainer: {
    marginHorizontal: scale(20),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  providerTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.black,
  },
  itemContainer: {
    padding: scale(10),
    backgroundColor: colors.white,
    borderRadius: 10,
    shadowColor: colors.primaryColor,
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
    flexDirection: 'row',
  },
  detailsContainer: {
    flex: 0.8,
    paddingVertical: scale(5),
    justifyContent: 'space-between',
  },
  proposalIcon: {
    borderRadius: 9,
    width: scale(50),
    height: scale(50),
  },
  proposalTitleTxt: {
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(16),
    color: colors.black,
    flex: 1,
    paddingRight: scale(5),
  },
  proposalDescTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(12),
    lineHeight: scale(15),
    color: colors.black,
    opacity: 0.8,
  },
  trackIcon: {
    width: scale(70),
    height: scale(20),
  },
  rateTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.darkShadeBlue,
    marginVertical: scale(15),
  },
  reviewItemContainer: {
    backgroundColor: colors.lightRed,
    padding: scale(15),
    borderRadius: 15,
  },
  userText: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(14),
    color: colors.darkShadeBlue,
  },
  reviewStar: {
    marginTop: scale(5),
    alignItems: 'flex-start',
  },
  reviewDetailTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(13),
    color: colors.suvaGrey,
  },
  timeTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(12),
    color: colors.approxGray,
  },
  sizeBox: {
    marginVertical: scale(5),
  },
});

ProviderDetailComponent.propTypes = {
  listData: PropTypes.func,
  trackIconPress: PropTypes.func,
};
ProviderDetailComponent.defaultProps = {};

export default ProviderDetailComponent;
