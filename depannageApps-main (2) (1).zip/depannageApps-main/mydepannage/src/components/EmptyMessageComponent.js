import React, { useContext } from 'react';
import {StyleSheet, Text, View} from 'react-native';

import {scale, moderateScale} from 'react-native-size-matters';

import appFonts from '../utils/appFonts';
import {colors} from '../utils/constants';
import {multiLanguages} from '../utils/multiLanguages';
import {ContextAPI} from '../contextAPI/contextProvider';

const EmptyMessageComponent = () => {
  const contextAPI = useContext(ContextAPI);

  return (
    <View style={styles.emptyContainer}>
      <Text style={styles.emptyTxt}>
        {multiLanguages[contextAPI?.appLang]?.noResult}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: scale(50),
  },
  emptyTxt: {
    fontSize: moderateScale(15),
    color: colors.black,
    fontFamily: appFonts.hankenGroteskMedium,
  },
});

export default EmptyMessageComponent;
