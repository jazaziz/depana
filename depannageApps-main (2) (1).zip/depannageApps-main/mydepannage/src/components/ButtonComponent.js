import React from 'react';
import {
  StyleSheet,
  Text,
  Image,
  Pressable,
} from 'react-native';

import PropTypes from 'prop-types';
import {scale, moderateScale} from 'react-native-size-matters';

import {colors} from '../utils/constants';
import appFonts from '../utils/appFonts';

const ButtonComponent = props => {
  return (
    <Pressable
      onPress={props.onBtnPress}
      style={[styles.container, props.container]}>
      {props.leftIcon != null ? (
        <Image
          resizeMode="contain"
          style={styles.btnIcon}
          source={props.leftIcon}
        />
      ) : null}
      <Text numberOfLines={1} style={[styles.btnLabelTxt, props.btnLabelTxt]}>
        {props.btnLabel}
      </Text>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.darkBlue,
    borderRadius: scale(50),
    height: scale(50),
    width: scale(200),
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
  },
  btnLabelTxt: {
    fontFamily: appFonts.hankenGroteskBold,
    color: colors.white,
    fontSize: moderateScale(16),
    textAlign: 'center',
  },
  btnIcon: {
    position: 'absolute',
    left: scale(30),
    width: scale(25),
    height: scale(25),
  },
});

ButtonComponent.propTypes = {
  container: PropTypes.object,
  btnLabelTxt: PropTypes.object,
  leftIcon: PropTypes.any,
  btnLabel: PropTypes.string,
  onBtnPress: PropTypes.func,
};
ButtonComponent.defaultProps = {
  container: styles.container,
  btnLabelTxt: styles.btnLabelTxt,
};

export default ButtonComponent;
