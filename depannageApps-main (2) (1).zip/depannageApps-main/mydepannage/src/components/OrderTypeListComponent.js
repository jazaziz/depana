import {StyleSheet, FlatList, View, Image, Pressable} from 'react-native';

import {Divider, Text} from 'react-native-paper';
import {moderateScale, scale} from 'react-native-size-matters';
import PropTypes from 'prop-types';

import {ServiceTypes, colors} from '../utils/constants';
import appFonts from '../utils/appFonts';
import {ImageView} from '../utils/imageView';
import {orderTypeMapping} from '../utils/helpers';

const OrderTypeListComponent = props => {
  const renderOrderListItem = ({item}) => (
    <Pressable
      onPress={() => {
        props.orderPress(item);
      }}
      style={styles.itemContainer}>
      <View style={styles.headerItemContainer}>
        <View style={styles.leftHeaderSection}>
          <Text numberOfLines={1} style={styles.typeTxt}>
            {orderTypeMapping(item.type)}
          </Text>
          <Text numberOfLines={1} style={styles.idTxt}>
            {`#${item.id.substring(0, 10)}`}
          </Text>
        </View>
        <View style={styles.rightHeaderSection}>
          <Text numberOfLines={1} style={styles.statusTxt}>
            {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
          </Text>
        </View>
      </View>
      <View style={styles.sizeBox} />
      <Divider style={styles.dividerLine} />
      <View style={styles.sizeBox} />
      <View style={styles.detailsContainer}>
        <View style={styles.detailsSection}>{CarTypeView(item)}</View>
        <View style={styles.detailsSection}>
          {item.type === ServiceTypes.VisitTechnique && CalendarView(item)}
        </View>
      </View>
      <View style={styles.sizeBox} />
      <View style={styles.detailsContainer}>
        <View style={styles.detailsSection}>{PickupLocationView(item)}</View>
        <View style={styles.detailsSection}>
          {![
            ServiceTypes.VisitTechnique,
            ServiceTypes.BatteryChange,
            ServiceTypes.FuelOrGas,
            ServiceTypes.TireChange,
          ].includes(item.type) && DropoffLocationView(item)}
        </View>
      </View>
      {NotesView(item)}
      <View style={styles.sizeBox} />
      <View style={styles.detailsContainer}>
        <View style={styles.detailsSection}>
          {/* {item.type === ServiceTypes.VisitTechnique && TaxiDriverView(item)} */}
        </View>
        <View style={styles.detailsSection}>{CalendarTickView(item)}</View>
      </View>
    </Pressable>
  );

  const CarTypeView = item => (
    <>
      <Image
        resizeMode="contain"
        style={styles.detailsIcon}
        source={ImageView.carType}
      />
      <View style={{marginHorizontal: scale(3)}} />
      <Text numberOfLines={1} style={styles.detailsTypeTxt}>
        {`${item?.year} ${item?.vehicleBrand} ${item?.vehicle}`}
      </Text>
      <View style={{marginHorizontal: scale(1)}} />
    </>
  );

  const CalendarView = item => (
    <>
      <Image
        resizeMode="contain"
        style={styles.detailsIcon}
        source={ImageView.calendar}
      />
      <View style={{marginHorizontal: scale(3)}} />
      <Text numberOfLines={1} style={styles.detailsTypeTxt}>
        {'12/10/2021 - 4:45 PM'}
      </Text>
      <View style={{marginHorizontal: scale(1)}} />
    </>
  );

  const PickupLocationView = item => (
    <>
      <Image
        resizeMode="contain"
        style={styles.detailsIcon}
        source={ImageView.locationSecond}
      />
      <View style={{marginHorizontal: scale(3)}} />
      <Text numberOfLines={3} style={styles.detailsTypeTxt}>
        {item?.pickUp?.address || '--'}
      </Text>
      <View style={{marginHorizontal: scale(1)}} />
    </>
  );

  const DropoffLocationView = item => (
    <>
      <Image
        resizeMode="contain"
        style={styles.detailsIcon}
        source={ImageView.locationSecond}
      />
      <View style={{marginHorizontal: scale(3)}} />
      <Text numberOfLines={3} style={styles.detailsTypeTxt}>
        {item?.dropOff?.address || '--'}
        hello
      </Text>
      <View style={{marginHorizontal: scale(1)}} />
    </>
  );

  const TaxiDriverView = item => (
    <>
      <Image
        resizeMode="contain"
        style={styles.detailsIcon}
        source={ImageView.taxiDriver}
      />
      <View style={{marginHorizontal: scale(3)}} />
      <Text numberOfLines={1} style={styles.detailsTypeTxt}>
        {item?.visitTechnique}
      </Text>
      <View style={{marginHorizontal: scale(1)}} />
    </>
  );

  const CalendarTickView = item => {
    const createdAtDate = new Date(item.createdAt.toDate());
    const formattedDate = createdAtDate.toLocaleDateString('en-US', {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric',
    });
    const formattedTime = createdAtDate.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });

    return (
      <>
        <Image
          resizeMode="contain"
          style={styles.detailsIcon}
          source={ImageView.calendarTick}
        />
        <View style={{marginHorizontal: scale(3)}} />
        <Text numberOfLines={1} style={styles.detailsTypeTxt}>
          {`${formattedDate}-${formattedTime}`}
          {/* {'12/10/2021 - 4:45 PM'} */}
        </Text>
        <View style={{marginHorizontal: scale(1)}} />
      </>
    );
  };

  const NotesView = item => (
    <>
      <View style={styles.sizeBox} />
      <View style={styles.detailsContainer}>
        <View
          style={[
            styles.detailsSection,
            {
              flex: 1,
            },
          ]}>
          <Image
            resizeMode="contain"
            style={styles.detailsIcon}
            source={ImageView.noteText}
          />
          <View style={{marginHorizontal: scale(3)}} />
          <Text style={styles.detailsTypeTxt}>
            {item?.contactInfo?.note || '--'}
          </Text>
          <View style={{marginHorizontal: scale(1)}} />
        </View>
      </View>
    </>
  );

  return (
    <FlatList
      contentContainerStyle={{
        paddingTop: scale(10),
        paddingHorizontal: scale(20),
        flexGrow: 1,
        paddingBottom: scale(80),
      }}
      bounces={false}
      ItemSeparatorComponent={<View style={{marginBottom: scale(15)}} />}
      showsVerticalScrollIndicator={false}
      keyExtractor={item => item?.id}
      data={props.listData}
      renderItem={renderOrderListItem}
    />
  );
};

const styles = StyleSheet.create({
  itemContainer: {
    backgroundColor: colors.white,
    borderRadius: 7,
    padding: scale(12),
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 5,
  },
  headerItemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  leftHeaderSection: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    paddingRight: scale(5),
  },
  rightHeaderSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  typeTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.gray33,
    maxWidth: '70%',
  },
  idTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(12),
    color: colors.black,
    opacity: 0.4,
    flex: 1,
    paddingLeft: scale(10),
  },
  statusTxt: {
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(14),
    color: colors.black,
    textAlign: 'right',
    color: '#978800',
  },
  dividerLine: {
    height: 1,
    backgroundColor: colors.black,
    opacity: 0.1,
  },
  sizeBox: {
    marginVertical: scale(5),
  },
  detailsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  detailsSection: {
    flexDirection: 'row',
    flex: 0.5,
  },
  detailsTypeTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(12),
    color: colors.gray40,
    flex: 1,
  },
  detailsIcon: {
    width: scale(16),
    height: scale(16),
  },
});

OrderTypeListComponent.propTypes = {
  listData: PropTypes.array,
  orderPress: PropTypes.func,
};
OrderTypeListComponent.defaultProps = {};

export default OrderTypeListComponent;
