import {useContext} from 'react';
import {StyleSheet, View, Image, FlatList, Pressable} from 'react-native';

import {Text} from 'react-native-paper';
import {moderateScale, scale} from 'react-native-size-matters';
import PropTypes from 'prop-types';

import appFonts from '../utils/appFonts';
import {colors} from '../utils/constants';
import {ImageView} from '../utils/imageView';
import {ContextAPI} from '../contextAPI/contextProvider';
import {multiLanguages} from '../utils/multiLanguages';

const ProposalListComponent = props => {
  const contextAPI = useContext(ContextAPI);

  const renderProposalListItem = ({item}) => (
    <Pressable
      onPress={() => {
        props.onPraposalPress(item);
      }}
      style={styles.itemContainer}>
      <View style={{flex: 0.2}}>
        <Image
          resizeMode="contain"
          style={styles.proposalIcon}
          source={
            item?.company?.logo
              ? {uri: item?.company?.logo}
              : ImageView.dummyImg
          }
        />
      </View>
      <View style={styles.detailsContainer}>
        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
          <Text numberOfLines={1} style={styles.proposalTitleTxt}>
            {item?.company?.companyName ?? '-'}
          </Text>
          <Text numberOfLines={1} style={styles.proposalPriceTxt}>
            {`${item?.amount} MAD` ?? '0 MAD'}
          </Text>
        </View>
        <Text numberOfLines={2} style={styles.proposalDescTxt}>
          {item?.company?.about ?? '--'}
        </Text>
      </View>
    </Pressable>
  );

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <Text style={styles.proposalTxt}>
          {multiLanguages[contextAPI?.appLang]?.proposals}
          <Text
            style={{
              color: colors.primaryColor,
            }}>
            {`(${props.listData?.length})`}
          </Text>
        </Text>
        <Pressable
          onPress={props.filterPress}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
          }}>
          <Text style={styles.shortingTxt}>
            {multiLanguages[contextAPI?.appLang]?.shortPrice}
          </Text>
          <Image
            resizeMode="contain"
            style={styles.downArrowIcon}
            source={ImageView.downArrowSecond}
          />
        </Pressable>
      </View>
      <FlatList
        scrollEnabled={false}
        contentContainerStyle={{
          paddingVertical: scale(15),
          paddingHorizontal: scale(20),
        }}
        bounces={false}
        ItemSeparatorComponent={<View style={{marginBottom: scale(15)}} />}
        showsVerticalScrollIndicator={false}
        keyExtractor={item => item?.id}
        data={props.listData}
        renderItem={renderProposalListItem}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginTop: 0,
    marginVertical: scale(20),
  },
  headerContainer: {
    marginHorizontal: scale(20),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  proposalTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.black,
  },
  shortingTxt: {
    fontFamily: appFonts.metropolisRegular,
    fontSize: moderateScale(14),
    color: colors.black,
    opacity: 0.7,
  },
  downArrowIcon: {
    marginLeft: scale(8),
    width: scale(11),
    height: scale(8),
  },
  itemContainer: {
    padding: scale(10),
    backgroundColor: colors.white,
    borderRadius: 10,
    shadowColor: colors.primaryColor,
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
    flexDirection: 'row',
  },
  detailsContainer: {
    flex: 0.8,
    paddingVertical: scale(5),
    justifyContent: 'space-between',
  },
  proposalIcon: {
    borderRadius: 9,
    width: scale(50),
    height: scale(50),
  },
  proposalTitleTxt: {
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(16),
    color: colors.black,
    flex: 1,
    paddingRight: scale(5),
  },
  proposalPriceTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(14),
    color: colors.primaryColor,
  },
  proposalDescTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(12),
    lineHeight: scale(15),
    color: colors.black,
    opacity: 0.8,
  },
});

ProposalListComponent.propTypes = {
  listData: PropTypes.func,
  filterPress: PropTypes.func,
  onPraposalPress: PropTypes.func,
};
ProposalListComponent.defaultProps = {};

export default ProposalListComponent;
