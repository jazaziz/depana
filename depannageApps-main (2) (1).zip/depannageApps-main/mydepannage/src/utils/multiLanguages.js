export const multiLanguages = {
  //English
  0: {
    home: 'Home',

    // Sign In Page Strings
    signIn: 'Sign in',
    signInMessg: 'Please sign in your account to continue',

    // OTP Verification Page Strings
    otpVerification: 'OTP Verification',
    otpVerificationMessg: 'We just sent you 6 digit OTP code\nat ',
    confirmNow: 'Confirm Now',
    resendCode: 'Resend Code',

    // Attention Page Strings
    attention: 'Attention',
    attentionMessg:
      'For your safety, please take the following security measures',
    ok: 'Ok',
    turnOnLight: 'Turn on traffic light',
    wearJacket: 'Wear a yellow jacket',
    placement: 'Placement of the safety triangle',
    pleaseHold: 'Please hold on to the barrier',

    // Home Page Strings
    welcome: 'Welcome',
    towingService: 'Towing Service',
    fuelGasFill: 'Fuel/ Gas Fill',
    tireChange: 'Tire Change',
    batteryChange: 'Battery Change',
    taxi: 'Taxi',
    visitTechnique: 'Visit Technique',

    // Notification Page Strings
    notification: 'Notification',

    // Service Form Page Strings
    vehicleDetail: 'Vehicle Detail',
    selectVehicle: 'Select Your Vehicle',
    brand: 'Brand',
    registrationNumber: 'Registration Number',
    year: 'Year',
    maker: 'Maker',
    insurance: 'Insurance',
    yes: 'Yes',
    no: 'No',
    selectInsurance: 'Select insurance/ADM service',
    locationInformation: 'Location Information',
    enterLocation: 'Enter Your Location',
    pickup: 'Pickup',
    dropOff: 'Drop-off',
    contactInformation: 'Contact Information',
    fullName: 'Full Name',
    emailAddress: 'Email Address',
    mobileNumber: 'Mobile Number',
    note: 'Note*',
    selectVisitTechnique: 'Select Your Visit Technique',
    dateTime: 'Date & Time',
    date: 'Date',
    time: 'Time',
    submit: 'Submit',
    successMsg: 'You have successfully submitted',
    takeCalmMsg: 'now stay calm and wait for proposal from various provider',
    thankMsg: 'Thank You',
    waitMsg: 'Waiting For Service Provider',
    refundTxt: 'is refunded to you My-Depannage wallet.',

    // Map Page Strings
    myDepannage: 'My Depannage',
    pickupLocation: 'Pick up Location',
    dropoffLocation: 'Drop-off Location',
    pickupSecond: 'Pick up',

    // Order Page Strings
    order: 'Order',
    pending: 'Pending',
    onGoing: 'On going',
    completed: 'Completed',
    cancelled: 'Cancelled',

    // Service Details Page Strings
    serviceDetails: 'Service Details',
    cancel: 'Cancel',
    bookingDateTime: 'Booking Date & Time',
    proposals: 'Proposals ',
    shortPrice: 'Short by price',
    shortDistances: 'Short by distances',
    price: 'Price:',
    amount: 'Amount',
    awardJob: 'Award Job',
    viewProfile: 'View Profile',
    provider: 'Provider',
    writeReview: 'Write Your Review',
    writeReviewSecond: 'Write Review',

    // View Profile Strings
    viewProfile: 'View Profile',
    rateReview: 'Rate & Reviews',

    // Payment Method Page Strings
    paymentMethod: 'Payment Method',
    payCard: 'Pay by Credit Card',
    payCash: 'Pay by Cash',
    cPayment: 'Confirm Payment',
    walletMsg: 'Use available wallet balance',

    // Profile Page Strings
    profile: 'Profile',
    notifications: 'Notifications',
    CMobileNumber: 'Change mobile number',
    terms: 'Terms & conditions',
    termsSecond: 'Terms & Conditions',
    privacy: 'Privacy policy',
    privacySecond: 'Privacy Policy',
    support: 'Support',
    deleteAccount: 'Delete account',
    logout: 'Log out',
    logout: 'Log out',

    // Change Number Page Strings
    CMobileNumberSecond: 'Change Mobile Number',
    cNumber: 'Change Number',
    cNumberMsg:
      'Please enter your any new mobile number which you want to change',
    save: 'Save',

    // Edit Profile Page Strings
    editProfile: 'Edit Profile',

    // Support Page Strings
    contactUs: 'Contact Us',
    emailUs: 'Email Us',

    // App Validation messages strings
    noResult: 'No data found.',
    companyName: 'Company Name',
    mNumber: 'Mobile Number',
    location: 'Location',
    aboutCompany: 'About Company',
    uploadDocument: 'Upload Document',
    continue: 'Continue',
    plsEnterOTP: 'Enter OTP',
    submit: 'Submit',
    saveChanges: 'Save Changes',
    plsEnterOtpMsg: 'Please enter your OTP code.',
    OTPIncorrect: 'Entered OTP is incorrect.',
    logoutAccountMsg: 'Are you sure you want to logout?',
    deleteAccountMsg: 'Are you sure you want to delete this account?',
  },
  //French
  1: {
    home: 'Maison',

    // Sign In Page Strings
    signIn: "S'identifier",
    signInMessg: 'Veuillez vous connecter à votre compte pour continuer',

    // OTP Verification Page Strings
    otpVerification: 'Vérification OTP',
    otpVerificationMessg:
      'Nous venons de vous envoyer un code OTP à 4 chiffres\nat',
    confirmNow: 'Confirmer maintenant',
    resendCode: 'Renvoyer le code',

    // Attention Page Strings
    attention: 'Attention',
    attentionMessg:
      'Pour votre sécurité, veuillez prendre les mesures de sécurité suivantes',
    ok: "D'accord",
    turnOnLight: 'Allumer le feu de circulation',
    wearJacket: 'Porter une veste jaune',
    placement: 'Placement du triangle de sécurité',
    pleaseHold: 'Merci de vous tenir à la barrière',

    // Home Page Strings
    welcome: 'Bienvenue',
    towingService: 'Service de remorquage',
    fuelGasFill: 'Remplissage de carburant/gaz',
    tireChange: 'Changement de pneu',
    batteryChange: 'Changement de batterie',
    taxi: 'Taxi',
    visitTechnique: 'Visite technique',

    // Notification Page Strings
    notification: 'Notification',

    // Service Form Page Strings
    vehicleDetail: 'Les détails du véhicule',
    selectVehicle: 'Sélectionnez votre véhicule',
    brand: 'Marque',
    registrationNumber: "Numéro d'enregistrement",
    year: 'Année',
    maker: 'Fabricante',
    insurance: 'Assurance',
    yes: 'Oui',
    no: 'Non',
    selectInsurance: "Sélectionnez le service d'assurance/ADM",
    locationInformation: 'Information de Lieu',
    enterLocation: 'Entrez votre emplacement',
    pickup: 'Ramasser',
    dropOff: 'Déposer',
    contactInformation: 'Coordonnées',
    fullName: 'Nom et prénom',
    emailAddress: 'Adresse e-mail',
    mobileNumber: 'Numéro de portable',
    note: 'Note*',
    selectVisitTechnique: 'Sélectionnez votre technique de visite',
    dateTime: 'Date et heure',
    date: 'Date',
    time: 'Temps',
    submit: 'Soumettre',
    successMsg: 'Vous avez soumis avec succès',
    takeCalmMsg:
      'maintenant restez calme et attendez la proposition de divers fournisseurs',
    thankMsg: 'Merci',
    waitMsg: 'En attente du fournisseur de services',
    refundTxt: 'est remboursé sur votre portefeuille My-Depannage.',

    // Map Page Strings
    myDepannage: 'Mon Dépannage',
    pickupLocation: 'Lieu dep ramassage',
    dropoffLocation: 'Point de chute',
    pickupSecond: 'Ramasser',

    // Order Page Strings
    order: 'Commande',
    pending: 'En attente',
    onGoing: 'En cours',
    completed: 'Completed',
    cancelled: 'Annulé',

    // Service Details Page Strings
    serviceDetails: 'Détails des services',
    cancel: 'Annuler',
    bookingDateTime: 'Date et heure de réservation',
    proposals: 'Les propositions ',
    shortPrice: 'Court par prix',
    shortDistances: 'Court par distances',
    price: 'Prix:',
    amount: 'Montante',
    awardJob: "Offre d'emploi",
    viewProfile: 'Voir le profil',
    provider: 'Fournisseuse',
    writeReview: 'Donnez votre avis',
    writeReviewSecond: 'Ecrire une critique',

    // View Profile Strings
    viewProfile: 'Voir le profil',
    rateReview: 'Note et avis',

    // Payment Method Page Strings
    paymentMethod: 'Mode de paiement',
    payCard: 'Payer par carte de crédit',
    payCash: 'Payer en espèce',
    cPayment: 'Confirmer le paiement',
    walletMsg: 'Utiliser le solde du portefeuille disponible',

    // Profile Page Strings
    profile: 'Profil',
    notifications: 'Avis',
    CMobileNumber: 'Changer de numéro de portable',
    terms: 'Termes et conditions',
    termsSecond: 'termes et conditions',
    privacy: 'Politique de confidentialité',
    privacySecond: 'politique de confidentialité',
    support: 'Soutien',
    deleteAccount: 'Supprimer le compte',
    logout: 'Se déconnecter',

    // Change Number Page Strings
    CMobileNumberSecond: 'Changer de numéro de portable',
    cNumber: 'Changer de numéro',
    cNumberMsg:
      'Veuillez entrer votre nouveau numéro de mobile que vous souhaitez modifier',
    save: 'Sauvegarder',

    // Edit Profile Page Strings
    editProfile: 'Editer le profil',

    // Support Page Strings
    contactUs: 'Contactez-nous',
    emailUs: 'Envoyez-nous un email',

    // App Validation messages strings
    noResult: 'Aucune donnée disponible.',
    companyName: "Nom de l'entreprise",
    mNumber: 'Numéro de portable',
    location: 'Emplacement',
    aboutCompany: 'À propos de la société',
    uploadDocument: 'Télécharger un document',
    continue: 'Continuer',
    plsEnterOTP: 'Entrez OTP',
    submit: 'Soumettre',
    saveChanges: 'Sauvegarder les modifications',
    plsEnterOtpMsg: 'Veuillez entrer votre code OTP.',
    OTPIncorrect: "L'OTP saisi est incorrect.",
    logoutAccountMsg: 'Êtes-vous sûr de vouloir vous déconnecter?',
    deleteAccountMsg: 'Voulez-vous vraiment supprimer ce compte ?',
  },
};
