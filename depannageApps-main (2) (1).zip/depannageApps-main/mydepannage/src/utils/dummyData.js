export const dummuData = {
  VIHICLE_TYPE_DATA: [
    {
      id: 1,
      tag: 'Car',
    },
    {
      id: 2,
      tag: 'Bus',
    },
    {
      id: 3,
      tag: 'Bike',
    },
    {
      id: 4,
      tag: 'Truck',
    },
  ],

  TECHNIQUE_TYPE_DATA: [
    {
      id: 1,
      tag: 'Periodical',
    },
    {
      id: 2,
      tag: 'Mutation',
    },
    {
      id: 3,
      tag: 'voluntary',
    },
  ],

  TECHNIQUE_TYPE_DATA: [
    {
      id: 1,
      tag: 'Periodical',
    },
    {
      id: 2,
      tag: 'Mutation',
    },
    {
      id: 3,
      tag: 'voluntary',
    },
    {
      id: 4,
      tag: 'Service',
    },
    {
      id: 5,
      tag: 'Wash',
    },
  ],

  TILE_OPTION_DATA: [
    {
      id: 1,
    },
    {
      id: 2,
    },
    {
      id: 3,
    },
    {
      id: 4,
    },
    {
      id: 5,
    },
    {
      id: 6,
    },
  ],
};

export default {dummuData};
