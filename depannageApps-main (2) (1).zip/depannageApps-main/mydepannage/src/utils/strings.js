export const Strings = {
  // Sign In Page Strings
  signIn: 'Sign in',
  signInMessg: 'Please sign in your account to continue',

  // OTP Verification Page Strings
  otpVerification: 'OTP Verification',
  otpVerificationMessg: 'We just sent you 4 digit OTP code\nat ',
  confirmNow: 'Confirm Now',
  resendCode: 'Resend Code',

  // Attention Page Strings
  attention: 'Attention',
  attentionMessg:
    'For your safety, please take the following security measures',
  ok: 'Ok',
  turnOnLight: 'Turn on traffic light',
  wearJacket: 'Wear a yellow jacket',
  placement: 'Placement of the safety triangle',
  pleaseHold: 'Please hold on to the barrier',

  // Home Page Strings
  welcome: 'Welcome',
  towingService: 'Towing Service',
  fuelGasFill: 'Fuel/ Gas Fill',
  tireChange: 'Tire Change',
  batteryChange: 'Battery Change',
  taxi: 'Taxi',
  visitTechnique: 'Visit Technique',

  // Notification Page Strings
  notification: 'Notification',

  // Service Form Page Strings
  vehicleDetail: 'Vehicle Detail',
  selectVehicle: 'Select Your Vehicle',
  brand: 'Brand',
  registrationNumber: 'Registration Number',
  year: 'Year',
  maker: 'Maker',
  insurance: 'Insurance',
  yes: 'Yes',
  no: 'No',
  selectInsurance: 'Select insurance/ADM service',
  locationInformation: 'Location Information',
  enterLocation: 'Enter Your Location',
  pickup: 'Pickup',
  dropOff: 'Drop-off',
  contactInformation: 'Contact Information',
  fullName: 'Full Name',
  emailAddress: 'Email Address',
  mobileNumber: 'Mobile Number',
  note: 'Note*',
  visitTechnique: 'Visit Technique',
  selectVisitTechnique: 'Select Your Visit Technique',
  dateTime: 'Date & Time',
  dateTime: 'Date & Time',
  date: 'Date',
  time: 'Time',
  submit: 'Submit',
  successMsg: 'You have successfully submitted ',
  takeCalmMsg: 'now stay calm and wait for proposal from various provider',
  thankMsg: 'Thank You',
  waitMsg: 'Waiting For Service Provider',
  refundTxt: 'is refunded to you My-Depannage wallet.',

  // Map Page Strings
  myDepannage: 'My Depannage',
  pickupLocation: 'Pick up Location',
  dropoffLocation: 'Drop-off Location',
  pickupSecond: 'Pick up',

  // Order Page Strings
  order: 'Order',
  onGoing: 'On going',
  completed: 'Completed',
  cancelled: 'Cancelled',

  // Service Details Page Strings
  serviceDetails: 'Service Details',
  cancel: 'Cancel',
  bookingDateTime: 'Booking Date & Time',
  proposals: 'Proposals ',
  shortPrice: 'Short by price',
  shortDistances: 'Short by distances',
  price: 'Price:',
  amount: 'Amount',
  awardJob: 'Award Job',
  viewProfile: 'View Profile',
  provider: 'Provider',
  writeReview: 'Write Your Review',
  writeReviewSecond: 'Write Review',

  // View Profile Strings
  viewProfile: 'View Profile',
  rateReview: 'Rate & Reviews',

  // Payment Method Page Strings
  paymentMethod: 'Payment Method',
  payCard: 'Pay by Credit Card',
  payCash: 'Pay by Cash',
  cPayment: 'Confirm Payment',
  walletMsg: 'Use available wallet balance',

  // Profile Page Strings
  profile: 'Profile',
  notifications: 'Notifications',
  CMobileNumber: 'Change mobile number',
  terms: 'Terms & conditions',
  termsSecond: 'Terms & Conditions',
  privacy: 'Privacy policy',
  privacySecond: 'Privacy Policy',
  support: 'Support',
  deleteAccount: 'Delete account',
  logout: 'Log out',

  // Change Number Page Strings
  CMobileNumberSecond: 'Change Mobile Number',
  cNumber: 'Change Number',
  cNumberMsg:
    'Please enter your any new mobile number which you want to change',
  save: 'Save',

  // Edit Profile Page Strings
  editProfile: 'Edit Profile',

  // Support Page Strings
  contactUs: 'Contact Us',
  emailUs: 'Email Us',

  // App Validation messages strings
  noResult: 'No data found.',
  companyName: 'Company Name',
  mNumber: 'Mobile Number',
  location: 'Location',
  aboutCompany: 'About Company',
  uploadDocument: 'Upload Document',
  continue: 'Continue',
  plsEnterOTP: 'Enter OTP',
  submit: 'Submit',
  saveChanges: 'Save Changes',
  plsEnterOtpMsg: 'Please enter your OTP code.',
  OTPIncorrect: 'Entered OTP is incorrect.',
  logoutAccountMsg: 'Are you sure you want to logout?',
  deleteAccountMsg: 'Are you sure you want to delete this account?',
};
