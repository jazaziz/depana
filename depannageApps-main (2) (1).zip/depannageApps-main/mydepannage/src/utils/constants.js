import moment from 'moment';
import {showMessage} from 'react-native-flash-message';
import {moderateScale} from 'react-native-size-matters';
import AsyncStorage from '@react-native-async-storage/async-storage';

import appFonts from './appFonts';
import {keyPref} from '../service/ApiKeys';

export const showErrorMessage = message => {
  showMessage({
    message: message,
    type: 'error',
    backgroundColor: colors.veryDark,
    titleStyle: {
      fontFamily: appFonts.openSansBold,
      fontSize: moderateScale(15),
    },
    color: colors.white,
  });
};

// For common log display function
export const logDisplay = function (key, value) {
  let isLog = true;
  if (isLog) {
    return console.log(key, value);
  }
  return null;
};

export const showSuccessMessage = message => {
  showMessage({
    message: message,
    type: 'success',
    backgroundColor: colors.veryDark,
    titleStyle: {
      fontFamily: appFonts.openSansBold,
      fontSize: moderateScale(15),
    },
    color: colors.white,
  });
};

export const POPUP_TYPE = {
  SUCCESS: 'SUCCESS',
  CONFIRM: 'CONFIRM',
};

export const colors = {
  transparent: 'transparent',
  white: '#FFFFFF',
  black: '#000000',
  primaryColor: '#1E42B4',
  secondaryColor: '#7681F4',
  darkBlue: '#1E3683',
  suvaGrey: '#8E8E8E',
  softPeach: '#E5E6EA',
  gray: '#A2A2A2',
  gray15: '#262626',
  darkBlueGrayis: '#070D1E',
  blackBlue: '#2B3A42',
  dimGray: '#6C6C6C',
  gray89: '#E5E3E3',
  gray98: '#FAFAFA',
  gray33: '#545454',
  gray40: '#666666',
  silver: '#C4C4C4',
  approxBlack: '#0C0C0C',
  darkShadeBlue: '#101327',
  lightRed: '#F6F6F6',
  approxGray: '#7C7C7C',
  grayishViolet: '#424143',
  blackPearl: '#191D23',
  jungleGren: '#092C22',
  lightBlue: '#0A152F',
  msgColor: '#27343E',
  whisper: '#E7E7E7',
};

export const config = {
  getUserData: async () => {
    let getData = await AsyncStorage.getItem(keyPref.USER_DATA);
    logDisplay('>>>>>>>>> USER LOGIN DATA ', getData);
    return JSON.parse(getData);
  },
  getTimesagoUTCtoLocal: dateTime => {
    const getTimesAgo = moment
      .utc(dateTime)
      .local()
      .startOf('seconds')
      .fromNow();
    return getTimesAgo;
  },
  convertUTCToLocal: (dateTime, passFormat, getBackFormat) => {
    // logDisplay('>>>>>> DATE TIME WITH FORMAT ', dateTime + ' ' + passFormat); // 2015-09-13 03:39:27
    var utcDate = moment
      .utc(dateTime, passFormat)
      .format(config.commonDateTimeFormat);
    var stillUtc = moment.utc(utcDate).toDate();
    // logDisplay('>>>>>> UTC ', stillUtc); // 2015-09-13 09:39:27
    var local = moment(stillUtc).local().format(config.commonDateTimeFormat);
    // logDisplay('>>>>>> LOCAL ', local); // 2015-09-13 09:39:27
    const convertedDateTime = moment(local).format(getBackFormat);
    // logDisplay('>>>>>> CONVERT DATE OR TIME ', convertedDateTime); // 2015-09-13 09:39:27
    return convertedDateTime;
  },
  convertLocalToUTC: (dateTime, passFormat, getBackFormat) => {
    // logDisplay('>>>>>> DATE TIME WITH FORMAT ', dateTime + ' ' + passFormat); // 2015-09-13 03:39:27
    const UTCDateTime = moment(dateTime, passFormat)
      .utc()
      .format(config.commonDateTimeFormat);
    // logDisplay('>>>>>> UTC ', UTCDateTime); // 2015-09-13 09:39:27
    const convertedDateTime = moment(UTCDateTime).format(getBackFormat);
    // logDisplay('>>>>>> CONVERTED UTC DATE TIME FORMATE ', convertedDateTime); // 2015-09-13 09:39:27
    return convertedDateTime;
  },
  DOB_FORMAT: 'DD, MMM YYYY',
  TIME_FORMAT: 'hh:mm A',
  BACKEND_TIME_FORMAT: 'HH:mm',
  BACKEND_DATE_FORMAT: 'YYYY-MM-DD',
  commonDateTimeFormat: 'YYYY-MM-DD HH:mm:ss',
};

export const FirebaseCollections = {
  Services: 'services',
  Companies: 'companies',
  Agents: 'agents',
  Proposals: 'proposals',
  OrderReviews: 'orderReviews',
  userSettings: 'userSettings',
  notifications: 'notifications',
};

export const ServicesStatus = {
  PENDING: 'pending',
  ON_GOING: 'onGoing',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled',
};

export const ServiceTypes = {
  TowingService: 'towingService',
  FuelOrGas: 'fuelOrGas',
  TireChange: 'tireChange',
  BatteryChange: 'batteryChange',
  Texi: 'texi',
  VisitTechnique: 'visitTechnique',
};

export const locationTypes = {
  pickUp: 'pickup',
  dropOff: 'dropOff',
};

export const googleMapApiKey = 'AIzaSyBnp2G072cphpIQYMEfdCcYRyXwoNxgPek';

export const FirebaseServerKey =
  'AAAAlaQyatY:APA91bGbMHDv_s9wBlf7n0CFYRX5Tne1DWi1DN9B4ruri24cZYpXkesTFkNxyl-fYziNiWjx_GI9JCynKVlOxyHkdj3sho-aIG1-9XuNEbTmiuuJZGVGv3_PqMEV1gC3XtFU21gYiqhO';

export const imageOptions = {
  Camera: 'camera',
  Gallery: 'gallery',
};

export const LocalStorageKeys = {
  USER_DATA: 'userData',
};

export default {
  colors,
  config,
};
