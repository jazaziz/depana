export default AppFonts = {
  hankenGroteskRegular: 'HankenGrotesk-Regular',
  hankenGroteskMedium: 'HankenGrotesk-Medium',
  hankenGroteskSemiBold: 'HankenGrotesk-SemiBold',
  hankenGroteskBold: 'HankenGrotesk-Bold',
  hangout: 'Hangout',
  metropolisRegular: 'Metropolis-Regular',
};
