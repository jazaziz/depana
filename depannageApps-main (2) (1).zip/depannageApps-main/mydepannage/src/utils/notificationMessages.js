export const notificationMessages = {};
