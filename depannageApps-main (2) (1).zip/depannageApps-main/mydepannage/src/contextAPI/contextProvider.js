import {createContext, useState} from 'react';

export const ContextAPI = createContext();

export default ContextProvider = ({children}) => {
  const [appLang, setAppLang] = useState(null);
  const [loginUserData, setLoginUserData] = useState(null);
  const [isLoading, setLoading] = useState(false);
  const [pickupLocation, setPickupLocation] = useState(null);
  const [dropOffLocation, setDropOffLocation] = useState(null);
  const [serviceType, setServiceType] = useState(null);

  return (
    <ContextAPI.Provider
      value={{
        appLang,
        setAppLang,
        loginUserData,
        setLoginUserData,
        isLoading,
        setLoading,
        setPickupLocation,
        setDropOffLocation,
        pickupLocation,
        dropOffLocation,
        setServiceType,
        serviceType,
      }}>
      {children}
    </ContextAPI.Provider>
  );
};
