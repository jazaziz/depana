import messaging from '@react-native-firebase/messaging';
import {Alert, Platform} from 'react-native';
import notifee, {AndroidImportance} from '@notifee/react-native';
import axios from 'axios';
import {FirebaseServerKey} from '../utils/constants';

export async function requestUserPermission() {
  const authStatus = await messaging().requestPermission();
  const enabled =
    authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
    authStatus === messaging.AuthorizationStatus.PROVISIONAL;

  if (enabled) {
    console.log('Authorization status:', authStatus);
    // getFcmToken();
  }
}

export const getFcmToken = async () => {
  try {
    let fcmToken = await messaging().getToken();
    return fcmToken;
  } catch (e) {
    Alert.alert('error raised in fcm token');
  }
};

export async function onDisplayNotification(data) {
  if (Platform.OS === 'ios') {
    await notifee.requestPermission();
  }
  //create channel only req for android
  const channelId = await notifee.createChannel({
    id: 'default ID',
    name: 'Default Channel',
    sound: 'default',
    importance: AndroidImportance.HIGH,
    badge: true,
  });

  // Display a notification
  await notifee.displayNotification({
    title: `<p style="color: #ffff;"><b>${data?.notification?.title}</span></p></b></p>`,

    body: `<p style="color: #ffffff; background-color: #9c27b0">${data?.notification?.body}</p>`,
    android: {
      channelId,
      color: '#4caf50',
    },
  });
}

export const notificationListner = async () => {
  const openedAppSubscription = messaging().onNotificationOpenedApp(
    remoteMessage => {
      console.log(
        'Notification caused app to open from background state:',
        remoteMessage.notification,
      );
    },
  );

  const messageSubscription = messaging().onMessage(async remoteMessage => {
    console.log('recived in foreground', remoteMessage);
    onDisplayNotification(remoteMessage);
  });

  messaging()
    .getInitialNotification()
    .then(remoteMessage => {
      if (remoteMessage) {
        console.log(
          'Notification caused app to open from quit state:',
          remoteMessage.notification,
        );
      }
    });

  return {openedAppSubscription, messageSubscription};
};

export const sendNotification = async (fcmToken, data) => {
  try {
    const request = await axios({
      url: 'https://fcm.googleapis.com/fcm/send',
      method: 'POST',
      headers: {
        Authorization: `Bearer ${FirebaseServerKey}`,
      },

      data: {
        to: fcmToken,
        notification: {
          title: data?.title,
          body: data?.body,
        },
      },
    });
  } catch (err) {
    Alert.alert('Error', err);
  }
};
