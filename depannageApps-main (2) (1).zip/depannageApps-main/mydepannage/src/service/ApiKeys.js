export var BASE_URL = '';

export const ApiEndpoint = {
  // API Endpoints
  SIGNUP: BASE_URL + 'signup',
};

export const ApiKeys = {
  DEVICE_ID: 'device_id',
  DEVICE_TYPE: 'device_type',
};

export const keyPref = {
  USER_DATA: 'USER_DATA',
  FCM_TOKEN: 'FCM_TOKEN',
};
