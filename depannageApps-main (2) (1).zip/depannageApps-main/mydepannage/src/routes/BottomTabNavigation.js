import React from 'react';
import {SafeAreaView, StatusBar} from 'react-native';

import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {getFocusedRouteNameFromRoute} from '@react-navigation/native';

import {colors} from '../utils/constants';

import CustomTabBar from './CustomTabBar';
import Home from '../screens/home/Home';
import Order from '../screens/order/Order';
import Profile from '../screens/profile/Profile';
import Notification from '../screens/home/Notification';
import ServiceForm from '../screens/home/ServiceForm';
import MapView from '../screens/home/MapView';
import OrderCustomerDetail from '../screens/order/OrderCustomerDetail';
import ViewProfile from '../screens/order/ViewProfile';
import PaymentMethod from '../screens/order/PaymentMethod';
import ChangeMobileNumber from '../screens/profile/ChangeMobileNumber';
import EditProfile from '../screens/profile/EditProfile';
import WebviewPage from '../screens/profile/WebviewPage';
import Support from '../screens/profile/Support';
import OTPVerification from '../screens/auth/OTPVerification';

const Stack = createNativeStackNavigator();

const HomeStackScreen = ({navigation, route}) => {
  return (
    <Stack.Navigator
      initialRouteName={'Home'}
      screenOptions={{
        headerShown: false,
        gestureEnabled: false,
      }}>
      <Stack.Screen name="Home" component={Home} />
      <Stack.Screen name="Notification" component={Notification} />
      <Stack.Screen name="ServiceForm" component={ServiceForm} />
      <Stack.Screen name="MapView" component={MapView} />
    </Stack.Navigator>
  );
};

const OrderStackScreen = ({navigation, route}) => {
  return (
    <Stack.Navigator
      initialRouteName={'Order'}
      screenOptions={{
        headerShown: false,
        gestureEnabled: false,
      }}>
      <Stack.Screen name="Order" component={Order} />
      <Stack.Screen
        name="OrderCustomerDetail"
        component={OrderCustomerDetail}
      />
      <Stack.Screen name="ViewProfile" component={ViewProfile} />
      <Stack.Screen name="PaymentMethod" component={PaymentMethod} />
      <Stack.Screen name="MapView" component={MapView} />
    </Stack.Navigator>
  );
};

const ProfileStackScreen = ({navigation, route}) => {
  return (
    <Stack.Navigator
      initialRouteName={'Profile'}
      screenOptions={{
        headerShown: false,
        gestureEnabled: false,
      }}>
      <Stack.Screen name="Profile" component={Profile} />
      <Stack.Screen name="EditProfile" component={EditProfile} />
      <Stack.Screen name="ChangeMobileNumber" component={ChangeMobileNumber} />
      <Stack.Screen name="WebviewPage" component={WebviewPage} />
      <Stack.Screen name="Support" component={Support} />
      <Stack.Screen name="OTPVerification" component={OTPVerification} />
    </Stack.Navigator>
  );
};

const Tab = createBottomTabNavigator();

export default function BottomTabNavigation({navigation}) {
  return (
    <>
      <SafeAreaView style={{flex: 0, backgroundColor: colors.primaryColor}} />
      <SafeAreaView style={{flex: 1, backgroundColor: colors.white}}>
        <StatusBar
          animated
          translucent={false}
          backgroundColor={colors.primaryColor}
        />
        <Tab.Navigator
          initialRouteName="Home"
          tabBar={props => <CustomTabBar {...props} />}
          screenOptions={({route}) => ({
            headerShown: false,
            tabBarShowLabel: false,
            tabBarActiveBackgroundColor: colors.white,
            tabBarInactiveBackgroundColor: colors.white,
            tabBarHideOnKeyboard: true,
          })}>
          <Tab.Screen
            name="Home"
            component={HomeStackScreen}
            options={({route}) => ({
              tabBarStyle: (route => {
                const routeName = getFocusedRouteNameFromRoute(route) ?? 'Home';
                if (routeName !== 'Home') {
                  return {display: 'none'};
                }
                return {display: 'flex', borderTopWidth: 0};
              })(route),
            })}
          />
          <Tab.Screen
            name="Order"
            component={OrderStackScreen}
            options={({route}) => ({
              tabBarStyle: (route => {
                const routeName =
                  getFocusedRouteNameFromRoute(route) ?? 'Order';
                if (routeName !== 'Order') {
                  return {display: 'none'};
                }
                return {display: 'flex', borderTopWidth: 0};
              })(route),
            })}
          />
          <Tab.Screen
            name="Profile"
            component={ProfileStackScreen}
            options={({route}) => ({
              tabBarStyle: (route => {
                const routeName =
                  getFocusedRouteNameFromRoute(route) ?? 'Profile';
                if (routeName !== 'Profile') {
                  return {display: 'none'};
                }
                return {display: 'flex', borderTopWidth: 0};
              })(route),
            })}
          />
        </Tab.Navigator>
      </SafeAreaView>
    </>
  );
}
