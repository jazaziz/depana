import React, {useContext, useEffect, useState} from 'react';
import {
  View,
  Pressable,
  StyleSheet,
  Text,
  Image,
  Keyboard,
  Platform,
} from 'react-native';

import {moderateScale, scale} from 'react-native-size-matters';

import {colors} from '../utils/constants';
import {ImageView} from '../utils/imageView';
import appFonts from '../utils/appFonts';
import {ContextAPI} from '../contextAPI/contextProvider';
import {multiLanguages} from '../utils/multiLanguages';

const CustomTabBar = ({state, descriptors, navigation}) => {
  const [visible, setVisible] = useState(false);
  const contextAPI = useContext(ContextAPI);

  useEffect(() => {
    let keyboardEventListeners;
    if (Platform.OS === 'android') {
      keyboardEventListeners = [
        Keyboard.addListener('keyboardDidShow', () => setVisible(true)),
        Keyboard.addListener('keyboardDidHide', () => setVisible(false)),
      ];
    }
    return () => {
      if (Platform.OS === 'android') {
        keyboardEventListeners &&
          keyboardEventListeners.forEach(eventListener =>
            eventListener.remove(),
          );
      }
    };
  }, []);

  const focusedOptions = descriptors[state.routes[state.index].key].options;
  if (
    focusedOptions?.tabBarStyle?.display === 'none' ||
    (visible && Platform.OS == 'android')
  ) {
    return null;
  }

  return (
    <View style={styles.mainContainer}>
      {state.routes.map((route, index) => {
        const focused = state.index === index;
        var iconName;
        var iconLabel;
        switch (route.name) {
          case 'Home':
            iconLabel = multiLanguages[contextAPI?.appLang]?.home;
            iconName = focused ? ImageView.activeHome : ImageView.home;
            break;
          case 'Order':
            iconLabel = multiLanguages[contextAPI?.appLang]?.order;
            iconName = focused ? ImageView.activeOrder : ImageView.order;
            break;
          case 'Profile':
            iconLabel = multiLanguages[contextAPI?.appLang]?.profile;
            iconName = focused
              ? ImageView.activeMyProfile
              : ImageView.myProfile;
            break;
        }

        const onPress = () => {
          const event = navigation.emit({
            type: 'tabPress',
            target: route.key,
          });
          if (!focused && !event.defaultPrevented) {
            navigation.navigate(route.name);
          }
        };

        const TabIconComponent = () => (
          <View
            style={{
              flex: 1,
              justifyContent: 'space-between',
            }}>
            <View
              style={{
                flex: 0.25,
                alignItems: 'center',
                justifyContent: 'center',
              }}>
              {focused && (
                <Image
                  source={ImageView.tabTopLine}
                  style={{
                    width: scale(40),
                    height: scale(20),
                  }}
                  resizeMode="contain"
                />
              )}
            </View>
            <View
              style={{
                flex: 0.45,
                top: -scale(3),
                alignItems: 'center',
                justifyContent: 'center',
              }}>
              <Image
                source={iconName}
                style={{
                  width: scale(25),
                  height: scale(25),
                }}
                resizeMode="contain"
              />
            </View>
            <View
              style={{
                flex: 0.3,
              }}>
              <Text
                style={{
                  color: focused ? colors.primaryColor : colors.gray,
                  textAlign: 'center',
                  fontSize: moderateScale(12),
                  fontFamily: appFonts.hankenGroteskMedium,
                }}>
                {iconLabel}
              </Text>
            </View>
          </View>
        );

        return (
          <View key={index} style={[styles.mainItemContainer]}>
            <Pressable onPress={onPress} style={styles.tabBarIconContainer}>
              {TabIconComponent()}
            </Pressable>
          </View>
        );
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  mainContainer: {
    flexDirection: 'row',
    position: 'absolute',
    backgroundColor: colors.white,
    bottom: 0,
    right: 0,
    left: 0,
    height: scale(72),
    borderTopEndRadius: 24,
    borderTopStartRadius: 24,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: -5,
    },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 5,
  },
  mainItemContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tabBarIconContainer: {
    flex: 1,
    width: scale(70),
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default CustomTabBar;
