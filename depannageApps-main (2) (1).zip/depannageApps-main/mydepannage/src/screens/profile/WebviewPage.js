import React, {useContext} from 'react';
import {StyleSheet, View} from 'react-native';

import WebView from 'react-native-webview';
import {useBackHandler} from '@react-native-community/hooks';
import {scale} from 'react-native-size-matters';

import HeaderComponent from '../../components/HeaderComponent';

import {colors} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';

const WebviewPage = ({navigation, route}) => {
  const contextAPI = useContext(ContextAPI);

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  const dynamicHeaderName = () => {
    switch (route.params?.headerTag) {
      case 'terms':
        return multiLanguages[contextAPI?.appLang]?.termsSecond;
      case 'privacy':
        return multiLanguages[contextAPI?.appLang]?.privacySecond;
    }
  };

  const dynamicUrl = () => {
    switch (route.params?.headerTag) {
      case 'terms':
        return;
      // ApiEndpoint.TERMS;
      case 'privacy':
        return;
      // ApiEndpoint.PRIVACY;
    }
  };

  return (
    <View style={styles.container}>
      <HeaderComponent
        centerTxt={dynamicHeaderName()}
        leftIcon={ImageView.backIconSecond}
        leftIconPress={() => {
          navigation.goBack();
        }}
      />
      <View
        style={{
          flex: 1,
          backgroundColor: colors.white,
          padding: scale(10),
        }}>
        <WebView
          showsVerticalScrollIndicator={false}
          bounces={false}
          setBuiltInZoomControls={false}
          textZoom={200}
          source={{uri: dynamicUrl()}}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.black,
  },
});

export default WebviewPage;
