import React, {useContext} from 'react';
import {StyleSheet, Text, View, Pressable, Image} from 'react-native';

import {useBackHandler} from '@react-native-community/hooks';
import {moderateScale, scale} from 'react-native-size-matters';

import HeaderComponent from '../../components/HeaderComponent';

import {colors} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import appFonts from '../../utils/appFonts';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';
import {openDialer, openEmail} from '../../utils/helpers';

const Support = ({navigation}) => {
  const contextAPI = useContext(ContextAPI);

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  const SupportView = () => (
    <View style={{padding: scale(20)}}>
      <Pressable onPress={() => {}} style={styles.listItemContainer}>
        <View
          style={{
            flex: 0.27,
          }}>
          <Image
            resizeMode="contain"
            style={styles.emailUsIcon}
            source={ImageView.emailUs}
          />
        </View>
        <View
          style={{
            flex: 0.73,
            paddingVertical: scale(5),
          }}>
          <Text style={styles.titleTxt}>
            {multiLanguages[contextAPI?.appLang]?.emailUs}
          </Text>
          <Pressable onPress={() => openEmail('mydepange@gmail.com')}>
            <Text style={styles.descTxt}>{'mydepange@gmail.com'}</Text>
          </Pressable>
        </View>
      </Pressable>
      <View style={styles.sizeBox} />
      <Pressable onPress={() => {}} style={styles.listItemContainer}>
        <View
          style={{
            flex: 0.27,
          }}>
          <Image
            resizeMode="contain"
            style={styles.contactUsIcon}
            source={ImageView.contactUs}
          />
        </View>
        <View
          style={{
            flex: 0.73,
            paddingVertical: scale(5),
          }}>
          <Text style={styles.titleTxt}>
            {multiLanguages[contextAPI?.appLang]?.contactUs}
          </Text>
          <Pressable onPress={() => openDialer('+212 681354778')}>
            <Text style={styles.descTxt}>{'+212 681354778'}</Text>
          </Pressable>
        </View>
      </Pressable>
    </View>
  );

  return (
    <View style={styles.container}>
      <HeaderComponent
        leftIconPress={() => {
          navigation.goBack();
        }}
        leftIcon={ImageView.backIconSecond}
        centerTxt={multiLanguages[contextAPI?.appLang]?.support}
      />
      {SupportView()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  listItemContainer: {
    backgroundColor: colors.white,
    borderRadius: 20,
    padding: scale(10),
    paddingVertical: scale(15),
    flexDirection: 'row',
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.17,
    shadowRadius: 2.54,
    elevation: 3,
  },
  emailUsIcon: {
    width: scale(70),
    height: scale(60),
  },
  contactUsIcon: {
    width: scale(65),
    height: scale(45),
  },
  titleTxt: {
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(16),
    color: colors.black,
    opacity: 0.8,
  },
  descTxt: {
    marginTop: scale(5),
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(14),
    color: colors.black,
    opacity: 0.5,
  },
  sizeBox: {
    marginVertical: scale(6),
  },
});

export default Support;
