import React, {useContext, useEffect, useRef, useState} from 'react';
import {
  StyleSheet,
  View,
  ScrollView,
  Text,
  Image,
  Pressable,
} from 'react-native';

import {useBackHandler} from '@react-native-community/hooks';
import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import {Avatar, Switch} from 'react-native-paper';
import RBSheet from 'react-native-raw-bottom-sheet';

import HeaderComponent from '../../components/HeaderComponent';
import TextInputComponent from '../../components/TextInputComponent';
import ConfirmationPopupComponent from '../../components/ConfirmationPopupComponent';

import {LocalStorageKeys, colors} from '../../utils/constants';
import appFonts from '../../utils/appFonts';
import {ImageView} from '../../utils/imageView';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';
import {fetchUserData} from '../../utils/helpers';
import {useFocusEffect} from '@react-navigation/native';
import auth from '@react-native-firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Profile = ({navigation}) => {
  const [notificationSwitch, setNotificationSwitch] = useState(false);
  const [showAccountContentType, setShowAccountContentType] = useState('');
  const [user, setUser] = useState(null);

  const refRBSheet = useRef();

  const contextAPI = useContext(ContextAPI);

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  useFocusEffect(
    React.useCallback(async () => {
      const user = await AsyncStorage.getItem(LocalStorageKeys.USER_DATA);
      console.log({user: JSON.parse(user)});
      setUser(JSON.parse(user));
    }, []),
  );

  const deleteAccount = async () => {
    const user = auth().currentUser;
    user.delete();

    refRBSheet.current.close();
    logoutHandler();
  };

  const logoutHandler = async () => {
    contextAPI.setLoading(true);

    try {
      await AsyncStorage.removeItem(LocalStorageKeys.USER_DATA);
      await auth().signOut();
    } catch (err) {
      contextAPI.setLoading(false);
      console.log({err});
    }

    contextAPI.setLoading(false);

    setTimeout(() => {
      navigation.reset({
        index: 0,
        routes: [{name: 'SignIn'}],
      });
    }, 500);
  };

  const onToggleSwitch = () => {
    setNotificationSwitch(!notificationSwitch);
  };

  const ProfileDetailView = () => (
    <View style={{padding: scale(20), paddingBottom: scale(10)}}>
      <View>
        <View style={styles.whiteBox}>
          <View style={styles.positionProfileIcon}>
            <Avatar.Image
              style={{backgroundColor: colors.silver}}
              source={
                !!user?.photoURL ? {uri: user?.photoURL} : ImageView.dummyImg
              }
              size={scale(65)}
            />
          </View>
          <Pressable
            onPress={() => {
              navigation.navigate('EditProfile');
            }}
            style={styles.editProfileContainer}>
            <Text style={styles.editProfileTxt}>
              {multiLanguages[contextAPI?.appLang]?.editProfile}
            </Text>
          </Pressable>
          <View style={{marginTop: scale(30 / 2)}}>
            <Text style={styles.titleTxt}>{user?.displayName || '-'}</Text>
            <Text style={styles.phoneTxt}>
              {(user?.phone ?? user?.phoneNumber) || '-'}
            </Text>
            <View style={styles.walletAmountContainer}>
              <Image
                style={styles.walletIcon}
                resizeMode="contain"
                source={ImageView.wallet}
              />
              <Text style={styles.walletAmountTxt}>{'150.00 MAD'}</Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  );

  const RightCustomIcon = () => (
    <View
      style={{
        flex: 0.4,
        alignItems: 'flex-end',
        justifyContent: 'center',
      }}>
      <Switch
        trackColor={{true: colors.primaryColor, false: colors.gray}}
        thumbColor={colors.white}
        value={notificationSwitch}
        onValueChange={() => onToggleSwitch()}
      />
    </View>
  );

  const ProfileOptionView = () => (
    <View>
      <TextInputComponent
        editable={false}
        value={multiLanguages[contextAPI?.appLang]?.notifications}
        normalTxt={styles.normalTxt}
        normalTxtStyl={{
          height: scale(55),
        }}
        rightCustomIcon={RightCustomIcon()}
        container={styles.textInputContainer}
      />
      <View style={styles.sizeBox} />
      <TextInputComponent
        editable={false}
        value={multiLanguages[contextAPI?.appLang]?.CMobileNumber}
        normalTxt={styles.normalTxt}
        normalTxtStyl={{
          height: scale(55),
        }}
        rightIcon={ImageView.rightArrow}
        container={styles.textInputContainer}
        onPress={() => {
          navigation.navigate('ChangeMobileNumber');
        }}
      />
      <View style={styles.sizeBox} />
      <TextInputComponent
        editable={false}
        value={multiLanguages[contextAPI?.appLang]?.terms}
        normalTxt={styles.normalTxt}
        normalTxtStyl={{
          height: scale(55),
        }}
        rightIcon={ImageView.rightArrow}
        container={styles.textInputContainer}
        onPress={() => {
          navigation.navigate('WebviewPage', {
            headerTag: 'terms',
          });
        }}
      />
      <View style={styles.sizeBox} />
      <TextInputComponent
        editable={false}
        value={multiLanguages[contextAPI?.appLang]?.privacy}
        normalTxt={styles.normalTxt}
        normalTxtStyl={{
          height: scale(55),
        }}
        rightIcon={ImageView.rightArrow}
        container={styles.textInputContainer}
        onPress={() => {
          navigation.navigate('WebviewPage', {
            headerTag: 'privacy',
          });
        }}
      />
      <View style={styles.sizeBox} />
      <TextInputComponent
        editable={false}
        value={multiLanguages[contextAPI?.appLang]?.support}
        normalTxt={styles.normalTxt}
        normalTxtStyl={{
          height: scale(55),
        }}
        rightIcon={ImageView.rightArrow}
        container={styles.textInputContainer}
        onPress={() => {
          navigation.navigate('Support');
        }}
      />
      <View style={styles.sizeBox} />
      <TextInputComponent
        editable={false}
        value={multiLanguages[contextAPI?.appLang]?.deleteAccount}
        normalTxt={styles.normalTxt}
        normalTxtStyl={{
          height: scale(55),
        }}
        container={styles.textInputContainer}
        onPress={() => {
          setShowAccountContentType('delete');
          refRBSheet.current.open();
        }}
      />
      <View style={styles.sizeBox} />
      <TextInputComponent
        editable={false}
        value={multiLanguages[contextAPI?.appLang]?.logout}
        normalTxt={styles.normalTxt}
        normalTxtStyl={{
          height: scale(55),
        }}
        container={styles.textInputContainer}
        onPress={() => {
          setShowAccountContentType('logout');
          refRBSheet.current.open();
        }}
      />
    </View>
  );

  return (
    <View style={styles.container}>
      <HeaderComponent
        centerTxt={multiLanguages[contextAPI?.appLang]?.profile}
      />
      <RBSheet
        ref={refRBSheet}
        height={verticalScale(200)}
        keyboardAvoidingViewEnabled={true}
        dragFromTopOnly
        closeOnDragDown
        openDuration={250}
        customStyles={{
          container: {
            borderTopEndRadius: 35,
            borderTopStartRadius: 35,
          },
          draggableIcon: {
            top: scale(5),
            backgroundColor: colors.silver,
            height: scale(6),
            borderRadius: 13,
            width: scale(70),
          },
        }}>
        <ConfirmationPopupComponent
          postiveBtnPress={deleteAccount}
          nagetiveBtnPress={() => {
            refRBSheet.current.close();
          }}
          titleMessage={
            showAccountContentType == 'logout'
              ? multiLanguages[contextAPI?.appLang]?.logoutAccountMsg
              : multiLanguages[contextAPI?.appLang]?.deleteAccountMsg
          }
        />
      </RBSheet>
      <ScrollView
        bounces={false}
        contentContainerStyle={{flexGrow: 1, paddingBottom: scale(80)}}
        keyboardShouldPersistTaps="always"
        showsVerticalScrollIndicator={false}>
        {ProfileDetailView()}
        {ProfileOptionView()}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  positionProfileIcon: {
    position: 'absolute',
    right: 0,
    left: 0,
    top: scale(-35),
    alignItems: 'center',
    justifyContent: 'center',
  },
  whiteBox: {
    marginTop: scale(65 / 2),
    padding: scale(10),
    backgroundColor: colors.white,
    borderRadius: 14,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
  },
  titleTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.lightBlue,
    textAlign: 'center',
  },
  phoneTxt: {
    marginVertical: scale(8),
    fontFamily: appFonts.metropolisRegular,
    fontSize: moderateScale(14),
    color: colors.black,
    opacity: 0.8,
    textAlign: 'center',
  },
  walletIcon: {
    width: scale(20),
    height: scale(20),
    marginRight: scale(5),
  },
  walletAmountTxt: {
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(14),
    color: colors.white,
  },
  editProfileContainer: {
    alignSelf: 'flex-end',
    backgroundColor: colors.primaryColor,
    padding: scale(5),
    paddingHorizontal: scale(6),
    borderRadius: scale(100),
  },
  editProfileTxt: {
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(12),
    color: colors.white,
  },
  walletAmountContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.primaryColor,
    alignSelf: 'center',
    padding: scale(5),
    paddingHorizontal: scale(10),
    borderRadius: scale(100),
  },
  textInputContainer: {
    borderRadius: 14,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    borderWidth: 0,
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
  },
  normalTxt: {
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(16),
    color: colors.jungleGren,
  },
  sizeBox: {
    marginVertical: scale(6),
  },
});

export default Profile;
