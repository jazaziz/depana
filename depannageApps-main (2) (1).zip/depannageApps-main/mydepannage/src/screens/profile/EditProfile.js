import React, {useState, useRef, useContext, useEffect} from 'react';
import {
  StyleSheet,
  View,
  Image,
  Keyboard,
  Pressable,
  Alert,
} from 'react-native';

import {useBackHandler} from '@react-native-community/hooks';
import {scale, verticalScale} from 'react-native-size-matters';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import RBSheet from 'react-native-raw-bottom-sheet';
import {Avatar} from 'react-native-paper';

import HeaderComponent from '../../components/HeaderComponent';
import TextInputComponent from '../../components/TextInputComponent';
import ButtonComponent from '../../components/ButtonComponent';

import {LocalStorageKeys, colors, imageOptions} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import Validation from '../../utils/validation';
import appFonts from '../../utils/appFonts';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';
import auth from '@react-native-firebase/auth';
import {FireStoreHelper} from '../../service/firebase';
import ImagePicker from 'react-native-image-crop-picker';
import AsyncStorage from '@react-native-async-storage/async-storage';

const EditProfile = ({navigation}) => {
  const [inputFocus, setInputFocus] = useState('');
  const [username, setUsername] = useState('');
  const [profileImg, setProfileImg] = useState(null);

  const refOptionRBSheet = useRef(null);

  const contextAPI = useContext(ContextAPI);

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  useEffect(() => {
    (async () => {
      const data = await AsyncStorage.getItem(LocalStorageKeys.USER_DATA);
      const user = JSON.parse(data);
      setUsername(user?.displayName);
      setProfileImg(user?.photoURL);
    })();
  }, []);

  const imageHandler = async image => {
    let imagePath = null;

    if (image === imageOptions.Camera) {
      const result = await ImagePicker.openCamera({
        cropping: true,
      });
      imagePath = result.path;
    }
    if (image === imageOptions.Gallery) {
      const result = await ImagePicker.openPicker({
        cropping: true,
        mediaType: 'photo',
      });
      imagePath = result.path;
    }

    const firebase = new FireStoreHelper();
    contextAPI.setLoading(true);
    const url = await firebase.uploadImage(imagePath);
    setProfileImg(url);
    contextAPI.setLoading(false);
  };

  const handleSave = async () => {
    Keyboard.dismiss();

    const user = auth().currentUser;
    if (user) {
      try {
        contextAPI.setLoading(true);
        await user.updateProfile({
          displayName: username,
          ...(profileImg !== user.photoURL && {
            photoURL: profileImg,
          }),
        });

        const oldData = await AsyncStorage.getItem(LocalStorageKeys.USER_DATA);

        const newData = {
          ...JSON.parse(oldData),
          displayName: username,
        };

        if (profileImg !== user.photoURL) {
          newData.photoURL = profileImg;
        }

        await AsyncStorage.setItem(
          LocalStorageKeys.USER_DATA,
          JSON.stringify(newData),
        );

        contextAPI.setLoading(false);
        navigation.goBack();
      } catch (error) {
        contextAPI.setLoading(false);
        Alert.alert('Error', error.message);
      }
    }
  };

  const ProfileDetailView = () => (
    <View style={{padding: scale(20), paddingBottom: scale(10)}}>
      <View>
        <View style={styles.positionProfileIcon}>
          <View>
            <Pressable
              onPress={() => {
                refOptionRBSheet.current.open();
              }}
              style={styles.cameraContainer}>
              <Image
                resizeMode="contain"
                style={styles.cameraIcon}
                source={ImageView.camera}
              />
            </Pressable>
            <Avatar.Image
              style={{backgroundColor: colors.silver}}
              source={!!profileImg ? {uri: profileImg} : ImageView.dummyImg}
              size={scale(100)}
            />
          </View>
        </View>
        <View style={styles.whiteBox}>
          <View style={{marginTop: scale(100 / 2), paddingVertical: scale(10)}}>
            <TextInputComponent
              placeholder={multiLanguages[contextAPI?.appLang]?.fullName}
              value={username}
              inputTxtStyl={{
                fontFamily: Validation.isEmpty(username)
                  ? appFonts.hankenGroteskRegular
                  : appFonts.hankenGroteskMedium,
              }}
              container={[
                {marginHorizontal: scale(10)},
                inputFocus == multiLanguages[contextAPI?.appLang]?.fullName &&
                  styles.activeTextInput,
              ]}
              onFocus={() => {
                setInputFocus(multiLanguages[contextAPI?.appLang]?.fullName);
              }}
              onBlur={() => {
                setInputFocus('');
              }}
              onChangeText={text => {
                setUsername(text);
              }}
              onSubmitEditing={() => {
                Keyboard.dismiss();
              }}
            />
          </View>
        </View>
      </View>
    </View>
  );

  const ModalContentView = () => (
    <View
      style={{
        flexDirection: 'row',
        alignSelf: 'center',
        flex: 1,
      }}>
      <View
        style={{
          width: scale(100),
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Pressable
          onPress={() => {
            refOptionRBSheet.current.close();
            setTimeout(() => {
              imageHandler(imageOptions.Camera);
            }, 500);
          }}
          style={styles.modalcIcon}>
          <Image
            resizeMode="contain"
            source={ImageView.chooseCamera}
            style={styles.cameraGalleryIcon}
          />
        </Pressable>
      </View>
      <View
        style={{
          width: scale(100),
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Pressable
          onPress={() => {
            refOptionRBSheet.current.close();
            setTimeout(() => {
              imageHandler(imageOptions.Gallery);
            }, 500);
          }}
          style={styles.modalcIcon}>
          <Image
            resizeMode="contain"
            source={ImageView.chooseGallery}
            style={styles.cameraGalleryIcon}
          />
        </Pressable>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <HeaderComponent
        leftIconPress={() => {
          navigation.goBack();
        }}
        leftIcon={ImageView.backIconSecond}
        centerTxt={multiLanguages[contextAPI?.appLang]?.editProfile}
      />
      <RBSheet
        ref={refOptionRBSheet}
        height={verticalScale(150)}
        keyboardAvoidingViewEnabled={true}
        dragFromTopOnly
        closeOnDragDown
        openDuration={250}
        customStyles={{
          container: {
            borderTopEndRadius: 35,
            borderTopStartRadius: 35,
          },
          draggableIcon: {
            top: scale(5),
            backgroundColor: colors.silver,
            height: scale(6),
            borderRadius: 13,
            width: scale(70),
          },
        }}>
        {ModalContentView()}
      </RBSheet>
      <KeyboardAwareScrollView
        bounces={false}
        keyboardShouldPersistTaps="always"
        showsVerticalScrollIndicator={false}>
        {ProfileDetailView()}
        <View style={styles.sizeBox} />
        <View style={styles.sizeBox} />
        <ButtonComponent
          onBtnPress={handleSave}
          btnLabel={multiLanguages[contextAPI?.appLang]?.save}
        />
      </KeyboardAwareScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  positionProfileIcon: {
    position: 'absolute',
    zIndex: 1,
    right: 0,
    left: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cameraContainer: {
    zIndex: 1,
    position: 'absolute',
    bottom: scale(-15),
    right: scale(-10),
  },
  cameraIcon: {
    width: scale(50),
    height: scale(50),
  },
  cameraGalleryIcon: {
    width: scale(55),
    height: scale(55),
  },
  whiteBox: {
    marginTop: scale(100 / 2),
    paddingVertical: scale(10),
    backgroundColor: colors.white,
    borderRadius: 14,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
  },
  textInputContainer: {
    borderRadius: 14,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    borderWidth: 0,
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
  },
  sizeBox: {
    marginVertical: scale(6),
  },
  activeTextInput: {
    borderColor: colors.secondaryColor,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.17,
    shadowRadius: 2.54,
    elevation: 3,
  },
  modalcIcon: {
    width: scale(50),
    height: scale(50),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: scale(15),
  },
});

export default EditProfile;
