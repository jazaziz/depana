import React, {useContext} from 'react';
import {
  StyleSheet,
  Image,
  Dimensions,
  ImageBackground,
  View,
  Text,
  SafeAreaView,
  Platform,
} from 'react-native';

import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {useBackHandler} from '@react-native-community/hooks';
import {useSafeAreaInsets} from 'react-native-safe-area-context';

import ButtonComponent from '../../components/ButtonComponent';

import {colors} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import appFonts from '../../utils/appFonts';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';

const deviceHeight = Dimensions.get('window').height;
const Attention = ({navigation, route}) => {
  const contextAPI = useContext(ContextAPI);

  const insets = useSafeAreaInsets();

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  const AuthHeaderView = () => (
    <ImageBackground
      style={[
        styles.imgBgContainer,
        {
          height:
            Platform.OS == 'ios'
              ? verticalScale(250) - insets.top
              : verticalScale(250),
        },
      ]}
      imageStyle={styles.curveImgStyl}
      source={ImageView.headerCurveImg}
    />
  );

  const UserInputView = () => (
    <View
      style={{
        height: deviceHeight - verticalScale(250),
      }}>
      <View style={styles.headerAbsoluteIcon}>
        <Image
          style={styles.headerIcon}
          resizeMode="contain"
          source={ImageView.alertIcon}
        />
      </View>
      <View style={{height: '60%'}}>{InputTextView()}</View>
      <View style={styles.fotterAbsoluteIcon}>
        <Image
          style={styles.fotterIcon}
          resizeMode="contain"
          source={ImageView.towingImg}
        />
      </View>
    </View>
  );

  const InputTextView = () => (
    <View style={{}}>
      <Text style={styles.authTypeTxt}>
        {multiLanguages[contextAPI?.appLang]?.attention}
      </Text>
      <Text style={styles.authTypeMsgTxt}>
        {multiLanguages[contextAPI?.appLang]?.attentionMessg}
      </Text>
      <View style={{paddingVertical: scale(20), paddingHorizontal: scale(40)}}>
        <View style={styles.detailsContainer}>
          <View style={styles.bullet} />
          <Text style={styles.detailsTxt}>
            {multiLanguages[contextAPI?.appLang]?.turnOnLight}
          </Text>
        </View>
        <View style={styles.detailsContainer}>
          <View style={styles.bullet} />
          <Text style={styles.detailsTxt}>
            {multiLanguages[contextAPI?.appLang]?.wearJacket}
          </Text>
        </View>
        <View style={styles.detailsContainer}>
          <View style={styles.bullet} />
          <Text style={styles.detailsTxt}>
            {multiLanguages[contextAPI?.appLang]?.placement}
          </Text>
        </View>
        <View style={styles.detailsContainer}>
          <View style={styles.bullet} />
          <Text style={styles.detailsTxt}>
            {multiLanguages[contextAPI?.appLang]?.pleaseHold}
          </Text>
        </View>
      </View>
      <View style={styles.sizeBox} />
      <ButtonComponent
        onBtnPress={() => {
          navigation.reset({
            index: 0,
            routes: [{name: 'Home'}],
          });
        }}
        btnLabel={multiLanguages[contextAPI?.appLang]?.ok}
      />
    </View>
  );

  return (
    <View style={styles.container}>
      <KeyboardAwareScrollView
        bounces={false}
        keyboardShouldPersistTaps="always"
        showsVerticalScrollIndicator={false}>
        {AuthHeaderView()}
        {UserInputView()}
      </KeyboardAwareScrollView>
      <SafeAreaView style={{flex: 0, backgroundColor: colors.white}} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  imgBgContainer: {
    width: '100%',
  },
  curveImgStyl: {
    width: '100%',
    height: '100%',
    borderBottomLeftRadius: 85,
    borderBottomRightRadius: 85,
  },
  headerAbsoluteIcon: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: scale(-45),
  },
  headerIcon: {
    width: scale(100),
    height: scale(100),
  },
  fotterAbsoluteIcon: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: scale(100),
    height: '40%',
    zIndex: -1,
  },
  fotterIcon: {
    width: '100%',
    height: scale(131),
  },
  authTypeTxt: {
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(26),
    color: colors.primaryColor,
    textAlign: 'center',
  },
  authTypeMsgTxt: {
    paddingHorizontal: scale(5),
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(16),
    color: colors.suvaGrey,
    textAlign: 'center',
    lineHeight: scale(25),
  },
  detailsTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(16),
    color: colors.black,
    opacity: 0.9,
    lineHeight: scale(18),
  },
  detailsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: scale(10),
  },
  bullet: {
    backgroundColor: colors.black,
    width: scale(4),
    height: scale(4),
    top: scale(1),
    marginRight: scale(15),
  },
  sizeBox: {
    marginVertical: scale(5),
  },
});

export default Attention;
