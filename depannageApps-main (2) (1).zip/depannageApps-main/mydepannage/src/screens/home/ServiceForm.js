import React, {useContext, useEffect, useState} from 'react';
import {
  Keyboard,
  StyleSheet,
  Text,
  View,
  Image,
  Pressable,
  FlatList,
} from 'react-native';
import auth from '@react-native-firebase/auth';

import {useBackHandler} from '@react-native-community/hooks';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {CountryPicker} from 'react-native-country-codes-picker';
import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import Tooltip from 'react-native-walkthrough-tooltip';
import Modal from 'react-native-modal';
import DatePicker from 'react-native-date-picker';

import HeaderComponent from '../../components/HeaderComponent';
import ButtonComponent from '../../components/ButtonComponent';
import TextInputComponent from '../../components/TextInputComponent';
import EmptyMessageComponent from '../../components/EmptyMessageComponent';

import {
  FirebaseCollections,
  ServiceTypes,
  ServicesStatus,
  colors,
  config,
  locationTypes,
} from '../../utils/constants';
import appFonts from '../../utils/appFonts';
import {ImageView} from '../../utils/imageView';
import Validation from '../../utils/validation';
import {dummuData} from '../../utils/dummyData';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';
import moment from 'moment';
import {FireStoreHelper} from '../../service/firebase';
import {
  convertLatLngToAddress,
  fetchUserData,
  formatePhoneNumber,
} from '../../utils/helpers';

const ServiceForm = ({navigation, route}) => {
  const [inputFocus, setInputFocus] = useState('');
  const [selectedVehicle, setSelectedVihicle] = useState('');
  const [selectedVisitTech, setSelectedVisitTech] = useState('');
  const [selectInsuranceService, setSelectInsuranceService] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [brand, setBrand] = useState('');
  const [rNumber, setRNumber] = useState('');
  const [year, setYear] = useState('');
  const [maker, setMaker] = useState('');
  const [selectInsurance, setSelectInsurance] = useState('');
  const [location, setLocation] = useState('');
  const [pickup, setPickup] = useState('');
  const [dropOff, setDropOff] = useState('');
  const [fName, setFName] = useState('');
  const [email, setEmail] = useState('');
  const [mNumber, setMNumber] = useState('');
  const [note, setNote] = useState('');
  const [countryCode, setCountryCode] = useState('+1');
  const [showCountryPicker, setShowCountryPicker] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [datePickerType, setDatePickerType] = useState('');

  const [selectedToolTipType, setSelectedToolTipType] = useState('');
  const [toolTipVihicleVisible, setToolTipVihicleVisible] = useState(false);
  const [toolTipTechniqueVisible, setToolTipTechniqueVisible] = useState(false);
  const [toolTipInsuranceVisible, setToolTipInsuranceVisible] = useState(false);
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  // const [user, setUser] = useState(null);

  const contextAPI = useContext(ContextAPI);

  useBackHandler(() => {
    Keyboard.dismiss();
    navigation.goBack();
    return true;
  });

  const onSelect = item => {
    setCountryCode(item.dial_code);
    setShowCountryPicker(false);
  };

  useEffect(() => {
    (async () => {
      const user = await fetchUserData();
      setFName(user?.displayName);
      // setUser(user);
    })();
  }, []);

  const handleSubmit = async () => {
    Keyboard.dismiss();
    contextAPI.setLoading(true);
    const servicesCollections = new FireStoreHelper(
      FirebaseCollections.Services,
    );

    let serviceType = null;

    switch (contextAPI.serviceType) {
      case multiLanguages[contextAPI?.appLang].towingService:
        serviceType = ServiceTypes.TowingService;
        break;

      case multiLanguages[contextAPI?.appLang].fuelGasFill:
        serviceType = ServiceTypes.FuelOrGas;
        break;

      case multiLanguages[contextAPI?.appLang].tireChange:
        serviceType = ServiceTypes.TireChange;
        break;

      case multiLanguages[contextAPI?.appLang].batteryChange:
        serviceType = ServiceTypes.BatteryChange;
        break;

      case multiLanguages[contextAPI?.appLang].taxi:
        serviceType = ServiceTypes.Texi;
        break;

      case multiLanguages[contextAPI?.appLang].visitTechnique:
        serviceType = ServiceTypes.VisitTechnique;
        break;
    }

    const user = auth().currentUser;

    let payload = {
      vehicle: selectedVehicle,
      vehicleBrand: brand,
      registrationNo: rNumber,
      year: year,
      maker: maker,
      isInsurance: selectInsurance.toLowerCase() === 'yes' ? true : false,
      type: serviceType,
      status: ServicesStatus.PENDING,
      createdAt: new Date(),
      userId: user.uid,
      visitTechnique: selectedVisitTech,
      visitDate: date,
      visitTime: time,
      contactInfo: {
        name: fName,
        email: email,
        phone: formatePhoneNumber(mNumber, countryCode),
        note: note,
      },
    };

    if (!!contextAPI.pickupLocation) {
      payload = {
        ...payload,
        pickUp: {
          lat: contextAPI.pickupLocation?.latitude,
          lng: contextAPI.pickupLocation?.longitude,
          address: contextAPI.pickupLocation?.address || '',
        },
      };
    }

    if (!!contextAPI.dropOffLocation) {
      payload = {
        ...payload,
        dropOff: {
          lat: contextAPI.dropOffLocation?.latitude,
          lng: contextAPI.dropOffLocation?.longitude,
          address: contextAPI.dropOffLocation?.address || '',
        },
      };
    }

    await servicesCollections.create(payload);
    contextAPI.setPickupLocation(null);
    contextAPI.setDropOffLocation(null);

    contextAPI.setLoading(false);
    setShowSubmitModal(true);
  };

  const dynamicListData = () => {
    switch (selectedToolTipType) {
      case 'vihicle':
        return dummuData?.VIHICLE_TYPE_DATA;
      case 'technique':
        return dummuData?.TECHNIQUE_TYPE_DATA;
      case 'insurance':
        return [];
    }
  };

  const datePickerDynamicTitle = type => {
    switch (type) {
      case 'date':
        return multiLanguages[contextAPI?.appLang]?.date;
      case 'time':
        return multiLanguages[contextAPI?.appLang]?.time;
    }
  };

  const dynamicDateHandler = date => {
    switch (datePickerType) {
      case 'date':
        setDate(moment(date).format(config.DOB_FORMAT));
        break;
      case 'time':
        setTime(moment(date).format(config.TIME_FORMAT));
        break;
    }
    setShowDatePicker(false);
  };

  const dynamicSelectionType = item => {
    switch (selectedToolTipType) {
      case 'vihicle':
        setToolTipVihicleVisible(false);
        setSelectedVihicle(item?.tag);
        break;
      case 'technique':
        setToolTipTechniqueVisible(false);
        setSelectedVisitTech(item?.tag);
        break;
      case 'insurance':
        setToolTipInsuranceVisible(false);
        setSelectInsuranceService(item?.tag);
        break;
    }
  };

  const ToolTipView = (type = '') => (
    <FlatList
      style={{width: scale(300), maxHeight: scale(300)}}
      contentContainerStyle={{padding: scale(10)}}
      keyExtractor={item => item?.id}
      showsVerticalScrollIndicator={false}
      bounces={false}
      ItemSeparatorComponent={<View style={{marginVertical: scale(5)}} />}
      renderItem={({item}) => {
        return (
          <Pressable
            onPress={() => dynamicSelectionType(item)}
            style={{padding: scale(5)}}>
            <Text style={styles.tollTipText}>{item?.tag}</Text>
          </Pressable>
        );
      }}
      ListEmptyComponent={<EmptyMessageComponent />}
      data={dynamicListData()}
    />
  );

  const VisitTechniqueFormDetailsView = () => (
    <>
      {SectionTitleView(multiLanguages[contextAPI?.appLang]?.visitTechnique)}
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <Tooltip
        tooltipStyle={{
          alignItems: 'center',
          left: 0,
          right: 0,
        }}
        contentStyle={{
          borderRadius: 10,
          padding: 0,
        }}
        animated={true}
        arrowSize={{width: 0, height: 0}}
        backgroundColor="rgba(0,0,0,0.5)"
        isVisible={toolTipTechniqueVisible}
        content={ToolTipView()}
        placement="bottom"
        onClose={() => setToolTipTechniqueVisible(false)}>
        <TextInputComponent
          normalTxt={{
            fontFamily: Validation.isEmpty(selectedVisitTech)
              ? appFonts.hankenGroteskRegular
              : appFonts.hankenGroteskMedium,
            color: Validation.isEmpty(selectedVisitTech)
              ? colors.gray
              : colors.gray15,
          }}
          value={
            Validation.isEmpty(selectedVisitTech)
              ? multiLanguages[contextAPI?.appLang]?.selectVisitTechnique
              : selectedVisitTech
          }
          rightIcon={ImageView.downArrow}
          rightIconStyl={{tintColor: colors.gray}}
          onPress={() => {
            Keyboard.dismiss();
            setSelectedToolTipType('technique');
            setToolTipTechniqueVisible(true);
          }}
          editable={false}
        />
      </Tooltip>

      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
    </>
  );

  const DateTimeFormDetailsView = () => (
    <>
      {SectionTitleView(multiLanguages[contextAPI?.appLang]?.dateTime)}
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <TextInputComponent
        value={
          Validation.isEmpty(date)
            ? multiLanguages[contextAPI?.appLang]?.date
            : date
        }
        editable={false}
        normalTxt={{
          fontFamily: Validation.isEmpty(date)
            ? appFonts.hankenGroteskRegular
            : appFonts.hankenGroteskMedium,
          color: Validation.isEmpty(date) ? colors.gray : colors.gray15,
        }}
        onChangeText={text => setDate(text)}
        onPress={() => {
          Keyboard.dismiss();
          setShowDatePicker(true), setDatePickerType('date');
        }}
      />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <TextInputComponent
        value={
          Validation.isEmpty(time)
            ? multiLanguages[contextAPI?.appLang]?.time
            : time
        }
        editable={false}
        normalTxt={{
          fontFamily: Validation.isEmpty(time)
            ? appFonts.hankenGroteskRegular
            : appFonts.hankenGroteskMedium,
          color: Validation.isEmpty(time) ? colors.gray : colors.gray15,
        }}
        onChangeText={text => setTime(text)}
        onPress={() => {
          Keyboard.dismiss();
          setShowDatePicker(true), setDatePickerType('time');
        }}
      />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
    </>
  );

  const VihicleFormDetailsView = () => (
    <>
      {SectionTitleView(multiLanguages[contextAPI?.appLang]?.vehicleDetail)}
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <Tooltip
        tooltipStyle={{
          alignItems: 'center',
          left: 0,
          right: 0,
        }}
        contentStyle={{
          borderRadius: 10,
          padding: 0,
        }}
        animated={true}
        arrowSize={{width: 0, height: 0}}
        backgroundColor="rgba(0,0,0,0.5)"
        isVisible={toolTipVihicleVisible}
        content={ToolTipView()}
        placement="bottom"
        onClose={() => setToolTipVihicleVisible(false)}>
        <TextInputComponent
          normalTxt={{
            fontFamily: Validation.isEmpty(selectedVehicle)
              ? appFonts.hankenGroteskRegular
              : appFonts.hankenGroteskMedium,
            color: Validation.isEmpty(selectedVehicle)
              ? colors.gray
              : colors.gray15,
          }}
          value={
            Validation.isEmpty(selectedVehicle)
              ? multiLanguages[contextAPI?.appLang]?.selectVehicle
              : selectedVehicle
          }
          rightIcon={ImageView.downArrow}
          rightIconStyl={{tintColor: colors.gray}}
          onPress={() => {
            Keyboard.dismiss();
            setSelectedToolTipType('vihicle');
            setToolTipVihicleVisible(true);
          }}
          editable={false}
        />
      </Tooltip>

      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <TextInputComponent
        placeholder={multiLanguages[contextAPI?.appLang]?.brand}
        value={brand}
        inputTxtStyl={{
          fontFamily: Validation.isEmpty(brand)
            ? appFonts.hankenGroteskRegular
            : appFonts.hankenGroteskMedium,
        }}
        container={
          inputFocus == multiLanguages[contextAPI?.appLang]?.brand &&
          styles.activeTextInput
        }
        onFocus={() => {
          setInputFocus(multiLanguages[contextAPI?.appLang]?.brand);
        }}
        onBlur={() => {
          setInputFocus('');
        }}
        onChangeText={text => setBrand(text)}
        onSubmitEditing={() => {
          Keyboard.dismiss();
        }}
      />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <TextInputComponent
        placeholder={multiLanguages[contextAPI?.appLang]?.registrationNumber}
        value={rNumber}
        inputTxtStyl={{
          fontFamily: Validation.isEmpty(rNumber)
            ? appFonts.hankenGroteskRegular
            : appFonts.hankenGroteskMedium,
        }}
        container={
          inputFocus ==
            multiLanguages[contextAPI?.appLang]?.registrationNumber &&
          styles.activeTextInput
        }
        keyboardType={'number-pad'}
        onFocus={() => {
          setInputFocus(
            multiLanguages[contextAPI?.appLang]?.registrationNumber,
          );
        }}
        onBlur={() => {
          setInputFocus('');
        }}
        onChangeText={text => setRNumber(text)}
        onSubmitEditing={() => {
          Keyboard.dismiss();
        }}
      />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          flex: 1,
          marginHorizontal: scale(20),
        }}>
        <TextInputComponent
          placeholder={multiLanguages[contextAPI?.appLang]?.year}
          value={year}
          keyboardType={'number-pad'}
          inputTxtStyl={{
            fontFamily: Validation.isEmpty(year)
              ? appFonts.hankenGroteskRegular
              : appFonts.hankenGroteskMedium,
          }}
          container={[
            {
              flex: 0.48,
              marginHorizontal: scale(0),
            },
            inputFocus == multiLanguages[contextAPI?.appLang]?.year &&
              styles.activeTextInput,
          ]}
          onFocus={() => {
            setInputFocus(multiLanguages[contextAPI?.appLang]?.year);
          }}
          onBlur={() => {
            setInputFocus('');
          }}
          onChangeText={text => setYear(text)}
          onSubmitEditing={() => {
            Keyboard.dismiss();
          }}
        />
        <TextInputComponent
          placeholder={multiLanguages[contextAPI?.appLang]?.maker}
          value={maker}
          inputTxtStyl={{
            fontFamily: Validation.isEmpty(maker)
              ? appFonts.hankenGroteskRegular
              : appFonts.hankenGroteskMedium,
          }}
          container={[
            {
              flex: 0.48,
              marginHorizontal: scale(0),
            },
            inputFocus == multiLanguages[contextAPI?.appLang]?.maker &&
              styles.activeTextInput,
          ]}
          onFocus={() => {
            setInputFocus(multiLanguages[contextAPI?.appLang]?.maker);
          }}
          onBlur={() => {
            setInputFocus('');
          }}
          onChangeText={text => setMaker(text)}
          onSubmitEditing={() => {
            Keyboard.dismiss();
          }}
        />
      </View>
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
    </>
  );

  const InsuranceFormDetailsView = () => (
    <>
      <View style={styles.confirmInsuranceContainer}>
        <View style={{flex: 0.6}}>
          <Text style={styles.insuranceTxt}>
            {multiLanguages[contextAPI?.appLang]?.insurance}
          </Text>
        </View>
        <View style={styles.rightContainer}>
          <View style={styles.confirmContainer}>
            <Pressable
              onPress={() => {
                Keyboard.dismiss();
                if (
                  selectInsurance == multiLanguages[contextAPI?.appLang]?.yes
                ) {
                  setSelectInsurance('');
                } else {
                  setSelectInsurance(multiLanguages[contextAPI?.appLang]?.yes);
                }
              }}>
              <Image
                resizeMode="contain"
                style={styles.checkBoxContainer}
                source={
                  selectInsurance == multiLanguages[contextAPI?.appLang]?.yes
                    ? ImageView.checked
                    : ImageView.checkBox
                }
              />
            </Pressable>
            <Text style={styles.confirmTxt}>
              {multiLanguages[contextAPI?.appLang]?.yes}
            </Text>
          </View>
          <View style={styles.confirmContainer}>
            <Pressable
              onPress={() => {
                Keyboard.dismiss();
                if (
                  selectInsurance == multiLanguages[contextAPI?.appLang]?.no
                ) {
                  setSelectInsurance('');
                  return;
                } else {
                  setSelectInsurance(multiLanguages[contextAPI?.appLang]?.no);
                }
              }}>
              <Image
                resizeMode="contain"
                style={styles.checkBoxContainer}
                source={
                  selectInsurance == multiLanguages[contextAPI?.appLang]?.no
                    ? ImageView.checked
                    : ImageView.checkBox
                }
              />
            </Pressable>
            <Text style={styles.confirmTxt}>
              {multiLanguages[contextAPI?.appLang]?.no}
            </Text>
          </View>
        </View>
      </View>
      {selectInsurance !== multiLanguages[contextAPI?.appLang]?.yes ? null : (
        <>
          <View style={styles.sizeBox} />
          <View style={styles.sizeBox} />
          <View style={styles.sizeBox} />
          <Tooltip
            tooltipStyle={{
              alignItems: 'center',
              left: 0,
              right: 0,
            }}
            contentStyle={{
              borderRadius: 10,
              padding: 0,
            }}
            animated={true}
            arrowSize={{width: 0, height: 0}}
            backgroundColor="rgba(0,0,0,0.5)"
            isVisible={toolTipInsuranceVisible}
            content={ToolTipView()}
            placement="bottom"
            onClose={() => setToolTipInsuranceVisible(false)}>
            <TextInputComponent
              normalTxt={{
                fontFamily: Validation.isEmpty(selectInsuranceService)
                  ? appFonts.hankenGroteskRegular
                  : appFonts.hankenGroteskMedium,
                color: Validation.isEmpty(selectInsuranceService)
                  ? colors.gray
                  : colors.gray15,
              }}
              value={
                Validation.isEmpty(selectInsuranceService)
                  ? multiLanguages[contextAPI?.appLang]?.selectInsurance
                  : selectInsuranceService
              }
              rightIcon={ImageView.downArrow}
              rightIconStyl={{tintColor: colors.gray}}
              onPress={() => {
                Keyboard.dismiss();
                setSelectedToolTipType('insurance');
                setToolTipInsuranceVisible(true);
              }}
              editable={false}
            />
          </Tooltip>
        </>
      )}
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
    </>
  );

  const LocationInfoFormDetailsView = () =>
    route.params?.type == multiLanguages[contextAPI?.appLang]?.fuelGasFill ||
    route.params?.type == multiLanguages[contextAPI?.appLang]?.tireChange ||
    route.params?.type == multiLanguages[contextAPI?.appLang]?.batteryChange ? (
      <>
        {SectionTitleView(
          multiLanguages[contextAPI?.appLang]?.locationInformation,
        )}
        <View style={styles.sizeBox} />
        <View style={styles.sizeBox} />
        <View style={styles.sizeBox} />
        <TextInputComponent
          value={
            contextAPI.pickupLocation?.address
              ? contextAPI.pickupLocation?.address
              : multiLanguages[contextAPI?.appLang]?.enterLocation
          }
          normalTxt={{
            fontFamily: appFonts.hankenGroteskRegular,
            color: Validation.isEmpty(location) ? colors.gray : colors.gray15,
          }}
          editable={false}
          onPress={() => {
            Keyboard.dismiss();
            navigation.navigate('MapView', {
              type: locationTypes.pickUp,
            });
          }}
        />
        <View style={styles.sizeBox} />
        <View style={styles.sizeBox} />
        <View style={styles.sizeBox} />
      </>
    ) : (
      <>
        {SectionTitleView(
          multiLanguages[contextAPI?.appLang]?.locationInformation,
        )}
        <View style={styles.sizeBox} />
        <View style={styles.sizeBox} />
        <View style={styles.sizeBox} />
        <TextInputComponent
          value={
            // Validation.isEmpty(pickup)
            contextAPI.pickupLocation?.address
              ? contextAPI.pickupLocation?.address
              : multiLanguages[contextAPI?.appLang]?.pickup
          }
          normalTxt={{
            fontFamily: appFonts.hankenGroteskRegular,
            color: Validation.isEmpty(selectInsuranceService)
              ? colors.gray
              : colors.gray15,
          }}
          editable={false}
          onPress={() => {
            Keyboard.dismiss();
            navigation.navigate('MapView', {
              type: locationTypes.pickUp,
            });
          }}
        />
        <View style={styles.sizeBox} />
        <View style={styles.sizeBox} />
        <View style={styles.sizeBox} />
        <TextInputComponent
          value={
            // Validation.isEmpty(dropOff)
            contextAPI.dropOffLocation?.address
              ? contextAPI.dropOffLocation?.address
              : multiLanguages[contextAPI?.appLang]?.dropOff
          }
          normalTxt={{
            fontFamily: appFonts.hankenGroteskRegular,
            color: Validation.isEmpty(selectInsuranceService)
              ? colors.gray
              : colors.gray15,
          }}
          editable={false}
          onPress={() => {
            Keyboard.dismiss();
            navigation.navigate('MapView', {
              type: locationTypes.dropOff,
            });
          }}
        />
        <View style={styles.sizeBox} />
        <View style={styles.sizeBox} />
        <View style={styles.sizeBox} />
      </>
    );

  const ContactInfoFormDetailsView = () => (
    <>
      {SectionTitleView(
        multiLanguages[contextAPI?.appLang]?.contactInformation,
      )}
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <TextInputComponent
        placeholder={multiLanguages[contextAPI?.appLang]?.fullName}
        value={fName}
        inputTxtStyl={{
          fontFamily: Validation.isEmpty(fName)
            ? appFonts.hankenGroteskRegular
            : appFonts.hankenGroteskMedium,
        }}
        container={
          inputFocus == multiLanguages[contextAPI?.appLang]?.fullName &&
          styles.activeTextInput
        }
        onFocus={() => {
          setInputFocus(multiLanguages[contextAPI?.appLang]?.fullName);
        }}
        onBlur={() => {
          setInputFocus('');
        }}
        onChangeText={text => setFName(text)}
        onSubmitEditing={() => {
          Keyboard.dismiss();
        }}
      />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <TextInputComponent
        placeholder={multiLanguages[contextAPI?.appLang]?.emailAddress}
        value={email}
        inputTxtStyl={{
          fontFamily: Validation.isEmpty(email)
            ? appFonts.hankenGroteskRegular
            : appFonts.hankenGroteskMedium,
        }}
        container={
          inputFocus == multiLanguages[contextAPI?.appLang]?.emailAddress &&
          styles.activeTextInput
        }
        keyboardType={'email-address'}
        onFocus={() => {
          setInputFocus(multiLanguages[contextAPI?.appLang]?.emailAddress);
        }}
        onBlur={() => {
          setInputFocus('');
        }}
        onChangeText={text => setEmail(text)}
        onSubmitEditing={() => {
          Keyboard.dismiss();
        }}
      />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <TextInputComponent
        placeholder={multiLanguages[contextAPI?.appLang]?.mNumber}
        value={mNumber}
        inputTxtStyl={{
          fontFamily: Validation.isEmpty(mNumber)
            ? appFonts.hankenGroteskRegular
            : appFonts.hankenGroteskMedium,
        }}
        container={
          inputFocus == multiLanguages[contextAPI?.appLang]?.mNumber &&
          styles.activeTextInput
        }
        onFocus={() => {
          setInputFocus(multiLanguages[contextAPI?.appLang]?.mNumber);
        }}
        onBlur={() => {
          setInputFocus('');
        }}
        keyboardType="number-pad"
        onChangeText={text => setMNumber(text)}
        leftCustomIcon={LeftCustomIcon()}
        onSubmitEditing={() => {
          Keyboard.dismiss();
        }}
        returnKeyType={'done'}
      />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <TextInputComponent
        textAlignVertical="top"
        multiline={true}
        placeholder={multiLanguages[contextAPI?.appLang]?.note}
        value={note}
        inputTxtStyl={{
          fontFamily: Validation.isEmpty(note)
            ? appFonts.hankenGroteskRegular
            : appFonts.hankenGroteskMedium,
        }}
        container={[
          {
            height: scale(125),
            alignItems: 'flex-start',
            paddingVertical: scale(15),
            borderRadius: 15,
          },
          inputFocus == multiLanguages[contextAPI?.appLang]?.note &&
            styles.activeTextInput,
        ]}
        onFocus={() => {
          setInputFocus(multiLanguages[contextAPI?.appLang]?.note);
        }}
        onBlur={() => {
          setInputFocus('');
        }}
        onChangeText={text => setNote(text)}
      />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
    </>
  );

  const LeftCustomIcon = () => (
    <Pressable
      onPress={() => {
        Keyboard.dismiss();
        setShowCountryPicker(true);
      }}
      style={styles.customIconContainer}>
      <Text
        style={[
          styles.countryCodeTxt,
          {
            color:
              inputFocus !== multiLanguages[contextAPI?.appLang]?.mNumber
                ? colors.gray
                : colors.black,
          },
        ]}>
        {countryCode}
      </Text>
      <Image
        resizeMode="contain"
        style={[
          styles.downArrowIcon,
          {
            tintColor:
              inputFocus !== multiLanguages[contextAPI?.appLang]?.mNumber
                ? colors.gray
                : null,
          },
        ]}
        source={ImageView.downArrow}
      />
    </Pressable>
  );

  const InputTextFormView = () => (
    <View style={{paddingVertical: scale(20)}}>
      {route.params?.type == multiLanguages[contextAPI?.appLang]?.visitTechnique
        ? VisitTechniqueFormDetailsView()
        : null}

      {route.params?.type == multiLanguages[contextAPI?.appLang]?.taxi
        ? null
        : VihicleFormDetailsView()}
      {InsuranceFormDetailsView()}
      {route.params?.type == multiLanguages[contextAPI?.appLang]?.visitTechnique
        ? null
        : LocationInfoFormDetailsView()}
      {route.params?.type == multiLanguages[contextAPI?.appLang]?.visitTechnique
        ? DateTimeFormDetailsView()
        : null}
      {ContactInfoFormDetailsView()}
      <ButtonComponent
        onBtnPress={() => handleSubmit()}
        btnLabel={multiLanguages[contextAPI?.appLang]?.submit}
      />
    </View>
  );

  const SectionTitleView = (type = '') => (
    <View style={{paddingHorizontal: scale(20)}}>
      <Text style={styles.cNameTxt}>{type}</Text>
    </View>
  );

  const ModalContentView = () => (
    <View style={styles.modalContainer}>
      <View style={styles.centerIconContainer}>
        <Image
          resizeMode="contain"
          style={styles.successIcon}
          source={ImageView.success}
        />
      </View>
      <View style={{marginTop: scale(20)}}>
        <Text style={styles.succesMsgTxt}>
          {multiLanguages[contextAPI?.appLang]?.successMsg + route.params?.type}
        </Text>
        <Text style={styles.takeCalmMsgTxt}>
          {multiLanguages[contextAPI?.appLang]?.takeCalmMsg}
        </Text>
        <Text
          suppressHighlighting
          onPress={() => {
            setShowSubmitModal(false);
            setTimeout(() => {
              navigation.goBack();
            }, 500);
          }}
          style={styles.thankMsgTxt}>
          {multiLanguages[contextAPI?.appLang]?.thankMsg}
        </Text>
      </View>
    </View>
  );

  return (
    <>
      <View style={styles.container}>
        <HeaderComponent
          leftIcon={ImageView.backIconSecond}
          leftIconPress={() => {
            Keyboard.dismiss();
            navigation.goBack();
          }}
          centerTxt={route.params?.type}
        />
        <Modal
          animationIn={'fadeIn'}
          animationOut={'fadeOut'}
          isVisible={showSubmitModal}
          backdropOpacity={0.5}
          style={{
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          {ModalContentView()}
        </Modal>
        <CountryPicker
          enableModalAvoiding
          show={showCountryPicker}
          onBackdropPress={() => {
            setShowCountryPicker(false);
          }}
          onRequestClose={() => {
            setShowCountryPicker(false);
          }}
          pickerButtonOnPress={item => onSelect(item)}
          style={styles.countryPickerStyl}
        />
        <KeyboardAwareScrollView
          bounces={false}
          contentContainerStyle={{flexGrow: 1}}
          keyboardShouldPersistTaps="always"
          showsVerticalScrollIndicator={false}>
          {InputTextFormView()}
        </KeyboardAwareScrollView>
        <DatePicker
          modal
          open={showDatePicker}
          theme="light"
          mode={datePickerType}
          date={
            datePickerType == 'date'
              ? Validation.isEmpty(date)
                ? new Date()
                : new Date(moment(date, config.DOB_FORMAT))
              : Validation.isEmpty(time)
              ? new Date()
              : new Date(moment(time, config.TIME_FORMAT))
          }
          title={datePickerDynamicTitle(datePickerType)}
          androidVariant={'iosClone'}
          onConfirm={date => {
            dynamicDateHandler(date);
          }}
          onCancel={() => {
            setShowDatePicker(false);
            setDatePickerType('');
          }}
        />
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  countryPickerStyl: {
    // Styles for whole modal [View]
    modal: {
      height: verticalScale(300),
    },
    // Styles for input [TextInput]
    textInput: {
      height: scale(50),
      borderRadius: 10,
      paddingHorizontal: scale(25),
    },
    // Styles for country button [TouchableOpacity]
    countryButtonStyles: {
      height: scale(50),
      borderRadius: 10,
    },
    // Country name styles [Text]
    countryName: {
      fontSize: moderateScale(13),
      fontFamily: appFonts.interRegular,
    },
  },
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  cNameTxt: {
    fontSize: moderateScale(18),
    fontFamily: appFonts.hankenGroteskBold,
    color: colors.gray15,
  },
  sizeBox: {
    marginBottom: scale(5),
  },
  activeTextInput: {
    borderColor: colors.secondaryColor,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.17,
    shadowRadius: 2.54,
    elevation: 3,
  },
  checkBoxContainer: {
    width: scale(20),
    height: scale(20),
  },
  insuranceTxt: {
    fontSize: moderateScale(16),
    fontFamily: appFonts.hankenGroteskRegular,
    color: colors.black,
    opacity: 0.8,
  },
  confirmTxt: {
    fontSize: moderateScale(14),
    fontFamily: appFonts.hankenGroteskRegular,
    color: colors.dimGray,
  },
  confirmInsuranceContainer: {
    marginHorizontal: scale(20),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  rightContainer: {
    flex: 0.4,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  confirmContainer: {
    flex: 0.5,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
  },
  customIconContainer: {
    marginEnd: scale(10),
    height: scale(25),
    alignItems: 'center',
    flexDirection: 'row',
  },
  downArrowIcon: {
    marginLeft: scale(10),
    width: scale(20),
    height: scale(20),
  },
  countryCodeTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(16),
  },
  tollTipText: {
    fontSize: moderateScale(18),
    fontFamily: appFonts.hankenGroteskMedium,
    color: colors.black,
  },
  modalContainer: {
    borderRadius: 20,
    padding: scale(20),
    backgroundColor: colors.white,
    width: '90%',
  },
  centerIconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  successIcon: {
    width: scale(100),
    height: scale(100),
  },
  succesMsgTxt: {
    textAlign: 'center',
    fontSize: moderateScale(20),
    fontFamily: appFonts.hankenGroteskBold,
    color: colors.black,
  },
  takeCalmMsgTxt: {
    textAlign: 'center',
    fontSize: moderateScale(16),
    fontFamily: appFonts.hankenGroteskMedium,
    color: colors.black,
    opacity: 0.8,
    marginVertical: scale(10),
  },
  thankMsgTxt: {
    textAlign: 'center',
    fontSize: moderateScale(16),
    fontFamily: appFonts.hankenGroteskSemiBold,
    color: colors.primaryColor,
  },
});

export default ServiceForm;
