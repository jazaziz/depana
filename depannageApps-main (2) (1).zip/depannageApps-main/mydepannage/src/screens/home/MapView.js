import React, {useContext, useEffect, useRef, useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  Keyboard,
  Pressable,
  Dimensions,
} from 'react-native';

import {moderateScale, scale} from 'react-native-size-matters';
import {useBackHandler} from '@react-native-community/hooks';
import {Divider} from 'react-native-paper';

import HeaderComponent from '../../components/HeaderComponent';
import ButtonComponent from '../../components/ButtonComponent';
import TextInputComponent from '../../components/TextInputComponent';

import {colors, locationTypes} from '../../utils/constants';
import imageView, {ImageView} from '../../utils/imageView';
import appFonts from '../../utils/appFonts';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';
import Validation from '../../utils/validation';
import RnMap, {Marker} from 'react-native-maps';
import Geolocation from '@react-native-community/geolocation';
import {convertLatLngToAddress, openDialer} from '../../utils/helpers';

const MapView = ({navigation, route}) => {
  const [pickupLocation, setPickupLocation] = useState('');
  const [dropoffLocation, setDropoffLocation] = useState('');
  const [showPickupTxt, setShowPickupTxt] = useState(false);
  const [showDropoffTxt, setShowDropoffTxt] = useState(false);
  const [currentLocation, setCurrentLocation] = useState(null);
  const [showMap, setShowMap] = useState(false);
  const [order, setOrder] = useState(route.params?.order ?? null);
  const pickupLocationRef = useRef('');
  const dropoffLocationRef = useRef('');
  let selectedLocation = null;

  const contextAPI = useContext(ContextAPI);

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  const getCurrentLocation = async () => {
    try {
      const currentPosition = Geolocation.getCurrentPosition(
        position => {
          const {latitude, longitude} = position.coords;
          setCurrentLocation({
            latitude,
            longitude,
          });
        },
        error => {
          console.log(error);
        },
        {enableHighAccuracy: true, timeout: 15000, maximumAge: 10000},
      );
    } catch (e) {
      console.log(e);
    }
  };

  useEffect(() => {
    getCurrentLocation();
  }, []);

  const LocationDetailsView = () => (
    <View style={styles.locationDetailsContainer}>
      {route.params?.type == 'track' ? (
        TrackPickupDetailsView()
      ) : (
        <View style={styles.locationWhiteBox}>
          <View
            style={{
              flexDirection: 'row',
              flex: 0.5,
              paddingVertical: scale(10),
            }}>
            <View
              style={{
                flex: 0.1,
                justifyContent: 'center',
              }}>
              <Image
                resizeMode="contain"
                style={{width: scale(10), height: scale(10)}}
                source={ImageView.pickupLocation}
              />
            </View>
            <View style={styles.locationPlaceholderContainer}>
              {showPickupTxt ? (
                <Pressable
                  onPress={() => {
                    setShowPickupTxt(false);
                    setTimeout(() => {
                      pickupLocationRef.current.focus();
                    }, 500);
                  }}>
                  <Text style={styles.pickupLocationTxt}>
                    {multiLanguages[contextAPI?.appLang]?.pickupLocation}
                  </Text>
                  <Text style={styles.pickupLocationDetailTxt}>
                    {pickupLocation}
                  </Text>
                </Pressable>
              ) : (
                <TextInputComponent
                  inputRef={pickupLocationRef}
                  placeholder={
                    multiLanguages[contextAPI?.appLang]?.pickupLocation
                  }
                  value={pickupLocation}
                  container={styles.locationInputContainerStyl}
                  inputTxtStyl={styles.locationInputTxt}
                  onChangeText={text => setPickupLocation(text)}
                  onSubmitEditing={() => {
                    Keyboard.dismiss();
                    if (Validation.isEmpty(pickupLocation)) return;
                    setShowPickupTxt(true);
                  }}
                />
              )}
            </View>
          </View>
          <Divider style={styles.dividerLine} />
          <View
            style={{
              flexDirection: 'row',
              flex: 0.5,
              paddingVertical: scale(10),
            }}>
            <View style={{flex: 0.1, justifyContent: 'center'}}>
              <Image
                resizeMode="contain"
                style={{width: scale(10), height: scale(15)}}
                source={ImageView.location}
              />
            </View>
            <View style={styles.locationPlaceholderContainer}>
              {showDropoffTxt ? (
                <Pressable
                  onPress={() => {
                    setShowDropoffTxt(false);
                    setTimeout(() => {
                      dropoffLocationRef.current.focus();
                    }, 500);
                  }}>
                  <Text style={styles.pickupLocationTxt}>
                    {multiLanguages[contextAPI?.appLang]?.dropoffLocation}
                  </Text>
                  <Text style={styles.pickupLocationDetailTxt}>
                    {dropoffLocation}
                  </Text>
                </Pressable>
              ) : (
                <TextInputComponent
                  inputRef={dropoffLocationRef}
                  placeholder={
                    multiLanguages[contextAPI?.appLang]?.dropoffLocation
                  }
                  value={dropoffLocation}
                  container={styles.locationInputContainerStyl}
                  inputTxtStyl={styles.locationInputTxt}
                  onChangeText={text => setDropoffLocation(text)}
                  onSubmitEditing={() => {
                    Keyboard.dismiss();
                    if (Validation.isEmpty(dropoffLocation)) return;
                    setShowDropoffTxt(true);
                  }}
                />
              )}
            </View>
          </View>
        </View>
      )}
    </View>
  );

  const TrackPickupDetailsView = () => (
    <View
      style={[
        styles.locationWhiteBox,
        {
          paddingVertical: scale(15),
          paddingHorizontal: scale(15),
          width: '90%',
        },
      ]}>
      <View
        style={{
          flexDirection: 'row',
        }}>
        <View
          style={{
            flex: 0.2,
          }}>
          <Image
            resizeMode="contain"
            style={{width: scale(40), height: scale(40)}}
            source={ImageView.trackLocation}
          />
        </View>
        <View
          style={[
            styles.locationPlaceholderContainer,
            {
              flex: 0.8,
            },
          ]}>
          <Text style={styles.locationTxt}>
            {multiLanguages[contextAPI?.appLang]?.pickupSecond}
          </Text>
          <Text style={styles.locationPickupTxt}>
            {
              '4517 Washington Ave. Manchester, Kentucky Preston Rd. Inglewood, Maine39495'
            }
          </Text>
        </View>
      </View>
    </View>
  );

  const BottomTrackDetailsView = () => (
    <View
      style={{
        backgroundColor: colors.white,
        position: 'absolute',
        bottom: 0,
        right: 0,
        left: 0,
        padding: scale(15),
        borderTopEndRadius: 35,
        borderTopStartRadius: 35,
      }}>
      <View style={styles.dragLine} />
      <View style={styles.sizeBox} />
      <View
        style={{
          flexDirection: 'row',
          padding: scale(5),
        }}>
        <View style={{flex: 0.2, justifyContent: 'center'}}>
          <Image
            resizeMode="contain"
            style={styles.profileIcon}
            source={ImageView.dummyImg}
          />
        </View>
        <View
          style={{
            flex: 0.6,
            justifyContent: 'space-around',
          }}>
          <Text style={styles.userTxt}>
            {order?.proposal?.company?.companyName ?? '--'}
          </Text>
          <Text style={styles.milesTxt}>
            {order?.proposal?.company?.phoneNumber ?? '-'}
          </Text>
        </View>
        <Pressable
          style={{
            flex: 0.2,
            justifyContent: 'center',
            alignItems: 'flex-end',
          }}
          onPress={() => {
            openDialer(order?.proposal?.company?.phoneNumber);
          }}>
          <Image
            resizeMode="contain"
            style={styles.callIcon}
            source={ImageView.call}
          />
        </Pressable>
      </View>
    </View>
  );

  const GoogleMap = () => {
    const {width, height} = Dimensions.get('window');

    const ASPECT_RATIO = width / height;
    const LATITUDE_DELTA = 0.012;
    const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

    setTimeout(() => {
      setShowMap(true);
    }, 5000);

    const dummyLocation = {
      latitude: 31.728584,
      longitude: -7.011981,
    };

    const locationData = {
      latitude: currentLocation?.latitude || dummyLocation?.latitude,
      longitude: currentLocation?.longitude || dummyLocation?.longitude,
    };

    return (
      <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
        {showMap && (
          <RnMap
            style={{
              flex: 1,
              width: width * 1,
              height: height * 0.6,
            }}
            initialRegion={{
              latitude: locationData.latitude,
              longitude: locationData.longitude,
              latitudeDelta: LATITUDE_DELTA,
              longitudeDelta: LONGITUDE_DELTA,
            }}
            zoomEnabled={true}
            zoomControlEnabled={true}
            zoomTapEnabled={true}
            showsUserLocation={true}
            mapType="standard"
            showsMyLocationButton={true}
            customMapStyle={mapStyles}
            //
          >
            <Marker
              coordinate={locationData}
              draggable={true}
              onDragEnd={e => (selectedLocation = e.nativeEvent.coordinate)}>
              <Image
                source={imageView.ImageView.trackLocation}
                style={{
                  width: 50,
                  height: 50,
                }}
                resizeMode="contain"
              />
            </Marker>
          </RnMap>
        )}
      </View>
    );
  };

  const handleSubmit = async () => {
    contextAPI.setLoading(true);

    const dummyLocation = {
      latitude: 31.728584,
      longitude: -7.011981,
    };

    const locationObj = selectedLocation
      ? selectedLocation
      : currentLocation
      ? currentLocation
      : dummyLocation;

    const address = await convertLatLngToAddress(
      locationObj?.latitude,
      locationObj?.longitude,
    );

    if (route.params?.type === locationTypes.pickUp) {
      const payload = {
        ...locationObj,
        address: address,
      };
      contextAPI.setPickupLocation(payload);
    } else if (route.params?.type === locationTypes.dropOff) {
      const payload = {
        ...locationObj,
        address: address,
      };
      contextAPI.setDropOffLocation(payload);
    }
    contextAPI.setLoading(false);
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <HeaderComponent
        leftIcon={ImageView.backIcon}
        leftIconStyl={styles.leftIconStyl}
        leftIconPress={() => {
          navigation.goBack();
        }}
        headerTxt={route.params?.type == 'track' ? null : styles.headerTxt}
        headerContainer={styles.headerContainer}
        centerTxt={
          route.params?.type == 'track'
            ? null
            : multiLanguages[contextAPI?.appLang]?.myDepannage
        }
      />
      {<GoogleMap />}
      {/* {LocationDetailsView()} */}
      {route.params?.type == 'track'
        ? BottomTrackDetailsView()
        : showMap && (
            <ButtonComponent
              onBtnPress={handleSubmit}
              container={styles.btnContainer}
              btnLabel={multiLanguages[contextAPI?.appLang]?.submit}
            />
          )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.transparent,
  },
  headerContainer: {
    position: 'absolute',
    backgroundColor: colors.transparent,
    paddingTop: scale(20),
    width: '95%',
    paddingHorizontal: scale(10),
    zIndex: 10,
  },
  leftIconStyl: {
    width: scale(70),
    height: scale(70),
    top: scale(5),
    right: scale(5),
    borderRadius: scale(70 / 2),
  },
  headerTxt: {
    color: colors.primaryColor,
    fontFamily: appFonts.hangout,
    fontSize: moderateScale(24),
  },
  locationDetailsContainer: {
    right: 0,
    left: 0,
    top: scale(70),
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
  },
  locationWhiteBox: {
    borderRadius: 20,
    backgroundColor: colors.white,
    width: '75%',
    paddingHorizontal: scale(20),
    paddingVertical: scale(10),
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
  },
  btnContainer: {
    position: 'absolute',
    bottom: scale(20),
  },
  locationTxt: {
    color: colors.black,
    opacity: 0.4,
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(14),
  },
  pickupLocationTxt: {
    color: colors.black,
    opacity: 0.4,
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(11),
  },
  pickupLocationDetailTxt: {
    marginTop: scale(5),
    color: colors.black,
    opacity: 0.9,
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(13),
  },
  locationPickupTxt: {
    marginTop: scale(5),
    color: colors.black,
    opacity: 0.9,
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(15),
  },
  locationPlaceholderContainer: {
    flex: 0.9,
    justifyContent: 'center',
  },
  dividerLine: {
    height: 0.5,
    backgroundColor: colors.black,
    opacity: 0.09,
  },
  dragLine: {
    height: scale(6),
    width: scale(75),
    borderRadius: 13,
    backgroundColor: colors.silver,
    alignSelf: 'center',
  },
  sizeBox: {
    marginVertical: scale(5),
  },
  profileIcon: {
    width: scale(50),
    height: scale(50),
  },
  callIcon: {
    width: scale(48),
    height: scale(41),
  },
  userTxt: {
    color: colors.approxBlack,
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(18),
  },
  milesTxt: {
    color: colors.primaryColor,
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(14),
  },
  locationInputContainerStyl: {
    marginHorizontal: 0,
    paddingHorizontal: 0,
    borderRadius: 0,
    borderWidth: 0,
  },
  locationInputTxt: {
    height: scale(25),
    color: colors.black,
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(14),
  },
});

const mapStyles = [
  {
    featureType: 'road',
    elementType: 'geometry.stroke',
    stylers: [
      {color: '#0071BC'}, // Set the color of major roads to blue
    ],
  },
  {
    featureType: 'road',
    elementType: 'geometry.fill',
    stylers: [
      {color: '#FFFFFF'}, // Set the color of the road background to white
    ],
  },
  {
    featureType: 'road',
    elementType: 'labels.icon',
    stylers: [
      {color: '#0071BC'}, // Set the color of local road arrow icons to blue
      {visibility: 'on'}, // Show local road arrow icons
    ],
  },
  {
    featureType: 'transit.line',
    elementType: 'geometry.fill',
    stylers: [
      {color: '#0071BC'}, // Set the color of transit lines to blue
    ],
  },
];

export default MapView;
