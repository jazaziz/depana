import React, {useContext, useState} from 'react';
import {StyleSheet, View} from 'react-native';

import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import {useBackHandler} from '@react-native-community/hooks';
import RNExitApp from 'react-native-exit-app';

import HeaderComponent from '../../components/HeaderComponent';
import TileOptionList from '../../components/TileOptionList';

import {colors} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import appFonts from '../../utils/appFonts';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';

const Home = ({navigation}) => {
  const contextAPI = useContext(ContextAPI);

  const [tileOptionListData, setTileOptionListData] = useState([
    {
      id: 1,
      tag: multiLanguages[contextAPI?.appLang]?.towingService,
      icon: ImageView.tile1,
      selected: false,
      width: scale(90),
      height: scale(35),
    },
    {
      id: 2,
      tag: multiLanguages[contextAPI?.appLang]?.fuelGasFill,
      icon: ImageView.tile2,
      selected: false,
      width: scale(35),
      height: scale(40),
    },
    {
      id: 3,
      tag: multiLanguages[contextAPI?.appLang]?.tireChange,
      icon: ImageView.tile3,
      selected: false,
      width: scale(40),
      height: scale(40),
    },
    {
      id: 4,
      tag: multiLanguages[contextAPI?.appLang]?.batteryChange,
      icon: ImageView.tile4,
      selected: false,
      width: scale(40),
      height: scale(40),
    },
    {
      id: 5,
      tag: multiLanguages[contextAPI?.appLang]?.taxi,
      icon: ImageView.tile5,
      selected: false,
      width: scale(40),
      height: scale(40),
    },
    {
      id: 6,
      tag: multiLanguages[contextAPI?.appLang]?.visitTechnique,
      icon: ImageView.tile6,
      selected: false,
      width: scale(50),
      height: scale(40),
    },
  ]);

  useBackHandler(() => {
    RNExitApp.exitApp();
    return true;
  });

  return (
    <View style={styles.container}>
      <HeaderComponent
        centerTxt={multiLanguages[contextAPI?.appLang]?.welcome}
        headerTxt={styles.headerTxt}
        rightIcon={ImageView.notifications}
        rightIconStyl={styles.rightIconStyl}
        rightIconPress={() => {
          navigation.navigate('Notification');
        }}
        headerContainer={styles.headerContainer}
      />
      <TileOptionList
        onTilePress={item => {
          contextAPI?.setServiceType(item?.tag);
          navigation.navigate('ServiceForm', {
            type: item?.tag,
          });
        }}
        listTileData={tileOptionListData}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  headerContainer: {
    height: verticalScale(70),
    borderBottomEndRadius: 35,
    borderBottomStartRadius: 35,
  },
  headerTxt: {
    textAlign: 'left',
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(24),
  },
  rightIconStyl: {
    width: scale(45),
    height: scale(45),
  },
});

export default Home;
