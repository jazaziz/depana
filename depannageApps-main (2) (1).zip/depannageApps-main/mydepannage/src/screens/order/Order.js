import React, {useContext, useEffect, useState} from 'react';
import {StyleSheet, View} from 'react-native';

import {useBackHandler} from '@react-native-community/hooks';
import {scale} from 'react-native-size-matters';

import HeaderComponent from '../../components/HeaderComponent';
import TopTabBarComponent from '../../components/TopTabBarComponent';
import OrderTypeListComponent from '../../components/OrderTypeListComponent';

import {
  FirebaseCollections,
  ServicesStatus,
  colors,
} from '../../utils/constants';
import {dummuData} from '../../utils/dummyData';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';
import {FireStoreHelper} from '../../service/firebase';
import {useFocusEffect} from '@react-navigation/native';

const Order = ({navigation}) => {
  const contextAPI = useContext(ContextAPI);
  const [selectedTab, setSelectedTab] = useState(
    multiLanguages[contextAPI?.appLang]?.pending,
  );
  const [orders, setOrders] = useState([]);

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  const handleOrders = async () => {
    let orderStatus = ServicesStatus.PENDING;

    switch (selectedTab) {
      case multiLanguages[contextAPI?.appLang].onGoing:
        orderStatus = ServicesStatus.ON_GOING;
        break;

      case multiLanguages[contextAPI?.appLang].completed:
        orderStatus = ServicesStatus.COMPLETED;
        break;

      case multiLanguages[contextAPI?.appLang].cancelled:
        orderStatus = ServicesStatus.CANCELLED;
        break;
    }

    const collection = new FireStoreHelper(FirebaseCollections.Services);

    contextAPI.setLoading(true);
    const data = await collection.getAll(orderStatus);
    setOrders(data);

    setTimeout(() => {
      contextAPI.setLoading(false);
    }, 500);
  };

  useFocusEffect(
    React.useCallback(() => {
      handleOrders();
    }, [selectedTab]),
  );

  return (
    <View style={styles.container}>
      <HeaderComponent centerTxt={multiLanguages[contextAPI?.appLang]?.order} />
      <View style={{paddingBottom: scale(10), padding: scale(20)}}>
        <TopTabBarComponent
          selectedTab={selectedTab}
          titleOne={multiLanguages[contextAPI?.appLang]?.pending}
          titleSecond={multiLanguages[contextAPI?.appLang]?.onGoing}
          titleThird={multiLanguages[contextAPI?.appLang]?.completed}
          titleFour={multiLanguages[contextAPI?.appLang]?.cancelled}
          onTabPress={flag => {
            if (flag == selectedTab) return;
            setSelectedTab(flag);
          }}
        />
      </View>
      <OrderTypeListComponent
        orderPress={item => {
          navigation.navigate('OrderCustomerDetail', {
            order: item,
          });
        }}
        listData={orders}
        orderData={orders}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
});

export default Order;
