import React, {useContext, useEffect, useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  ScrollView,
  FlatList,
} from 'react-native';

import {useBackHandler} from '@react-native-community/hooks';
import Stars from 'react-native-stars';
import {moderateScale, scale} from 'react-native-size-matters';
import {Avatar} from 'react-native-paper';

import HeaderComponent from '../../components/HeaderComponent';
import EmptyMessageComponent from '../../components/EmptyMessageComponent';

import {FirebaseCollections, colors} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import appFonts from '../../utils/appFonts';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';
import {FireStoreHelper} from '../../service/firebase';
import {calculateAverageRating} from '../../utils/helpers';

const ViewProfile = ({navigation, route}) => {
  const contextAPI = useContext(ContextAPI);
  const [company, setCompany] = useState(route.params?.company ?? null);
  const [reviews, setReviews] = useState([]);

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  const fetchCompanyReviews = async () => {
    const reviewRepo = new FireStoreHelper(FirebaseCollections.OrderReviews);

    try {
      contextAPI.setLoading(true);

      const result = await reviewRepo.getByColumn(
        'company.userId',
        company?.company?.userId,
      );
      setReviews(result);
    } catch (err) {
      console.log({err});
    }

    setTimeout(() => {
      contextAPI.setLoading(false);
    }, 500);
  };

  useEffect(() => {
    (async () => {
      await fetchCompanyReviews();
    })();
  }, []);

  const ViewProfileView = () => (
    <View style={{padding: scale(20)}}>
      <View style={{}}>
        <View style={styles.positionProfileIcon}>
          <Avatar.Image
            style={{backgroundColor: colors.silver}}
            source={
              company?.company?.logo
                ? {
                    uri: company?.company?.logo,
                  }
                : ImageView.dummyImg
            }
            size={scale(95)}
          />
        </View>
        <View style={styles.whiteBox}>
          <View style={{marginTop: scale(85 / 2)}}>
            <Text style={styles.titleTxt}>
              {company?.company?.companyName ?? '--'}
            </Text>
            <View style={styles.reviewDetailsContianer}>
              <Stars
                disabled={true}
                default={calculateAverageRating(reviews.map(d => d.rating))}
                spacing={scale(5)}
                starSize={scale(14)}
                count={5}
                fullStar={ImageView.activeStar}
                emptyStar={ImageView.star}
              />
              <Text style={styles.reviewCountTxt}>{`${calculateAverageRating(
                reviews.map(d => d.rating),
              )} (${reviews?.length})`}</Text>
            </View>
          </View>
          <View style={{paddingTop: scale(20)}}>
            <View>
              <Text numberOfLines={1} style={styles.titleDetailTxt}>
                {multiLanguages[contextAPI?.appLang]?.mobileNumber}
              </Text>
              <Text numberOfLines={1} style={styles.subTitleDetailTxt}>
                {company?.company?.phoneNumber ?? '--'}
              </Text>
            </View>
            <View style={styles.sizeBox} />
            <View>
              <Text numberOfLines={1} style={styles.titleDetailTxt}>
                {multiLanguages[contextAPI?.appLang]?.aboutCompany}
              </Text>
              <Text numberOfLines={5} style={styles.subTitleDetailTxt}>
                {company?.company?.about ?? '--'}
              </Text>
            </View>
            <View style={styles.sizeBox} />
            <View>
              <Text numberOfLines={1} style={styles.titleDetailTxt}>
                {multiLanguages[contextAPI?.appLang]?.location}
              </Text>
              <Text numberOfLines={2} style={styles.subTitleDetailTxt}>
                {company?.company?.location ?? '--'}
              </Text>
            </View>
          </View>
        </View>
      </View>
      <Text style={styles.rateTxt}>
        {multiLanguages[contextAPI?.appLang]?.rateReview}
      </Text>
      <FlatList
        scrollEnabled={false}
        style={{flex: 1}}
        data={reviews}
        keyExtractor={item => item?.id}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={<EmptyMessageComponent />}
        ItemSeparatorComponent={() => (
          <View style={{marginVertical: scale(5)}} />
        )}
        renderItem={renderReviewList}
      />
    </View>
  );

  const renderReviewList = ({item}) => (
    <View style={styles.reviewItemContainer}>
      <Text numberOfLines={2} style={styles.userText}>
        {item?.user?.name ?? '-'}
      </Text>
      <View style={styles.reviewStar}>
        <Stars
          disabled={true}
          default={item?.rating ?? 0}
          spacing={scale(6)}
          starSize={scale(14)}
          count={5}
          fullStar={ImageView.activeStar}
          emptyStar={ImageView.star}
        />
      </View>
      <View style={styles.sizeBox} />
      <Text numberOfLines={5} style={styles.reviewDetailTxt}>
        {item?.review ?? '-'}
      </Text>
      <View style={styles.sizeBox} />
      <Text numberOfLines={1} style={styles.timeTxt}>
        {'6hr ago'}
      </Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <HeaderComponent
        leftIconPress={() => {
          navigation.goBack();
        }}
        leftIcon={ImageView.backIconSecond}
        centerTxt={multiLanguages[contextAPI?.appLang]?.viewProfile}
      />
      <ScrollView
        bounces={false}
        contentContainerStyle={{flexGrow: 1, paddingBottom: scale(20)}}
        keyboardShouldPersistTaps="always"
        showsVerticalScrollIndicator={false}>
        {ViewProfileView()}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  positionProfileIcon: {
    position: 'absolute',
    zIndex: 1,
    right: 0,
    left: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  whiteBox: {
    marginTop: scale(95 / 2),
    padding: scale(15),
    backgroundColor: colors.white,
    borderRadius: 20,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
  },
  titleTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(18),
    color: colors.approxBlack,
    textAlign: 'center',
  },
  reviewDetailsContianer: {
    marginTop: scale(8),
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  reviewCountTxt: {
    marginLeft: scale(10),
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(14),
    color: colors.black,
  },
  titleDetailTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.primaryColor,
  },
  subTitleDetailTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(16),
    color: colors.black,
    opacity: 0.8,
    marginTop: scale(5),
  },
  sizeBox: {
    marginVertical: scale(5),
  },
  rateTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.darkShadeBlue,
    marginVertical: scale(15),
  },
  reviewItemContainer: {
    backgroundColor: colors.lightRed,
    padding: scale(15),
    borderRadius: 15,
  },
  userText: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(14),
    color: colors.darkShadeBlue,
  },
  reviewStar: {
    marginTop: scale(5),
    alignItems: 'flex-start',
  },
  reviewDetailTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(13),
    color: colors.suvaGrey,
  },
  timeTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(12),
    color: colors.approxGray,
  },
});

export default ViewProfile;
