import React, {useContext, useEffect, useRef, useState} from 'react';
import {
  StyleSheet,
  View,
  ScrollView,
  Image,
  Pressable,
  Keyboard,
  Alert,
} from 'react-native';

import {useBackHandler} from '@react-native-community/hooks';
import RBSheet from 'react-native-raw-bottom-sheet';
import {Divider, Text} from 'react-native-paper';
import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import Stars from 'react-native-stars';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';

import HeaderComponent from '../../components/HeaderComponent';
import ProposalListComponent from '../../components/ProposalListComponent';
import ButtonComponent from '../../components/ButtonComponent';
import ProviderDetailComponent from '../../components/ProviderDetailComponent';
import TextInputComponent from '../../components/TextInputComponent';

import {
  FirebaseCollections,
  LocalStorageKeys,
  ServicesStatus,
  colors,
} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import appFonts from '../../utils/appFonts';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';
import {orderTypeMapping} from '../../utils/helpers';
import {FireStoreHelper} from '../../service/firebase';
import auth from '@react-native-firebase/auth';
import {sendNotification} from '../../service/notification';
import AsyncStorage from '@react-native-async-storage/async-storage';

const OrderCustomerDetail = ({navigation, route}) => {
  const [awardJobStatus, setAwardJobStatus] = useState(false);
  const [reviewPoint, setReviewPoint] = useState(0);
  const [writeReview, setWriteReview] = useState('');
  const [inputFocus, setInputFocus] = useState('');
  const [order, setOrder] = useState(route.params?.order);
  const [orderProposals, setOrderProposals] = useState([]);
  const [selectedProposal, setSelectedProposal] = useState(null);
  const [orderReviews, setOrderReviews] = useState([]);

  const filterBSheetRef = useRef('');
  const reviewBSheetRef = useRef('');
  const proposalBSheetRef = useRef('');

  const contextAPI = useContext(ContextAPI);

  const fetchOrderProposals = async () => {
    const firebase = new FireStoreHelper(FirebaseCollections.Proposals);

    contextAPI.setLoading(true);

    try {
      const result = await firebase.getByColumn('orderId', order.id);

      setOrderProposals(result);
    } catch (err) {
      Alert.alert('Error', err);
    }

    setTimeout(() => {
      contextAPI.setLoading(false);
    }, 500);
  };

  const handleReview = async () => {
    Keyboard.dismiss();

    const reviewRepo = new FireStoreHelper(FirebaseCollections.OrderReviews);

    try {
      contextAPI.setLoading(true);

      const user = auth().currentUser;

      const data = {
        rating: reviewPoint,
        review: writeReview,
        order: order,
        createdAt: new Date(),
        user: {
          name: user?.displayName,
          email: user?.email,
          image: user?.photoURL,
          id: user?.uid,
        },
        company: order?.proposal?.company,
      };

      await reviewRepo.create(data);

      await fetchOrderReviews();

      await sendReviewNotiToCompany();

      reviewBSheetRef.current?.close();
    } catch (err) {
      Alert.alert('Error', err);
    }

    setTimeout(() => {
      contextAPI.setLoading(false);
    }, 500);
  };

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  const checkOrderStatus = () => {
    if (order?.proposal) {
      setAwardJobStatus(true);
    }
  };

  const fetchOrderReviews = async () => {
    const reviewRepo = new FireStoreHelper(FirebaseCollections.OrderReviews);

    try {
      contextAPI.setLoading(true);

      const result = await reviewRepo.getByColumn('order.id', order.id);
      setOrderReviews(result);
    } catch (err) {
      console.log({err});
    }

    setTimeout(() => {
      contextAPI.setLoading(false);
    }, 500);
  };

  const sendReviewNotiToCompany = async () => {
    if (!awardJobStatus) return;

    const companyId = order?.proposal?.company?.userId;

    if (!!!companyId) return;

    const userSettings = new FireStoreHelper(FirebaseCollections.userSettings);
    const notification = new FireStoreHelper(FirebaseCollections.notifications);

    const companySettings = await userSettings.getByColumn('userId', companyId);

    if (!(companySettings.length > 0)) return;

    const message = {
      title: 'you got an review',
      body: `you got an review on order ${order?.id?.substring(0, 10)}`,
    };

    await sendNotification(companySettings[0]?.fcmToken, message);

    const userData = await AsyncStorage.getItem(LocalStorageKeys.USER_DATA);

    const user = JSON.parse(userData);

    const data = {
      senderId: user?.userId,
      userId: companyId,
      data: message,
      createdAt: new Date(),
    };

    await notification.create(data);
  };

  useEffect(() => {
    (async () => {
      await fetchOrderProposals();
      await fetchOrderReviews();
      checkOrderStatus();
    })();
  }, []);

  const CustomerServiceDetailsView = () => {
    const createdAtDate = new Date(order.createdAt.toDate());
    const formattedDate = createdAtDate.toLocaleDateString('en-US', {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric',
    });
    const formattedTime = createdAtDate.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });

    return (
      <View
        style={{
          margin: scale(20),
        }}>
        <View style={styles.detailsWhiteBox}>
          <View
            style={{
              padding: scale(15),
            }}>
            <View style={styles.headerItemContainer}>
              <View style={styles.leftHeaderSection}>
                <Text numberOfLines={1} style={styles.typeTxt}>
                  {orderTypeMapping(order.type)}
                </Text>
                <Text numberOfLines={1} style={styles.idTxt}>
                  {`# ${order.id.substring(0, 10)}`}
                </Text>
              </View>
              <View style={styles.rightHeaderSection}>
                <Text numberOfLines={1} style={styles.statusTxt}>
                  {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                </Text>
              </View>
            </View>
            <Text style={styles.descTxt}>{order?.contactInfo?.note}</Text>
            <View style={styles.sizeBox} />
            <Divider style={styles.dividerLine} />
            <View style={styles.sizeBox} />
            <View>
              <Text numberOfLines={1} style={styles.titleTxt}>
                {multiLanguages[contextAPI?.appLang]?.vehicleDetail}
              </Text>
              <Text numberOfLines={1} style={styles.subTitleTxt}>
                {`${order?.year} ${order?.vehicleBrand} ${order?.vehicle}`}
              </Text>
            </View>
            <View style={styles.sizeBox} />
            <View>
              <Text numberOfLines={1} style={styles.titleTxt}>
                {multiLanguages[contextAPI?.appLang]?.insurance}
              </Text>
              <Text numberOfLines={1} style={styles.subTitleTxt}>
                {'LIC'}
              </Text>
            </View>
            <View style={styles.sizeBox} />
            <View>
              <Text numberOfLines={1} style={styles.titleTxt}>
                {multiLanguages[contextAPI?.appLang]?.location}
              </Text>
              <View style={styles.sizeBox} />
              <Text numberOfLines={1} style={styles.locationTypeTxt}>
                {multiLanguages[contextAPI?.appLang]?.pickup}
              </Text>
              <Text style={styles.subTitleTxt}>
                {order?.pickUp?.address || '--'}
              </Text>
              <View style={styles.sizeBox} />
              <Text numberOfLines={1} style={styles.locationTypeTxt}>
                {multiLanguages[contextAPI?.appLang]?.dropOff}
              </Text>
              <Text style={styles.subTitleTxt}>
                {order?.dropOff?.address || '--'}
              </Text>
            </View>
            <View style={styles.sizeBox} />
            <View>
              <Text numberOfLines={1} style={styles.titleTxt}>
                {multiLanguages[contextAPI?.appLang]?.bookingDateTime}
              </Text>
              <Text numberOfLines={1} style={styles.subTitleTxt}>
                {`${formattedDate} - ${formattedTime}`}
              </Text>
            </View>
          </View>
          <View
            style={{paddingBottom: scale(10)}}
            display={awardJobStatus ? 'flex' : 'none'}>
            <Divider style={styles.dividerLine} />
            <View style={styles.sizeBox} />
            <View
              style={[
                styles.priceContainer,
                {
                  paddingHorizontal: scale(20),
                },
              ]}>
              <Text style={styles.titleTxt}>
                {multiLanguages[contextAPI?.appLang]?.amount}
              </Text>
              <Text numberOfLines={1} style={styles.amountPriceTxt}>
                {`${order?.proposal?.amount ?? 0} MAD`}
              </Text>
            </View>
            <View style={styles.sizeBox} />
          </View>
        </View>
      </View>
    );
  };

  const WriteReviewView = () => (
    <View
      style={{
        padding: scale(20),
      }}>
      <Text style={styles.reviewTenantTxt}>{'Review Tenant'}</Text>
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.reviewStar}>
        <Stars
          update={val => {
            setReviewPoint(val);
          }}
          default={reviewPoint}
          spacing={scale(16)}
          starSize={scale(32)}
          count={5}
          fullStar={ImageView.activeStar}
          emptyStar={ImageView.star}
        />
      </View>
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <TextInputComponent
        textAlignVertical="top"
        multiline={true}
        placeholder={multiLanguages[contextAPI?.appLang]?.writeReviewSecond}
        value={writeReview}
        container={[
          {
            marginHorizontal: 0,
            height: scale(180),
            alignItems: 'flex-start',
            paddingVertical: scale(15),
            borderRadius: 15,
          },
          inputFocus ==
            multiLanguages[contextAPI?.appLang]?.writeReviewSecond &&
            styles.activeTextInput,
        ]}
        onFocus={() => {
          setInputFocus(multiLanguages[contextAPI?.appLang]?.writeReviewSecond);
        }}
        onBlur={() => {
          setInputFocus('');
        }}
        onChangeText={text => setWriteReview(text)}
      />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <ButtonComponent
        onBtnPress={handleReview}
        btnLabel={multiLanguages[contextAPI?.appLang]?.submit}
      />
    </View>
  );

  const FilterView = () => (
    <View style={styles.filterContainer}>
      <Pressable
        onPress={() => {
          filterBSheetRef?.current.close();
        }}
        style={styles.filterItemContainer}>
        <Text style={styles.filtetTxt}>
          {multiLanguages[contextAPI?.appLang]?.shortPrice}
        </Text>
        <Image
          resizeMode="contain"
          style={styles.checkBoxContainer}
          source={ImageView.checked}
        />
      </Pressable>
      <Divider style={styles.dividerLine} />
      <Pressable
        onPress={() => {
          filterBSheetRef?.current.close();
        }}
        style={styles.filterItemContainer}>
        <Text style={styles.filtetTxt}>
          {multiLanguages[contextAPI?.appLang]?.shortDistances}
        </Text>
        <Image
          resizeMode="contain"
          style={styles.checkBoxContainer}
          source={ImageView.checkBoxSecond}
        />
      </Pressable>
    </View>
  );

  const ProposalDetailView = () => (
    <View style={styles.praposalContainer}>
      <View style={styles.filterItemContainer}>
        <View style={{flex: 0.25}}>
          <Image
            resizeMode="contain"
            style={styles.proposalIcon}
            source={
              selectedProposal?.company?.logo
                ? {
                    uri: selectedProposal?.company?.logo,
                  }
                : ImageView.dummyImg
            }
          />
        </View>
        <View style={styles.detailsContainer}>
          <Text numberOfLines={1} style={styles.proposalTitleTxt}>
            {selectedProposal?.company?.companyName ?? '--'}
          </Text>
          <Text numberOfLines={3} style={styles.proposalDescTxt}>
            {selectedProposal?.company?.location ?? '--'}
          </Text>
        </View>
      </View>
      <View style={{}}>
        <Text numberOfLines={1} style={styles.companyTagTxt}>
          {multiLanguages[contextAPI?.appLang]?.aboutCompany}
        </Text>
        <Text numberOfLines={5} style={styles.aboutCompanyDescTxt}>
          {selectedProposal?.company?.about ?? '--'}
        </Text>
      </View>
      <View style={styles.sizeBox} />
      <View style={styles.priceContainer}>
        <Text style={styles.companyTagTxt}>
          {multiLanguages[contextAPI?.appLang]?.price}
        </Text>
        <Text numberOfLines={1} style={styles.priceTxt}>
          {`$${selectedProposal?.amount ?? 0}`}
        </Text>
      </View>
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.priceContainer}>
        <ButtonComponent
          onBtnPress={() => {
            proposalBSheetRef?.current.close();
            setTimeout(() => {
              navigation.navigate('PaymentMethod', {
                // onGoBackHandler: () => {
                //   setAwardJobStatus(true);
                // },
                order: order,
                proposal: selectedProposal,
              });
            }, 500);
          }}
          container={{flex: 0.48}}
          btnLabel={multiLanguages[contextAPI?.appLang]?.awardJob}
        />
        <ButtonComponent
          onBtnPress={() => {
            proposalBSheetRef?.current.close();
            setTimeout(() => {
              navigation.navigate('ViewProfile', {
                company: selectedProposal,
              });
            }, 500);
          }}
          container={styles.customBtnContainer}
          btnLabelTxt={{color: colors.primaryColor}}
          btnLabel={multiLanguages[contextAPI?.appLang]?.viewProfile}
        />
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <HeaderComponent
        leftIconPress={() => {
          navigation.goBack();
        }}
        leftIcon={ImageView.backIconSecond}
        centerTxt={multiLanguages[contextAPI?.appLang]?.serviceDetails}
      />
      <RBSheet
        ref={filterBSheetRef}
        keyboardAvoidingViewEnabled={true}
        dragFromTopOnly
        height={verticalScale(180)}
        closeOnDragDown
        openDuration={250}
        customStyles={{
          container: {
            borderTopEndRadius: 35,
            borderTopStartRadius: 35,
          },
          draggableIcon: {
            top: scale(5),
            backgroundColor: colors.silver,
            height: scale(6),
            borderRadius: 13,
            width: scale(70),
          },
        }}>
        <ScrollView
          contentContainerStyle={{paddingBottom: scale(20)}}
          bounces={false}
          keyboardShouldPersistTaps="always"
          showsVerticalScrollIndicator={false}>
          {FilterView()}
        </ScrollView>
      </RBSheet>
      <RBSheet
        ref={reviewBSheetRef}
        keyboardAvoidingViewEnabled={true}
        dragFromTopOnly
        height={verticalScale(400)}
        closeOnDragDown
        openDuration={250}
        customStyles={{
          container: {
            borderTopEndRadius: 35,
            borderTopStartRadius: 35,
          },
          draggableIcon: {
            top: scale(5),
            backgroundColor: colors.silver,
            height: scale(6),
            borderRadius: 13,
            width: scale(70),
          },
        }}>
        <KeyboardAwareScrollView
          bounces={false}
          contentContainerStyle={{paddingBottom: scale(20)}}
          keyboardShouldPersistTaps="always"
          showsVerticalScrollIndicator={false}>
          {WriteReviewView()}
        </KeyboardAwareScrollView>
      </RBSheet>
      <RBSheet
        ref={proposalBSheetRef}
        keyboardAvoidingViewEnabled={true}
        dragFromTopOnly
        height={verticalScale(380)}
        closeOnDragDown
        openDuration={250}
        customStyles={{
          container: {
            borderTopEndRadius: 35,
            borderTopStartRadius: 35,
          },
          draggableIcon: {
            top: scale(5),
            backgroundColor: colors.silver,
            height: scale(6),
            borderRadius: 13,
            width: scale(70),
          },
        }}>
        <ScrollView
          contentContainerStyle={{paddingBottom: scale(20)}}
          bounces={false}
          keyboardShouldPersistTaps="always"
          showsVerticalScrollIndicator={false}>
          {ProposalDetailView()}
        </ScrollView>
      </RBSheet>
      <ScrollView
        bounces={false}
        contentContainerStyle={{flexGrow: 1, paddingBottom: scale(20)}}
        keyboardShouldPersistTaps="always"
        showsVerticalScrollIndicator={false}>
        {CustomerServiceDetailsView()}
        {awardJobStatus ? (
          <ProviderDetailComponent
            filterPress={() => {
              filterBSheetRef?.current?.open();
            }}
            trackIconPress={() => {
              navigation.navigate('MapView', {type: 'track', order: order});
            }}
            order={order}
            orderReviews={orderReviews}
            listData={Array(3).fill()}
          />
        ) : (
          <ProposalListComponent
            filterPress={() => {
              filterBSheetRef?.current?.open();
            }}
            onPraposalPress={item => {
              setSelectedProposal(item);
              proposalBSheetRef?.current?.open();
            }}
            listData={orderProposals}
          />
        )}
        {order?.status === ServicesStatus.COMPLETED && (
          <ButtonComponent
            onBtnPress={() => {
              awardJobStatus
                ? reviewBSheetRef.current.open()
                : navigation.goBack();
            }}
            btnLabel={
              awardJobStatus
                ? multiLanguages[contextAPI?.appLang]?.writeReview
                : multiLanguages[contextAPI?.appLang]?.cancel
            }
          />
        )}

        {/* <View
          style={{
            marginVertical: scale(20),
          }}>
          {awardJobStatus ? (
            <Text style={styles.refundTxt}>{'$200 ' + multiLanguages[contextAPI?.appLang]?.refundTxt}</Text>
          ) : (
            <Text style={styles.waitMsgTxt}>{multiLanguages[contextAPI?.appLang]?.waitMsg}</Text>
          )}
        </View> */}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  detailsWhiteBox: {
    borderRadius: 7,
    backgroundColor: colors.white,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
  },
  headerItemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  leftHeaderSection: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    paddingRight: scale(5),
  },
  rightHeaderSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  typeTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(18),
    color: colors.gray33,
    maxWidth: '70%',
  },
  idTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(16),
    color: colors.black,
    opacity: 0.4,
    flex: 1,
    paddingLeft: scale(10),
  },
  statusTxt: {
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(16),
    textAlign: 'right',
    color: '#978800',
  },
  descTxt: {
    paddingTop: scale(5),
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(16),
    color: colors.black,
    opacity: 0.5,
    lineHeight: scale(25),
  },
  dividerLine: {
    width: '100%',
    height: 1,
    backgroundColor: colors.black,
    opacity: 0.1,
  },
  sizeBox: {
    marginVertical: scale(5),
  },
  titleTxt: {
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(16),
    color: colors.primaryColor,
  },
  amountPriceTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.black,
  },
  locationTypeTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(14),
    color: colors.black,
    opacity: 0.5,
  },
  subTitleTxt: {
    marginTop: scale(5),
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(14),
    color: colors.black,
  },
  waitMsgTxt: {
    marginHorizontal: scale(20),
    textAlign: 'center',
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(26),
    color: colors.black,
    opacity: 0.2,
    lineHeight: scale(40),
  },
  refundTxt: {
    marginHorizontal: scale(20),
    textAlign: 'center',
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(22),
    color: colors.primaryColor,
    lineHeight: scale(35),
  },
  filterContainer: {
    paddingVertical: scale(10),
    paddingHorizontal: scale(20),
  },
  praposalContainer: {
    paddingVertical: scale(10),
    paddingHorizontal: scale(20),
  },
  filterItemContainer: {
    paddingVertical: scale(20),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  checkBoxContainer: {
    width: scale(25),
    height: scale(25),
  },
  filtetTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(18),
    color: colors.black,
  },
  proposalIcon: {
    borderRadius: 9,
    width: scale(60),
    height: scale(60),
  },
  proposalTitleTxt: {
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(17),
    color: colors.black,
  },
  detailsContainer: {
    flex: 0.75,
    paddingVertical: scale(5),
    justifyContent: 'space-between',
  },
  proposalDescTxt: {
    paddingTop: scale(5),
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(14),
    color: colors.black,
    opacity: 0.7,
  },
  companyTagTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.primaryColor,
  },
  aboutCompanyDescTxt: {
    lineHeight: scale(25),
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(16),
    color: colors.black,
    opacity: 0.8,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  proposalTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(16),
    color: colors.black,
  },
  shortingTxt: {
    fontFamily: appFonts.hankenGroteskSemiBold,
    fontSize: moderateScale(14),
    color: colors.black,
    opacity: 0.7,
  },
  priceTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(16),
    color: colors.black,
    opacity: 0.8,
  },
  customBtnContainer: {
    flex: 0.48,
    borderWidth: 1,
    borderColor: colors.primaryColor,
    elevation: 0,
    shadowOpacity: 0,
    shadowRadius: 0,
    backgroundColor: colors.transparent,
  },
  reviewTenantTxt: {
    textAlign: 'center',
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(18),
    color: colors.black,
  },
  reviewStar: {
    marginTop: scale(5),
  },
  activeTextInput: {
    borderColor: colors.secondaryColor,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.17,
    shadowRadius: 2.54,
    elevation: 3,
  },
});

export default OrderCustomerDetail;
