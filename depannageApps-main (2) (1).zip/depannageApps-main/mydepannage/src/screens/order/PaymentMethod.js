import React, {useContext, useState} from 'react';
import {StyleSheet, View, Text, Pressable, Image, Alert} from 'react-native';

import {useBackHandler} from '@react-native-community/hooks';
import {moderateScale, scale} from 'react-native-size-matters';

import HeaderComponent from '../../components/HeaderComponent';
import ButtonComponent from '../../components/ButtonComponent';

import {
  FirebaseCollections,
  ServicesStatus,
  colors,
} from '../../utils/constants';
import {ImageView} from '../../utils/imageView';
import appFonts from '../../utils/appFonts';
import {ContextAPI} from '../../contextAPI/contextProvider';
import {multiLanguages} from '../../utils/multiLanguages';
import {FireStoreHelper} from '../../service/firebase';
import {sendNotification} from '../../service/notification';
import auth from '@react-native-firebase/auth';

const PaymentMethod = ({navigation, route}) => {
  const [walletSelect, setWalletSelect] = useState(false);
  const [payType, setPayType] = useState('');
  const [order, setOrder] = useState(route.params?.order ?? null);
  const [proposal, setProposal] = useState(route.params?.proposal ?? null);

  const contextAPI = useContext(ContextAPI);

  useBackHandler(() => {
    navigation.goBack();
    return true;
  });

  const handlePayment = async () => {
    const ordersRepo = new FireStoreHelper(FirebaseCollections.Services);
    const proposalRepo = new FireStoreHelper(FirebaseCollections.Proposals);
    const userSettings = new FireStoreHelper(FirebaseCollections.userSettings);

    try {
      contextAPI.setLoading(true);

      const companySettings = await userSettings.getByColumn(
        'userId',
        proposal?.company?.userId,
      );

      await ordersRepo.update(order.id, {
        status: ServicesStatus.ON_GOING,
        proposal: proposal,
        paymentType: payType,
      });

      await proposalRepo.update(proposal.id, {isAccepted: true});

      // send notification to company
      if (!!companySettings[0]?.fcmToken) {
        await sendNotiToCompany(companySettings[0]?.fcmToken);
      }

      navigation.navigate('Order');
    } catch (err) {
      Alert.alert('Error', err);
    }
    setTimeout(() => {
      contextAPI.setLoading(false);
    }, 500);
  };

  const sendNotiToCompany = async token => {
    const message = {
      title: 'Your Proposal Accepted',
      body: `your proposal has been accepted. order No: ${order?.id?.substring(
        0,
        10,
      )}`,
    };
    await sendNotification(token, message);

    // save notifications
    const user = auth().currentUser;
    const notification = new FireStoreHelper(FirebaseCollections.notifications);

    const data = {
      senderId: user?.uid,
      userId: proposal?.company?.userId,
      data: message,
      createdAt: new Date(),
    };

    await notification.create(data);
  };

  const PaymentMethodView = () => (
    <View style={{padding: scale(20)}}>
      <Pressable
        onPress={() => {
          if (payType == 'cash') setPayType('');
          setWalletSelect(!walletSelect);
        }}
        style={styles.whiteBox}>
        <View style={{flex: 0.9}}>
          <Text style={styles.walletTxt}>
            {multiLanguages[contextAPI?.appLang]?.walletMsg}
          </Text>
          <Text style={styles.walletAmountTxt}>{'20 MAD'}</Text>
        </View>
        <View style={{flex: 0.1, alignItems: 'flex-end'}}>
          <Image
            resizeMode="contain"
            style={styles.checkBoxContainer}
            source={walletSelect ? ImageView.checked : ImageView.checkBox}
          />
        </View>
      </Pressable>
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <Pressable
        onPress={() => {
          if (payType == 'card') setPayType('');
          else setPayType('card');
        }}
        style={[
          styles.whiteBox,
          {
            justifyContent: 'flex-start',
          },
        ]}>
        <View style={{flex: 0.15}}>
          <Image
            resizeMode="contain"
            style={styles.radioBtnIcon}
            source={
              payType == 'card'
                ? ImageView.checkedRound
                : ImageView.uncheckedRound
            }
          />
        </View>
        <View style={{flex: 0.85}}>
          <Text style={styles.payTypeTxt}>
            {multiLanguages[contextAPI?.appLang]?.payCard}
          </Text>
          <View style={styles.sizeBox} />
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Image
              resizeMode="contain"
              style={styles.mCardIcon}
              source={ImageView.mastercard}
            />
            <View style={{marginLeft: scale(15)}} />
            <Image
              resizeMode="contain"
              style={styles.visaCardIcon}
              source={ImageView.visa}
            />
            <View style={{marginLeft: scale(15)}} />
            <Image
              resizeMode="contain"
              style={styles.cmiCardIcon}
              source={ImageView.cmi}
            />
          </View>
        </View>
      </Pressable>
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <Pressable
        onPress={() => {
          if (walletSelect) return;
          if (payType == 'cash') setPayType('');
          else setPayType('cash');
        }}
        style={[
          styles.whiteBox,
          {
            opacity: walletSelect ? 0.5 : 1,
            justifyContent: 'flex-start',
          },
        ]}>
        <View style={{flex: 0.15}}>
          <Image
            resizeMode="contain"
            style={styles.radioBtnIcon}
            source={
              payType == 'cash'
                ? ImageView.checkedRound
                : ImageView.uncheckedRound
            }
          />
        </View>
        <View style={{flex: 0.85}}>
          <Text style={styles.payTypeTxt}>
            {multiLanguages[contextAPI?.appLang]?.payCash}
          </Text>
          <View style={styles.sizeBox} />
          <Image
            resizeMode="contain"
            style={styles.payCashIcon}
            source={ImageView.payCash}
          />
        </View>
      </Pressable>
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <View style={styles.sizeBox} />
      <ButtonComponent
        onBtnPress={() => {
          handlePayment();
        }}
        btnLabel={multiLanguages[contextAPI?.appLang]?.cPayment}
      />
    </View>
  );

  return (
    <View style={styles.container}>
      <HeaderComponent
        leftIconPress={() => {
          navigation.goBack();
        }}
        leftIcon={ImageView.backIconSecond}
        centerTxt={multiLanguages[contextAPI?.appLang]?.paymentMethod}
      />
      {PaymentMethodView()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  whiteBox: {
    borderRadius: 11,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.17,
    shadowRadius: 3.05,
    elevation: 4,
    backgroundColor: colors.white,
    flexDirection: 'row',
    padding: scale(13),
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  checkBoxContainer: {
    width: scale(20),
    height: scale(20),
  },
  radioBtnIcon: {
    left: scale(10),
    width: scale(15),
    height: scale(15),
  },
  walletTxt: {
    fontFamily: appFonts.hankenGroteskMedium,
    fontSize: moderateScale(14),
    color: colors.gray33,
  },
  walletAmountTxt: {
    marginTop: scale(5),
    fontFamily: appFonts.hankenGroteskBold,
    fontSize: moderateScale(15),
    color: colors.grayishViolet,
  },
  sizeBox: {
    marginVertical: scale(5),
  },
  payTypeTxt: {
    fontFamily: appFonts.hankenGroteskRegular,
    fontSize: moderateScale(16),
    color: colors.blackPearl,
  },
  payCashIcon: {
    width: scale(50),
    height: scale(30),
  },
  mCardIcon: {
    width: scale(32),
    height: scale(32),
  },
  visaCardIcon: {
    width: scale(45),
    height: scale(15),
  },
  cmiCardIcon: {
    width: scale(45),
    height: scale(31),
  },
});

export default PaymentMethod;
